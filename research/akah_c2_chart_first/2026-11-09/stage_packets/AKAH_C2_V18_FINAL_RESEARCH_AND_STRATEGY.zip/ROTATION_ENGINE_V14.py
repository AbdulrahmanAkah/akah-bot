#!/usr/bin/env python3
"""AKAH V14 BTC core + dynamic long-trend rotation, read-only historical research pre2024.
No orders, no API keys. Uses V13 validated as-of OHLC/features.
"""
import sys, math, json, pandas as pd, numpy as np
sys.path.insert(0,'/mnt/data')
import akah_c2_v13_integrated as v
from pathlib import Path
D,btc,start,end=v.D,v.btc,v.start,v.end
OUT=Path('/mnt/data/AKAH_C2_V14_ROTATION');OUT.mkdir(exist_ok=True)
# Weekly and biweekly cross-sectional rankings; require 200 day history? 90d minimum.
# Return + score + liquidity reflect *past only*. No historical universe PIT proof claimed.
DAILY_RANK={}
for day in range(start,end):
 if day%7 not in (0,):continue  # fixed calendar schedule, not tuned to outcomes
 prev=day-1;bt=btc.loc[prev]
 if not (np.isfinite(bt.ret90) and np.isfinite(bt.ma200)):continue
 pool=[]
 for pair,f in D.items():
  if pair=='BTC-USDT':continue
  p=f.loc[prev]
  if not all(np.isfinite(p[k]) for k in ['open','close','ma20','ma50','ret30','ret90','ret10','atr','atrpct','vol20prev']):continue
  if not (p.vol20prev>=5e6 and .01<p.atrpct<.20 and p.ret90>.05 and p.ret30>0 and p.close>p.ma20>p.ma50):continue
  score= float(p.ret90 + .5*p.ret30 - .2*max(p.ret10,0))
  pool.append((score,pair))
 pool.sort(key=lambda x:(-x[0],x[1]))
 DAILY_RANK[day]=[pair for score,pair in pool]
print('RANK days',len(DAILY_RANK),'median candidates',np.median([len(x) for x in DAILY_RANK.values()]),flush=True)

def backtest(name,btc_target=.5,alt_target=.5,topn=3,holdrank=5,rebalance_period=7,stop_atr=4.,fee=.003,slip=.001,exclude=(),particip=.003,trade_cap=.24,guard='ma200'):
 cash=100000.;btc_units=0.;pos={};cooldown={};fills=[];daily=[];peak=100000.;dd=0.;start_2023_nav=None
 buys=0;maxpos=0
 for day in range(start,end):
  prev=day-1; br=btc.loc[day];pbr=btc.loc[prev]
  bopen=float(br.open);bclose=float(br.close)
  # prior-day BTC regime. 200-day default. Never read 2024.
  regime=bool(np.isfinite(pbr.ma200) and pbr.close>pbr.ma200)
  if guard=='ma200ret30':regime=regime and bool(np.isfinite(pbr.ret30) and pbr.ret30>0)
  # At OPEN execute sell orders due to overnight gap or risk regime changes
  for pair,p in list(pos.items()):
   r=D[pair].loc[day]
   if not np.isfinite(r.open):x=p['last']*.9;reason='missing_bar_penalty'
   elif r.open<=p['stop']:x=float(r.open);reason='gap_stop'
   elif not regime:x=float(r.open);reason='market_off'
   else:x=None
   if x is not None:
    cash+=p['units']*x*(1-slip)*(1-fee)
    profit=p['units']*x*(1-slip)*(1-fee)-p['spent']
    fills.append(dict(pair=pair,entry=p['entry'],exit=day,net=profit,reason=reason,spent=p['spent']))
    cooldown[pair]=day+7;del pos[pair]
  if btc_units and not regime:
   cash+=btc_units*bopen*(1-slip)*(1-fee);btc_units=0
  value=cash+btc_units*bopen+sum(p['units']* (float(D[k].loc[day].open) if np.isfinite(D[k].loc[day].open) else p['last']) for k,p in pos.items())
  if regime and btc_target>0 and btc_units==0:
   nominal=min(value*btc_target,cash/(1+fee))
   btc_units=nominal/(bopen*(1+slip));cash-=nominal*(1+fee)
  # Fixed periodic rebalance; use only prior-day market conditions
  if regime and alt_target>0 and day in DAILY_RANK and ((day-start)%rebalance_period==0 or rebalance_period==7):
   pool=[x for x in DAILY_RANK[day] if x not in exclude]
   # existing position can run unless it falls out of top holdrank, cash rotation at OPEN
   for pair,p in list(pos.items()):
    if pair not in pool[:holdrank]:
     r=D[pair].loc[day]
     x=float(r.open) if np.isfinite(r.open) else p['last']*.90
     cash+=p['units']*x*(1-slip)*(1-fee)
     profit=p['units']*x*(1-slip)*(1-fee)-p['spent']
     fills.append(dict(pair=pair,entry=p['entry'],exit=day,net=profit,reason='weekly_rank_rotation',spent=p['spent']))
     del pos[pair]
   # buy to fill TOP-N only; do not use today's high/close; don't oversubscribe
   alt_val=sum(p['units']*(float(D[k].loc[day].open) if np.isfinite(D[k].loc[day].open) else p['last']) for k,p in pos.items())
   nv=cash+btc_units*bopen+alt_val
   for pair in pool[:max(topn,holdrank)]:
    if len(pos)>=topn:break
    if pair in pos or day<cooldown.get(pair,0):continue
    r=D[pair].loc[day];pr=D[pair].loc[prev]
    if not np.isfinite(r.open) or not np.isfinite(pr.atr):continue
    px=float(r.open)*(1+slip);dist=min(max(float(pr.atr)*stop_atr,.04*px),.30*px)
    remaining=max(0,nv*alt_target-alt_val)
    notional=min(remaining,nv*trade_cap,nv*.008/max(dist/px,.01),float(pr.vol20prev)*particip,cash/(1+fee))
    if notional<200:continue
    u=notional/px;cost=notional*(1+fee);cash-=cost;alt_val+=notional
    pos[pair]=dict(units=u,entry=day,price=px,spent=cost,stop=px-dist,highest=px,last=px,initialrisk=dist)
    buys+=1
  # intraday stop, active from pre-close or buy-open; proceeds not used to buy earlier today
  for pair,p in list(pos.items()):
   r=D[pair].loc[day]
   if not np.isfinite(r.close):continue
   if r.low<=p['stop']:
    xp=min(float(r.open),p['stop'])*(1-slip)
    proceeds=p['units']*xp*(1-fee);cash+=proceeds
    fills.append(dict(pair=pair,entry=p['entry'],exit=day,net=proceeds-p['spent'],spent=p['spent'],reason='precommitted_stop'))
    cooldown[pair]=day+7;del pos[pair];continue
   p['last']=float(r.close);p['highest']=max(p['highest'],float(r.high))
   a=float(r.atr) if np.isfinite(r.atr) else p['initialrisk']/stop_atr
   p['stop']=max(p['stop'],p['highest']-max(.04*p['last'],min(.3*p['last'],stop_atr*a)))
  val=cash+btc_units*bclose+sum(p['units']*p['last'] for p in pos.values())
  peak=max(peak,val);dd=min(dd,val/peak-1);maxpos=max(maxpos,len(pos));daily.append((day,val,cash,btc_units*bclose,len(pos)))
  if day==pd.Timestamp('2022-12-31',tz='UTC').value//10**6//v.DAY:start_2023_nav=val
 for pair,p in pos.items():
  px=p['last']*(1-slip);proceeds=p['units']*px*(1-fee);cash+=proceeds
  fills.append(dict(pair=pair,entry=p['entry'],exit=end-1,net=proceeds-p['spent'],spent=p['spent'],reason='end_2023'))
 if btc_units:cash+=btc_units*float(btc.loc[end-1].close)*(1-slip)*(1-fee)
 tf=pd.DataFrame(fills);nf=pd.DataFrame(daily,columns=['day','nav','cash','btc_value','open_alts'])
 tops=tf.groupby('pair').net.sum().sort_values(ascending=False) if len(tf) else pd.Series(dtype=float)
 if start_2023_nav is None:start_2023_nav=100000
 return dict(policy=name,return_pct=100*(cash/100000-1),return2022_pct=100*(start_2023_nav/100000-1),return2023_pct=100*(cash/start_2023_nav-1),maxdd_pct=100*dd,trades=len(tf),pairs=tf.pair.nunique() if len(tf) else 0,maxpos=maxpos,fee=fee,slip=slip,top3=tops.head(3).index.to_list(),top3profit=tops.head(3).sum(),btc=btc_target,alt=alt_target,topn=topn,stop_atr=stop_atr,holdrank=holdrank),tf,nf

if __name__=='__main__':
 P=[('R1_BTC60_ALT40_TOP3',.6,.4,3,6,4.),('R2_BTC40_ALT60_TOP3',.4,.6,3,6,4.),('R3_BTC20_ALT80_TOP4',.2,.8,4,8,4.),('R4_ALT100_TOP4',0.,1.,4,8,4.),('R5_BTC60_ALT40_TOP5',.6,.4,5,10,5.),('R6_BTC40_ALT60_TOP5',.4,.6,5,10,5.),('R7_BTC75_ALT25_TOP2',.75,.25,2,4,5.)]
 results=[]
 for name,bc,alt,n,h,atr in P:
  print('START',name,flush=True)
  kw=dict(name=name,btc_target=bc,alt_target=alt,topn=n,holdrank=h,stop_atr=atr)
  r,td,nd=backtest(**kw);results.append(r);td.to_csv(OUT/(name+'_TRADES.csv'),index=False);nd.to_csv(OUT/(name+'_NAV.csv'),index=False)
  print('BASE',r,flush=True)
  rr,_,_=backtest(**{**kw,'name':name+'_STRESS'},fee=.006,slip=.002);results.append(rr)
  rx,_,_=backtest(**{**kw,'name':name+'_EXCLUDE3_DOUBLE'},fee=.006,slip=.002,exclude=r['top3']);results.append(rx)
 pd.DataFrame(results).to_csv(OUT/'ROTATION_RESULTS.csv',index=False)
