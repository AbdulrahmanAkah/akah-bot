#!/usr/bin/env python3
"""V17 portfolio drawdown-risk guardian for BTC trend runner (historical experiment only)."""
import sys,pandas as pd,numpy as np
sys.path.insert(0,'/mnt/data');import akah_c2_v13_integrated as v
from pathlib import Path
OUT=Path('/mnt/data/AKAH_C2_V17_RISK_GUARD');OUT.mkdir(exist_ok=True)
S=int(pd.Timestamp('2020-01-01',tz='UTC').value//10**6//v.DAY);E=v.end

def run(alloc=.5,cap=.12,lock_days=30,atrmult=6,fee=.003,slip=.001):
 d=v.btc;cash=100000.;u=0.;cost=0;stop=0;top=100000.;peak=100000.;dd=0.;locked=0;lowrisk=False;entry=0;high=0;trades=[];navs=[]
 for day in range(S,E):
  prior=d.loc[day-1];r=d.loc[day];o=float(r.open);c=float(r.close)
  permitted=bool(np.isfinite(prior.ma200) and prior.close>prior.ma200)
  portfolio_nav_open=cash+u*o
  # A drawdown kill request is based ONLY on yesterday's marked close and historical NAV peak.
  exited=False
  if u and (not permitted or prior.close<=stop or lowrisk):
   ex=o*(1-slip);p=u*ex*(1-fee);cash+=p;trades.append(dict(entry=entry,exit=day,net=p-cost,reason=('dd_guard' if lowrisk else 'stop_or_trend')));u=0;exited=True
   if lowrisk:locked=day+lock_days
   lowrisk=False
  if not u and permitted and day>=locked and not exited:
   amount=min(cash*alloc,cash/(1+fee));entry=day;px=o*(1+slip);u=amount/px;cost=amount*(1+fee);cash-=cost;high=px
   a=float(prior.atr) if np.isfinite(prior.atr) else .1*px
   stop=px-max(.04*px,atrmult*a)
  if u:
   if r.low<=stop:
    ex=min(o,stop)*(1-slip);p=u*ex*(1-fee);cash+=p;trades.append(dict(entry=entry,exit=day,net=p-cost,reason='precommitted_stop'));u=0;locked=day+lock_days
   else:
    high=max(high,float(r.high));a=float(r.atr) if np.isfinite(r.atr) else float(prior.atr)
    stop=max(stop,high-max(.04*c,atrmult*a))
  nv=cash+u*c
  peak=max(peak,nv);dd=min(dd,nv/peak-1)
  # Per-trade peak protection, not global forever. If 12% down from the local max
  # (measured on the *current position cycle*), signal exit at NEXT OPEN.
  if u:
   top=max(top,nv)
   if nv/top-1<=-cap:lowrisk=True
  else:top=nv
  navs.append((day,nv))
 if u:
  px=float(d.loc[E-1].close)*(1-slip);proceeds=u*px*(1-fee);cash+=proceeds;trades.append(dict(entry=entry,exit=E-1,net=proceeds-cost,reason='end_2023'))
 nav=pd.DataFrame(navs,columns=['day','nav']);
 y22=nav.loc[nav.day==int(pd.Timestamp('2022-12-31',tz='UTC').value//10**6//v.DAY),'nav'].iloc[0]
 y21=nav.loc[nav.day==int(pd.Timestamp('2021-12-31',tz='UTC').value//10**6//v.DAY),'nav'].iloc[0]
 return dict(alloc=alloc,cap=cap,lock=lock_days,atrmult=atrmult,fee=fee,slip=slip,return_pct=100*(cash/1e5-1),ret2020_21=100*(y21/1e5-1),ret2022=100*(y22/y21-1),ret2023=100*(cash/y22-1),mdd_pct=100*dd,trades=len(trades)),pd.DataFrame(trades),nav
if __name__=='__main__':
 res=[]
 for alloc in (.25,.5,1.):
  for cap in (.08,.12,.18):
   for lock in (14,30):
    r,t,d=run(alloc,cap,lock);res.append(r)
    r2,_,_=run(alloc,cap,lock,fee=.006,slip=.002);res.append(r2)
    if cap==.12 and lock==30 and alloc in (.25,.5,1.):d.to_csv(OUT/f'NAV_{alloc}.csv',index=False);t.to_csv(OUT/f'TRADES_{alloc}.csv',index=False)
 pd.DataFrame(res).to_csv(OUT/'PORTFOLIO_GUARD_RESULTS.csv',index=False)
 print(pd.DataFrame(res).query('fee==0.003')[['alloc','cap','lock','return_pct','mdd_pct','trades']].to_string(index=False))
