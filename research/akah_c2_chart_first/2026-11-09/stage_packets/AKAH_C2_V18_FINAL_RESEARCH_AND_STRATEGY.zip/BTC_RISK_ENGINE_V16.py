#!/usr/bin/env python3
"""Read-only BTC spot baseline risk comparison, no future/2024 prices."""
from pathlib import Path
import sys,json
sys.path.insert(0,'/mnt/data');import akah_c2_v13_integrated as v
import pandas as pd,numpy as np
OUT=Path('/mnt/data/AKAH_C2_V16_FINAL_EVIDENCE');OUT.mkdir(exist_ok=True)
def simulation(alloc=1.,trail=None,cooldown_days=0,fee=.003,slip=.001):
 b=v.btc;c=100000.;u=0.;spent=0.;entry=0;stop=0;highest=0.;cool=0;trades=[];navs=[];maxdd=0.;peak=100000.;y22=100000.;turnover=0.
 for day in range(v.start,v.end):
  p=b.loc[day-1];r=b.loc[day];open_=float(r.open);close=float(r.close)
  market_on=bool(np.isfinite(p.ma200) and p.close>p.ma200)
  if u>0 and (not market_on or (trail is not None and open_<=stop)):
   ex=open_*(1-slip);proceeds=u*ex*(1-fee);c+=proceeds;turnover+=u*ex
   trades.append(dict(entry_day=entry,exit_day=day,net=proceeds-spent,exit_type='regime_or_gap',exit_price=ex));u=0;cool=day+cooldown_days
  if u==0 and market_on and day>=cool:
   cap=min(c*alloc,c/(1+fee));en=open_*(1+slip);u=cap/en;spent=cap*(1+fee);c-=spent;turnover+=cap;entry=day;highest=en
   if trail is not None:
    atr=float(p.atr)
    if not np.isfinite(atr):raise AssertionError('BTC ATR missing')
    stop=en-max(.04*en,trail*atr)
  if trail is not None and u>0:
   if float(r.low)<=stop:
    ex=min(open_,stop)*(1-slip);proceeds=u*ex*(1-fee);c+=proceeds;turnover+=u*ex
    trades.append(dict(entry_day=entry,exit_day=day,net=proceeds-spent,exit_type='precommitted_stop',exit_price=ex));u=0;cool=day+cooldown_days
   else:
    highest=max(highest,float(r.high))
    atr=float(r.atr)
    if np.isfinite(atr):stop=max(stop,highest-max(.04*close,trail*atr))
  nav=c+u*close;peak=max(peak,nav);maxdd=min(maxdd,nav/peak-1);navs.append((day,nav))
  if day==pd.Timestamp('2022-12-31',tz='UTC').value//10**6//v.DAY:y22=nav
 if u:
  ex=float(b.loc[v.end-1].close)*(1-slip);proceeds=u*ex*(1-fee);c+=proceeds;trades.append(dict(entry_day=entry,exit_day=v.end-1,net=proceeds-spent,exit_type='end_2023',exit_price=ex));turnover+=u*ex
 return dict(alloc=alloc,trail_atr=trail,cooldown=cooldown_days,fee=fee,slip=slip,final=c,return_pct=100*(c/1e5-1),return2022_pct=100*(y22/1e5-1),return2023_pct=100*(c/y22-1),maxdd_pct=100*maxdd,trades=len(trades),turnover_usd=turnover),pd.DataFrame(trades),pd.DataFrame(navs,columns=['day','nav'])
if __name__=='__main__':
 allres=[]
 for alloc in (.25,.5,.75,1.):
  for trail,cool in ((None,0),(4.,7),(6.,7),(4.,14)):
   name=f'btc_{alloc}_{trail}_{cool}';r,t,n=simulation(alloc,trail,cool);r['name']=name;allres.append(r)
   rs,_,_=simulation(alloc,trail,cool,fee=.006,slip=.002);rs['name']=name+'_DOUBLE';allres.append(rs)
   if alloc in (0.5,1.) and trail in (None,4.):n.to_csv(OUT/(name+'_NAV.csv'),index=False);t.to_csv(OUT/(name+'_TRADES.csv'),index=False)
 pd.DataFrame(allres).to_csv(OUT/'BTC_RISK_COMPARISON.csv',index=False)
 print(pd.DataFrame(allres).loc[lambda d: d.fee.eq(.003),['name','return_pct','maxdd_pct','trades']].to_string(index=False))
