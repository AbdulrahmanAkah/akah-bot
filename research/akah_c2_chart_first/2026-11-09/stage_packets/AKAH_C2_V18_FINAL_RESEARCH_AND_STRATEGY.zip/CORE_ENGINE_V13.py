#!/usr/bin/env python3
"""AKAH C2 V13 — empirical multi-asset dynamic trend allocation lab.
Historical-only, strictly pre-2024, CASH SPOT, as-of next-open signals; no trading instructions or API keys.
"""
import io,glob,zipfile,math,json,hashlib,sys
from pathlib import Path
import numpy as np,pandas as pd
DAY=86400000
ROOT=Path('/mnt/data');OUT=ROOT/'AKAH_C2_V13_INTEGRATED';OUT.mkdir(exist_ok=True)
start=pd.Timestamp('2022-01-01',tz='UTC').value//10**6//DAY
end=pd.Timestamp('2024-01-01',tz='UTC').value//10**6//DAY
# Include prior years for trailing indicators, but never 2024.
a0=pd.Timestamp('2019-01-01',tz='UTC').value//10**6//DAY
all_days=np.arange(a0,end,dtype=int)
D={};sources={};records=[]
for file in sorted(glob.glob('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip')):
 with zipfile.ZipFile(file) as z:
  for nm in z.namelist():
   if not nm.startswith('daily/') or not nm.endswith('.csv.gz'):continue
   stem=nm[6:-7];venue,pair=stem.split('_',1)
   if pair in D and venue=='BINANCE':continue
   try:
    data=pd.read_csv(io.BytesIO(z.read(nm)),compression='gzip')
    if not {'unix_ms','open','high','low','close','base_volume'}.issubset(data.columns):continue
    data=data.loc[(data.unix_ms>=a0*DAY)&(data.unix_ms<end*DAY)].drop_duplicates('unix_ms',keep='last')
    for k in ('open','high','low','close','base_volume'):
     data[k]=pd.to_numeric(data[k],errors='coerce')
    data=data.loc[(data.open>0)&(data.high>=data.open)&(data.high>=data.close)&(data.low<=data.open)&(data.low<=data.close)&(data.low>0)&(data.close>0)&(data.base_volume>=0)]
    if len(data)<90:continue
    data['day']=(data.unix_ms//DAY).astype(int)
    data=data.sort_values('day').drop_duplicates('day').set_index('day')
    df=data.reindex(all_days)
    # Require no gaps for rolling features. Native quote volume retained separately.
    df['qproxy']=df.base_volume*df.close
    tr=pd.concat([df.high-df.low,abs(df.high-df.close.shift(1)),abs(df.low-df.close.shift(1))],axis=1).max(axis=1,skipna=False)
    df['atr']=tr.rolling(14,min_periods=14).mean()
    for n in [10,20,30,50,90,100,200]:
     df[f'ma{n}']=df.close.rolling(n,min_periods=n).mean()
    for n in [5,10,20,30,90]:df[f'ret{n}']=df.close/df.close.shift(n)-1
    df['h20prev']=df.high.shift(1).rolling(20,min_periods=20).max()
    df['h55prev']=df.high.shift(1).rolling(55,min_periods=55).max()
    df['vol20prev']=df.qproxy.shift(1).rolling(20,min_periods=20).median()
    df['volmomentum']=df.qproxy/(df.vol20prev+1e-8)
    df['atrpct']=df.atr/df.close
    # Signal after close, acted at next day's open. No future/hindsight inputs.
    df['entry20']=(df.close>df.h20prev)&(df.close.shift(1)<=df.h20prev.shift(1))
    df['entry55']=(df.close>df.h55prev)&(df.close.shift(1)<=df.h55prev.shift(1))
    D[pair]=df;sources[pair]=venue
   except Exception as e: records.append((pair,repr(e)[:80]))
assert 'BTC-USDT' in D
btc=D['BTC-USDT'];print('DATA',len(D),'btc',int(btc.close.notna().sum()),'errors',len(records),flush=True)
# Only current-day available signals (never future membership). Universe still NOT PIT-certified.
# Test all policies on same 2022-2023 historical window; in-sample due extensive prior work.
POLICIES=[
 dict(name='B0_BTC100_MA200',btc=1.,alt=0.,mode='none',breadth=False,exit='none',r=.004),
 dict(name='B1_BTC75_ALT25_LEADERS',btc=.75,alt=.25,mode='55',breadth=False,exit='atr',r=.005),
 dict(name='B2_BTC50_ALT50_LEADERS',btc=.50,alt=.50,mode='55',breadth=False,exit='atr',r=.006),
 dict(name='B3_BTC25_ALT75_LEADERS',btc=.25,alt=.75,mode='55',breadth=False,exit='atr',r=.008),
 dict(name='B4_BTC50_ALT50_RECLAIM',btc=.50,alt=.50,mode='20',breadth=False,exit='atr',r=.006),
 dict(name='B5_BTC50_ALT50_LEADERS_MARKET_BREADTH',btc=.50,alt=.50,mode='55',breadth=True,exit='atr',r=.006),
 dict(name='B6_BTC75_ALT25_DUAL_REGIME',btc=.75,alt=.25,mode='55',breadth=False,exit='dual',r=.004),
 dict(name='B7_BTC100_MA100',btc=1.,alt=0.,mode='none',breadth=False,exit='none',r=.004,ma=100),
]
# point-in-time breadth: shares among assets with 200d cumulative indicators, not 2024 symbol master for time of eligibility
breadth={}
for day in range(start-1,end):
 eligible=0;up=0
 for pair,f in D.items():
  if pair=='BTC-USDT':continue
  row=f.loc[day]
  if not (np.isfinite(row.ma200) and np.isfinite(row.close)):continue
  if row.vol20prev<200000:continue
  eligible+=1;up+=int(row.close>row.ma50)
 breadth[day]=up/eligible if eligible>0 else np.nan

# Compute all point-in-time signals ONCE; reuse exact decisions for every cost/exclusion scenario.
# Event day = signal calendar close + 1; no future outcome is used.
SIGNAL_BANK={mode:{} for mode in ('20','55')}
for pair,f in D.items():
 if pair=='BTC-USDT':continue
 bp=btc[['ret30','ret90']]
 common=(f.vol20prev>=5e6)&(f.atrpct>=.01)&(f.atrpct<=.15)&(f.ret90>=.20)&(f.close>f.ma20)&(f.ma20>f.ma50)&(f.ret30>btc.ret30)
 for mode in ('20','55'):
  mask=common & f[f'entry{mode}'] & f.open.shift(-1).notna() & btc.ret90.notna()
  subset=f.loc[mask & (f.index>=start-1) & (f.index<=end-2)]
  if subset.empty:continue
  for day,p in subset.iterrows():
   score=float(p.ret90-btc.loc[day].ret90 + .5*(p.ret30-btc.loc[day].ret30))
   score+=.02*min(max(float(p.volmomentum),0),5)
   if not np.isfinite(score):continue
   SIGNAL_BANK[mode].setdefault(day+1,[]).append((score,pair,float(p.atr),float(p.vol20prev)))
for mode in SIGNAL_BANK:
 for day,items in SIGNAL_BANK[mode].items():items.sort(key=lambda x:(-x[0],x[1]))
print('SIGNAL_BANK', {k:sum(len(v) for v in d.values()) for k,d in SIGNAL_BANK.items()},flush=True)

def broker(pol,fee=.003,slip=.001,excluded=(),limit_mode='regular',trade_cap=.18,topn=4):
 c=100000.;btc_units=0.;positions={};ledger=[];days=[];pair_pnl={};year_end=None;oldpk=100000.;dd=0.;cooled={};buycount=0;maxpos=0;bad=0
 alt_target=pol['alt'];btc_target=pol['btc'];qmin=5e6 if limit_mode!='easier' else 1e6
 for day in range(start,end):
  previous=day-1
  bt=btc.loc[day];bp=btc.loc[previous];bt_open=float(bt.open);bt_close=float(bt.close)
  if not (np.isfinite(bt_open) and np.isfinite(bt_close)):raise RuntimeError('missing BTC bar')
  pma=float(bp[f"ma{pol.get('ma',200)}"])
  regime=bool(np.isfinite(pma) and bp.close>pma)
  if pol.get('breadth') and regime:
   regime=bool(np.isfinite(breadth.get(previous,np.nan)) and breadth[previous]>.42)
  # OPEN: exits triggered by prior close and overnight gaps, before any new buys.
  for pair,p in list(positions.items()):
   row=D[pair].loc[day]
   if not np.isfinite(row.open):
    reason='missing_open_censored';px=p['last']*.90;bad+=1
   elif float(row.open)<=p['stop']:
    reason='overnight_gap_stop';px=float(row.open)
   elif pol['exit']=='dual' and ((not regime) or (np.isfinite(D[pair].loc[previous].ma20) and D[pair].loc[previous].close<D[pair].loc[previous].ma20)):
    reason='prior_day_trend_weak';px=float(row.open)
   else: reason=None
   if reason:
    sale=p['units']*px*(1-slip)*(1-fee);c+=sale;net=sale-p['cost'];pair_pnl[pair]=pair_pnl.get(pair,0)+net
    ledger.append(dict(pair=pair,reason=reason,entry_day=p['entry'],exit_day=day,net=net,spent=p['cost'],entry_price=p['entryprice'],exit_price=px*(1-slip),maxhigh=p['highest'],adds=p.get('adds',0)));cooled[pair]=day+3;del positions[pair]
  if btc_units and not regime:
   c+=btc_units*bt_open*(1-slip)*(1-fee);btc_units=0.
  nav_open=c+btc_units*bt_open
  for pair,p in positions.items():
   row=D[pair].loc[day];mark=float(row.open) if np.isfinite(row.open) else p['last'];nav_open+=p['units']*mark
  # BTC core: one initial allocation within regime, then hold; no 2024 data.
  if regime and not btc_units and btc_target>0:
   nominal=min(c/(1+fee),btc_target*nav_open)
   if nominal>0:
    btc_units=nominal/(bt_open*(1+slip));c-=nominal*(1+fee)
  # ALT positions are added only if there is prior-close evidence, fixed candidate score.
  candidates=[]
  if regime and alt_target>0:
   for signal in SIGNAL_BANK[pol['mode']].get(day,[]):
    if signal[1] not in excluded and signal[1] not in positions and day>=cooled.get(signal[1],0):
     candidates.append(signal)
  # Constrain total alt capital using OPEN marks; no use of today's high/low/close.
  invest_alt=sum(p['units']*(float(D[pair].loc[day].open) if np.isfinite(D[pair].loc[day].open) else p['last']) for pair,p in positions.items())
  for score,pair,atr,qprev in candidates:
   if len(positions)>=topn:break
   r=D[pair].loc[day];px=float(r.open)*(1+slip)
   distance=max(.05*px,4.0*atr);distance=min(distance,.24*px)
   stop=px-distance
   nav_open=c+btc_units*bt_open+invest_alt
   maxrisk=nav_open*pol['r']/max(distance/px,.001)
   new=min(nav_open*trade_cap,maxrisk,qprev*(.001 if limit_mode=='strict' else .004),c/(1+fee),max(0,nav_open*alt_target-invest_alt))
   if new<100:continue
   units=new/px;spent=new*(1+fee);c-=spent;invest_alt+=new;positions[pair]=dict(units=units,cost=spent,entry=day,entryprice=px,stop=stop,highest=px,last=px,atr=atr,adds=0)
   buycount+=1
  # OHLC stop handling, stops were active before this day's price path; no same-day stop financing earlier buys.
  for pair,p in list(positions.items()):
   r=D[pair].loc[day]
   if not (np.isfinite(r.open) and np.isfinite(r.low) and np.isfinite(r.high) and np.isfinite(r.close)):
    continue
   if r.low<=p['stop']:
    price=min(float(r.open),p['stop'])*(1-slip);sale=p['units']*price*(1-fee);c+=sale
    net=sale-p['cost'];pair_pnl[pair]=pair_pnl.get(pair,0)+net
    ledger.append(dict(pair=pair,reason='intraday_precommitted_stop',entry_day=p['entry'],exit_day=day,net=net,spent=p['cost'],entry_price=p['entryprice'],exit_price=price,maxhigh=p['highest'],adds=p.get('adds',0)));cooled[pair]=day+3;del positions[pair];continue
   p['highest']=max(p['highest'],float(r.high));p['last']=float(r.close)
   # Stop raised *after* close, hence cannot be filled earlier on the same day.
   atr=float(r.atr) if np.isfinite(r.atr) else p['atr'];dist=max(.05*p['last'],4*atr);dist=min(dist,.24*p['last'])
   p['stop']=max(p['stop'],p['highest']-dist)
  # Daily marked-to-market; BTC asset still valued at day's close
  nav=c+btc_units*bt_close+sum(p['units']*p['last'] for p in positions.values())
  oldpk=max(oldpk,nav);dd=min(dd,nav/oldpk-1);maxpos=max(maxpos,len(positions));days.append((day,nav,len(positions),btc_units*bt_close,c))
  if day==pd.Timestamp('2022-12-31',tz='UTC').value//10**6//DAY:year_end=nav
 # liquidate all on last close with cost/slippage
 for pair,p in positions.items():
  px=p['last']*(1-slip);sale=p['units']*px*(1-fee);c+=sale;net=sale-p['cost'];pair_pnl[pair]=pair_pnl.get(pair,0)+net
  ledger.append(dict(pair=pair,reason='end_2023',entry_day=p['entry'],exit_day=end-1,net=net,spent=p['cost'],entry_price=p['entryprice'],exit_price=px,maxhigh=p['highest'],adds=p.get('adds',0)))
 if btc_units:c+=btc_units*float(btc.loc[end-1].close)*(1-slip)*(1-fee)
 if year_end is None:year_end=1e5
 top=sorted(pair_pnl.items(),key=lambda x:-x[1]);out=dict(policy=pol['name'],cost_side=fee,slip_side=slip,excluded=','.join(excluded),limit_mode=limit_mode,trades=len(ledger),pairs=len(set(x['pair'] for x in ledger)),returns_pct=100*(c/1e5-1),return_2022_pct=100*(year_end/1e5-1),return_2023_pct=100*(c/year_end-1),max_drawdown_pct=100*dd,max_positions=maxpos,top3_profit=sum(n for k,n in top[:3]),top3_pairs=[k for k,n in top[:3]],censors=bad,btc_target=btc_target)
 return out,pd.DataFrame(ledger),pd.DataFrame(days,columns=['day','nav','alt_positions','btc_value','cash'])

if __name__=='__main__':
 results=[];daily={};trades={}
 for pol in POLICIES:
  o,t,d=broker(pol);results.append(o);daily[pol['name']]=d;trades[pol['name']]=t
  print('BASE',pol['name'],round(o['returns_pct'],2),round(o['return_2022_pct'],2),round(o['return_2023_pct'],2),round(o['max_drawdown_pct'],2),o['trades'],flush=True)
  o2,_,_=broker(pol,fee=.006,slip=.002);results.append(o2)
  if o['top3_pairs']:
   o3,_,_=broker(pol,fee=.006,slip=.002,excluded=tuple(o['top3_pairs']));results.append(o3)
 for k,v in daily.items():v.to_csv(OUT/f'{k}_DAILY_NAV.csv',index=False)
 for k,v in trades.items():v.to_csv(OUT/f'{k}_TRADES.csv',index=False)
 pd.DataFrame(results).to_csv(OUT/'POLICY_COMPARISONS.csv',index=False)
 (OUT/'AUDIT_METADATA.json').write_text(json.dumps(dict(n_pairs=len(D),venues=sources,errors=records,years='2022-2023',status='UNAPPROVED_RESEARCH_HISTORICALLY_EXPOSED_UNIVERSE_NOT_PIT_CERTIFIED',candidate_policies=POLICIES),indent=2))
