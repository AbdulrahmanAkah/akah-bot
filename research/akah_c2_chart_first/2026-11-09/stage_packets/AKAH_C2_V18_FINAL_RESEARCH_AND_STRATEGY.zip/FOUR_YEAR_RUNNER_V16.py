from pathlib import Path
import json,sys,pandas as pd,numpy as np
sys.path.insert(0,'/mnt/data');import akah_c2_v16_btc_risklab as m
OUT=Path('/mnt/data/AKAH_C2_V16_FINAL_EVIDENCE');OUT.mkdir(exist_ok=True)
m.v.start=int(pd.Timestamp('2020-01-01',tz='UTC').value//10**6//m.v.DAY)
m.v.end=int(pd.Timestamp('2024-01-01',tz='UTC').value//10**6//m.v.DAY)
res=[]
for alloc in [.25,.5,.75,1.]:
 for trail,cool in [(None,0),(4.,7),(6.,7)]:
  for fee,slip in [(0.003,0.001),(0.006,0.002)]:
   r,tr,nd=m.simulation(alloc,trail,cool,fee,slip)
   nd['date']=pd.to_datetime(nd.day,unit='D',utc=True)
   for yr in range(2020,2024):
    seg=nd.loc[nd.date.dt.year==yr]
    if seg.empty:continue
    startnav=float(nd.loc[nd.day==seg.day.iloc[0]-1,'nav'].iloc[0]) if nd.day.iloc[0]<seg.day.iloc[0] else 100000.
    r[f'ret_{yr}']=100*(float(seg.nav.iloc[-1])/startnav-1)
   r['period']='2020-2023';res.append(r)
   if fee==.003 and alloc in [.5,1.] and trail in [None,6.]:
    nd.to_csv(OUT/f'BROAD_{alloc}_{trail}_DAILY_NAV.csv',index=False)
    tr.to_csv(OUT/f'BROAD_{alloc}_{trail}_TRADES.csv',index=False)
pd.DataFrame(res).to_csv(OUT/'FOUR_YEAR_RISK_COMPARISONS.csv',index=False)
print(pd.DataFrame(res).loc[lambda d:d.fee.eq(.003),['alloc','trail_atr','return_pct','maxdd_pct','ret_2020','ret_2021','ret_2022','ret_2023','trades']].to_string(index=False))
