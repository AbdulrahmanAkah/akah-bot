#!/usr/bin/env python3
"""BTC-core, ALT-leader substituting rather than idle-cash; causal daily spot simulation, historical only."""
import sys,json,math
sys.path.insert(0,'/mnt/data');import akah_c2_v13_integrated as base
import akah_c2_v14_rotation as rot
import numpy as np,pandas as pd
from pathlib import Path
D,btc,start,end=base.D,base.btc,base.start,base.end
OUT=Path('/mnt/data/AKAH_C2_V15_SWAP');OUT.mkdir(exist_ok=True)
def run(name,alt_limit=.6,topn=3,per_asset=.24,atr_mult=4.5,risk=.012,fee=.003,slip=.001,exclude=(),holdrank=8,ranking='rotation',strict=False):
 cash=100000.;btc_units=0.;positions={};cool={};fills=[];days=[];peak=100000.;dd=0.;y22=None;btc_orders=0;alt_orders=0;stops=0
 for day in range(start,end):
  prev=day-1;br=btc.loc[day];bpr=btc.loc[prev];o=float(br.open);cl=float(br.close)
  regime=bool(np.isfinite(bpr.ma200) and bpr.close>bpr.ma200)
  # Exits at market open based on PREVIOUS known stop or regime
  for pair,p in list(positions.items()):
   r=D[pair].loc[day]
   if not np.isfinite(r.open):x=p['last']*.9;why='censor'
   elif r.open<=p['stop']:x=float(r.open);why='gap_stop'
   elif not regime:x=float(r.open);why='regime_off'
   else:continue
   proceeds=p['units']*x*(1-slip)*(1-fee);cash+=proceeds
   fills.append(dict(pair=pair,entry=p['entry'],exit=day,net=proceeds-p['spent'],spent=p['spent'],exit_reason=why,peak=p['high'],entry_px=p['price'],exit_px=x*(1-slip)))
   cool[pair]=day+7;del positions[pair]
  if btc_units and not regime:
   cash+=btc_units*o*(1-slip)*(1-fee);btc_units=0;btc_orders+=1
  # weekly rotation based only PREV day; if holdrank=999 never rotate after entry
  ranks=rot.DAILY_RANK.get(day,[])
  if regime and ranks and holdrank<999:
   elig=[x for x in ranks if x not in exclude]
   for pair,p in list(positions.items()):
    if pair not in elig[:holdrank]:
     r=D[pair].loc[day]
     x=float(r.open) if np.isfinite(r.open) else p['last']*.9
     proceeds=p['units']*x*(1-slip)*(1-fee);cash+=proceeds
     fills.append(dict(pair=pair,entry=p['entry'],exit=day,net=proceeds-p['spent'],spent=p['spent'],exit_reason='weekly_rotated',peak=p['high'],entry_px=p['price'],exit_px=x*(1-slip)))
     del positions[pair]
  opening_pos=sum(p['units']*(float(D[k].loc[day].open) if np.isfinite(D[k].loc[day].open) else p['last']) for k,p in positions.items())
  nav=cash+btc_units*o+opening_pos
  altused=opening_pos
  # Seek new entries at next OPEN; historical rank computed last close only
  if regime and ranks:
   for pair in ranks[:max(topn,holdrank if holdrank<999 else topn*5)]:
    if len(positions)>=topn:break
    if pair in exclude or pair in positions or day<cool.get(pair,0):continue
    r=D[pair].loc[day];prior=D[pair].loc[prev]
    if not (np.isfinite(r.open) and np.isfinite(prior.atr) and np.isfinite(prior.vol20prev)):continue
    if float(prior.vol20prev)<5e6:continue
    px=float(r.open)*(1+slip);distance=min(.30*px,max(.06*px,atr_mult*float(prior.atr)))
    if distance<=0:continue
    nominal=min(nav*per_asset,nav*risk/(distance/px),max(0.,alt_limit*nav-altused),float(prior.vol20prev)*(.001 if strict else .004))
    if nominal<200:continue
    needed=nominal*(1+fee)-cash
    # At same OPEN sell enough BTC FIRST to finance ALT buy. No leverage or future cash.
    if needed>0 and btc_units>0:
     saleunits=min(btc_units,needed/(o*(1-slip)*(1-fee)))
     cash+=saleunits*o*(1-slip)*(1-fee);btc_units-=saleunits;btc_orders+=1
    nominal=min(nominal,cash/(1+fee))
    if nominal<200:continue
    qty=nominal/px;spent=nominal*(1+fee);cash-=spent
    positions[pair]=dict(units=qty,spent=spent,entry=day,price=px,stop=px-distance,high=px,last=px,atr=prior.atr)
    altused+=nominal;alt_orders+=1
  # put remaining cash into BTC (if regime) at open, not using todays closed-bar data
  if regime and cash>1:
   buy_nom=cash/(1+fee);btc_units+=buy_nom/(o*(1+slip));cash-=buy_nom*(1+fee);btc_orders+=1
  # Intraday exits; proceeds stay cash until next OPEN
  for pair,p in list(positions.items()):
   r=D[pair].loc[day]
   if not (np.isfinite(r.open) and np.isfinite(r.low) and np.isfinite(r.high) and np.isfinite(r.close)):continue
   if r.low<=p['stop']:
    x=min(float(r.open),p['stop'])*(1-slip);proceeds=p['units']*x*(1-fee);cash+=proceeds
    fills.append(dict(pair=pair,entry=p['entry'],exit=day,net=proceeds-p['spent'],spent=p['spent'],exit_reason='precommitted_stop',peak=p['high'],entry_px=p['price'],exit_px=x))
    cool[pair]=day+7;del positions[pair];stops+=1;continue
   p['last']=float(r.close);p['high']=max(p['high'],float(r.high))
   atr=float(r.atr) if np.isfinite(r.atr) else float(p['atr'])
   trail=max(.06*p['last'],min(.30*p['last'],atr_mult*atr))
   p['stop']=max(p['stop'],p['high']-trail)
  total=cash+btc_units*cl+sum(p['units']*p['last'] for p in positions.values())
  peak=max(peak,total);dd=min(dd,total/peak-1);days.append((day,total,len(positions),btc_units*cl,cash))
  if day==pd.Timestamp('2022-12-31',tz='UTC').value//10**6//base.DAY:y22=total
 for pair,p in positions.items():
  px=p['last']*(1-slip);val=p['units']*px*(1-fee);cash+=val
  fills.append(dict(pair=pair,entry=p['entry'],exit=end-1,net=val-p['spent'],spent=p['spent'],exit_reason='end_2023',peak=p['high'],entry_px=p['price'],exit_px=px))
 if btc_units:cash+=btc_units*float(btc.loc[end-1].close)*(1-slip)*(1-fee)
 ledger=pd.DataFrame(fills);nav=pd.DataFrame(days,columns=['day','nav','open_alt_count','btc_value','cash'])
 tops=ledger.groupby('pair').net.sum().sort_values(ascending=False) if len(ledger) else pd.Series(dtype=float)
 r=dict(policy=name,return_pct=100*(cash/1e5-1),return_2022_pct=100*(y22/1e5-1),return_2023_pct=100*(cash/y22-1),maxdd_pct=100*dd,alt_trades=len(ledger),distinct_pairs=ledger.pair.nunique() if len(ledger) else 0,btc_orders=btc_orders,alt_orders=alt_orders,stops=stops,top3=list(tops.head(3).index),top3_profit=float(tops.head(3).sum()),params=dict(alt_limit=alt_limit,topn=topn,per_asset=per_asset,atr_mult=atr_mult,risk=risk,holdrank=holdrank,cost_side=fee,slip_side=slip))
 return r,ledger,nav
if __name__=='__main__':
 policies=[
  dict(name='SWAP1_TOP3_40_WIDE',alt_limit=.4,topn=3,per_asset=.20,atr_mult=5.,risk=.02,holdrank=999),
  dict(name='SWAP2_TOP3_60_WIDE',alt_limit=.6,topn=3,per_asset=.25,atr_mult=5.,risk=.025,holdrank=999),
  dict(name='SWAP3_TOP5_60_WIDE',alt_limit=.6,topn=5,per_asset=.18,atr_mult=5.,risk=.02,holdrank=999),
  dict(name='SWAP4_TOP3_60_ROTATE',alt_limit=.6,topn=3,per_asset=.25,atr_mult=5.,risk=.025,holdrank=7),
  dict(name='SWAP5_TOP5_80_WIDE',alt_limit=.8,topn=5,per_asset=.23,atr_mult=6.,risk=.03,holdrank=999),
  dict(name='SWAP6_TOP3_60_TIGHT',alt_limit=.6,topn=3,per_asset=.25,atr_mult=3.,risk=.02,holdrank=999),
 ]
 rows=[]
 for kw in policies:
  print('START',kw['name'],flush=True)
  o,tr,nv=run(**kw);rows.append(o);tr.to_csv(OUT/(kw['name']+'_TRADES.csv'),index=False);nv.to_csv(OUT/(kw['name']+'_NAV.csv'),index=False)
  print('BASE',o,flush=True)
  oo,_,_=run(**{**kw,'name':kw['name']+'_DOUBLE'},fee=.006,slip=.002);rows.append(oo)
  ox,_,_=run(**{**kw,'name':kw['name']+'_EXC3_DOUBLE'},fee=.006,slip=.002,exclude=tuple(o['top3']));rows.append(ox)
 pd.DataFrame(rows).to_csv(OUT/'SWAP_RESULTS.csv',index=False)
