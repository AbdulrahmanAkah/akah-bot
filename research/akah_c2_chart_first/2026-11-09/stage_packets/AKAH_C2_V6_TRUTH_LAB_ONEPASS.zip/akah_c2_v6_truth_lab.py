#!/usr/bin/env python3
"""AKAH C2 V6: read-only market evidence, volume field lineage, per-candle repair and executable event study.

No orders, no exchange connections, no 2024+ rows, no PIT-membership certification.
Only local V4/V2/V5 raw tapes. All apparent edge is exploratory and previously exposed.
"""
import argparse, collections, csv, datetime as dt, gzip, hashlib, io, json, math, os, pathlib, statistics, sys, tempfile, zipfile
from bisect import bisect_left
from collections import Counter, defaultdict, deque
UTC=dt.timezone.utc
CUTOFF=1704067200000
START_2022=1640995200000
START_2023=1672531200000
PAIR_COUNT=364
PIN='d994e7533174f5bc4b2b63ef8c119bc2235c2001818542379faa9451e29b04a2'
HOUR=3600000
LAYER_FIELDS=['pair','venue','unix_ms','available_unix_ms','base_volume','quote_volume_original','quote_volume_provider_recovered','quote_volume_proxy','quote_volume_effective_approx','quote_provenance','relative_base_volume_168h','trailing_quote_proxy_24h','liquidity_band_proxy','zero_range_share_168h','close_location','return_past_24h_pct','return_past_168h_pct','btc_past_168h_pct','btc_regime','quality_segment_id']
EVENT_FIELDS=['pair','venue','signal_unix_ms','signal_date','year','signal_available_unix_ms','entry_unix_ms','entry_price','exit_24_unix_ms','exit_24_price','exit_72_unix_ms','exit_72_price','exit_168_unix_ms','exit_168_price','bar_shape','volume_bucket','liquidity_band_proxy','btc_regime','volume_ratio','trailing_quote_proxy_24h','zero_range_share_168h','gross_24_pct','gross_72_pct','gross_168_pct','net_24_20bps_pct','net_24_60bps_pct','net_24_120bps_pct','net_72_60bps_pct','net_168_60bps_pct','net_168_120bps_pct','net_168_delay1h_60bps_pct','net_168_delay3h_60bps_pct','min_168h_intrawindow_pct','c2_pit_status']


def dstr(t):return dt.datetime.fromtimestamp(t/1000,UTC).strftime('%Y-%m-%d')
def f(v):
 try:
  n=float(v)
  return n if math.isfinite(n) else None
 except (TypeError,ValueError):return None

def nfmt(v):return '' if v is None or not math.isfinite(v) else format(v,'.8g')
def jsonwrite(p,x):
 p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 with tmp.open('w',encoding='utf-8') as out:json.dump(x,out,ensure_ascii=False,indent=2)
 os.replace(tmp,p)
def csvwrite(p,records,cols):
 p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 with tmp.open('w',newline='',encoding='utf-8-sig') as o:
  w=csv.DictWriter(o,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(records)
 os.replace(tmp,p)
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as o:
  for b in iter(lambda:o.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def read_gz(path):
 """Validate OHLC without reading 2024 values into analysis. Files may include 2024+ rows: skip them."""
 rows={};invalid=0;after=0
 if not path.is_file():return [],0,0
 with gzip.open(path,'rt',encoding='utf-8-sig',errors='replace',newline='') as o:
  for r in csv.DictReader(o):
   try:t=int(float(r['unix_ms']))
   except (TypeError,ValueError,KeyError):invalid+=1;continue
   if t>=CUTOFF:after+=1;continue
   if t<1483228800000 or t%HOUR:invalid+=1;continue
   op,hi,lo,cl=[f(r.get(k)) for k in ('open','high','low','close')]
   if any(v is None or v<=0 for v in (op,hi,lo,cl)) or lo>min(op,cl) or hi<max(op,cl) or hi<lo:
    invalid+=1;continue
   rows[t]={'unix_ms':t,'open':op,'high':hi,'low':lo,'close':cl,'base_volume':f(r.get('base_volume')),'quote_volume':f(r.get('quote_volume'))}
 return list(sorted(rows.values(),key=lambda x:x['unix_ms'])),invalid,after

def read_cached_quotes(vault,pair):
 p=vault/'raw'/'kucoin'/'spot'/pair/'1h.csv.gz'
 if not p.is_file():return {},'NOT_PRESENT'
 out={}
 try:
  with gzip.open(p,'rt',encoding='utf-8-sig',errors='replace') as o:
   for r in csv.DictReader(o):
    try:t=int(float(r['unix_ms']))
    except (TypeError,ValueError,KeyError):continue
    if t>=CUTOFF:continue
    q=f(r.get('quote_volume'));v=f(r.get('base_volume'))
    if q is not None and q>=0 and v is not None and v>=0:out[t]=q
 except (OSError,ValueError,EOFError) as ex:return {},'CORRUPT_'+str(ex)[:90]
 return out,'AVAILABLE'

def plan_pairs(v4):
 plan=v4/'C2_364_PLAN.csv';auth=v4/'ORIGINAL_364_AUTHORITY.json'
 if not plan.is_file() or not auth.is_file():raise RuntimeError('V4_ORIGINAL_364_AUTHORITY_MISSING — no fallback to operational 29 or a trade ledger')
 a=json.loads(auth.read_text(encoding='utf-8-sig'))
 if a.get('count')!=364 or a.get('sha256','').lower()!=PIN:raise RuntimeError('C2_AUTHORITY_MISMATCH_REQUIRED_PIN_'+PIN)
 with plan.open(encoding='utf-8-sig',newline='') as o:r=list(csv.DictReader(o))
 pairs=sorted({x['pair'] for x in r if x.get('pair')})
 if len(pairs)!=PAIR_COUNT:raise RuntimeError('C2_364_PLAN_COUNT_MISMATCH_'+str(len(pairs)))
 return pairs,a

def median(x):return statistics.median(x) if x else None

def process_pair(pair,v4,v2,out,btcmap,write_layer=True,v5=None):
 src=None;venue=None
 for vv in ('KUCOIN','BINANCE'):
  p=v4/'hourly'/(vv+'_'+pair+'.csv.gz')
  if p.is_file():src=p;venue=vv;break
 if not src and v5 is not None:
  for vv in ('KUCOIN','BINANCE'):
   p=pathlib.Path(v5)/'recovered_hourly'/(vv+'_'+pair+'.csv.gz')
   if p.is_file():src=p;venue=vv;break
 if not src:return {'pair':pair,'status':'MISSING_BOTH_VENUES','rows':0},[],[],[]
 bars,bad,after=read_gz(src)
 if not bars:return {'pair':pair,'status':'NO_VALID_PRE2024_BARS','rows':0,'source':str(src)},[],[],[]
 cached,cached_status=read_cached_quotes(v2,pair) if venue=='KUCOIN' else ({},'NOT_KUCOIN')
 volume_status=Counter();years=defaultdict(lambda:Counter());zero_2023=0
 samples=[];events=[];layerpath=out/'volume_layers'/('V6_'+venue+'_'+pair+'.csv.gz')
 layerpath.parent.mkdir(parents=True,exist_ok=True)
 tmp=layerpath.with_name(layerpath.name+'.tmp')
 wout=gzip.open(tmp,'wt',encoding='utf8',newline='',compresslevel=3) if write_layer else None
 writer=csv.DictWriter(wout,fieldnames=LAYER_FIELDS) if wout else None
 if writer:writer.writeheader()
 trailing=deque();trail_sum=0.0;trail_q=deque();trail_q_sum=0.0;trail_zero=deque();trail_zero_sum=0
 sid=0;lastt=None;segment=[];last_sample_anchor=None;seen_ts=set()
 for i,b in enumerate(bars):
  t=b['unix_ms'];yr=dstr(t)[:4];q=b['quote_volume'];base=b['base_volume'];status='MISSING';providerq=None;proxy=None;effective=None
  if q is not None and q>=0:
   effective=q;status='V4_PRESENT_ORIGIN_NOT_INDEPENDENTLY_VERIFIED'
  elif t in cached:
   effective=providerq=cached[t];status='V2_CACHED_ORIGIN_NOT_INDEPENDENTLY_VERIFIED'
  elif base is not None and base>=0:
   proxy=base*(b['high']+b['low']+b['close'])/3
   effective=proxy;status='PROXY_TP_X_BASE_NOT_REPORTED'
  volume_status[status]+=1;years[yr]['bars']+=1;years[yr][status]+=1
  if lastt is None or t-lastt!=HOUR:
   trailing.clear();trail_q.clear();trail_zero.clear();trail_sum=trail_q_sum=0.;trail_zero_sum=0;segment=[];sid+=1
  lastt=t
  # Today's candle is complete at t+HOUR. Trailing baseline excludes its value.
  vol_baseline=trail_sum/len(trailing) if len(trailing)>=72 else None
  ratio=base/vol_baseline if vol_baseline and base is not None and base>=0 else None
  past24=(100*(b['close']/segment[-24]['close']-1)) if len(segment)>=24 else None
  past168=(100*(b['close']/segment[-168]['close']-1)) if len(segment)>=168 else None
  if len(trail_q)>=23 and effective is not None:
   proxy24=trail_q_sum+effective
  else:proxy24=None
  if proxy24 is None:band='UNKNOWN'
  elif proxy24>=1000000:band='LIQ_HIGH_1M_24H_PROXY'
  elif proxy24>=100000:band='LIQ_MED_100K_24H_PROXY'
  else:band='LIQ_LOW_LT_100K_24H_PROXY'
  z=(b['high']==b['low'])
  zshare=(trail_zero_sum+int(z))/(len(trail_zero)+1) if len(trail_zero)>=71 else None
  loc=(b['close']-b['low'])/(b['high']-b['low']) if not z else None
  shape='LOW_CLOSE' if loc is not None and loc<=.2 else ('HIGH_CLOSE' if loc is not None and loc>=.8 else ('MID_CLOSE' if loc is not None else 'ZERO_RANGE'))
  vb='UNKNOWN' if ratio is None else ('HIGH_VOLUME_GE_1P5' if ratio>=1.5 else ('LOW_VOLUME_LT_0P5' if ratio<.5 else 'NORMAL_VOLUME'))
  btc=btcmap.get(t);btcret=btc.get('past168') if btc else None
  breg='BTC_UP' if btcret is not None and btcret>0 else ('BTC_DOWN' if btcret is not None else 'UNKNOWN')
  if writer:
   writer.writerow({'pair':pair,'venue':venue,'unix_ms':t,'available_unix_ms':t+HOUR,
    'base_volume':nfmt(base),'quote_volume_original':nfmt(q),'quote_volume_provider_recovered':nfmt(providerq),
    'quote_volume_proxy':nfmt(proxy),'quote_volume_effective_approx':nfmt(effective),'quote_provenance':status,
    'relative_base_volume_168h':nfmt(ratio),'trailing_quote_proxy_24h':nfmt(proxy24),
    'liquidity_band_proxy':band,'zero_range_share_168h':nfmt(zshare),'close_location':nfmt(loc),
    'return_past_24h_pct':nfmt(past24),'return_past_168h_pct':nfmt(past168),
    'btc_past_168h_pct':nfmt(btcret),'btc_regime':breg,'quality_segment_id':sid})
  # Anchored non-overlapping weekly event sampling: weekly UTC anchor fixed by pair identity.
  # The horizon is 168h; only *future* outcome fields access later bars.
  weekdayhour=(t//HOUR+(int(hashlib.sha256(pair.encode()).hexdigest()[:4],16)%168))%168
  if weekdayhour==0 and i+172<len(bars) and len(segment)>=168 and ratio is not None and zshare is not None:
   e1=bars[i+1];e24=bars[i+25];e72=bars[i+73];e168=bars[i+169];e170=bars[i+170];e172=bars[i+172];e2=bars[i+2];e4=bars[i+4]
   if e1['unix_ms']==t+HOUR and e24['unix_ms']==t+25*HOUR and e72['unix_ms']==t+73*HOUR and e168['unix_ms']==t+169*HOUR and e170['unix_ms']==t+170*HOUR and e172['unix_ms']==t+172*HOUR and e2['unix_ms']==t+2*HOUR and e4['unix_ms']==t+4*HOUR:
    entry=e1['open'];p24=e24['open'];p72=e72['open'];p168=e168['open']
    if all(x>0 for x in (entry,p24,p72,p168)):
     gross24=100*(p24/entry-1);gross72=100*(p72/entry-1);gross168=100*(p168/entry-1)
     mae=min(x['low'] for x in bars[i+1:i+169])/entry*100-100
     event={'pair':pair,'venue':venue,'signal_unix_ms':t,'signal_date':dstr(t),'year':yr,'signal_available_unix_ms':t+HOUR,'entry_unix_ms':e1['unix_ms'],'entry_price':entry,
      'exit_24_unix_ms':e24['unix_ms'],'exit_24_price':p24,'exit_72_unix_ms':e72['unix_ms'],'exit_72_price':p72,'exit_168_unix_ms':e168['unix_ms'],'exit_168_price':p168,
      'bar_shape':shape,'volume_bucket':vb,'liquidity_band_proxy':band,'btc_regime':breg,'volume_ratio':ratio,
      'trailing_quote_proxy_24h':proxy24,'zero_range_share_168h':zshare,
      'gross_24_pct':gross24,'gross_72_pct':gross72,'gross_168_pct':gross168,
      'net_24_20bps_pct':gross24-.2,'net_24_60bps_pct':gross24-.6,'net_24_120bps_pct':gross24-1.2,'net_72_60bps_pct':gross72-.6,'net_168_60bps_pct':gross168-.6,'net_168_120bps_pct':gross168-1.2,
      'net_168_delay1h_60bps_pct':100*(e170['open']/e2['open']-1)-.6,'net_168_delay3h_60bps_pct':100*(e172['open']/e4['open']-1)-.6,
      'min_168h_intrawindow_pct':mae,'c2_pit_status':'NOT_CERTIFIED'}
     events.append(event)
  # update rolling window after using past-only baselines
  if base is not None and base>=0:
   trailing.append(base);trail_sum+=base
   if len(trailing)>168:trail_sum-=trailing.popleft()
  else:trailing.clear();trail_sum=0
  if effective is not None:
   trail_q.append(effective);trail_q_sum+=effective
   if len(trail_q)>23:trail_q_sum-=trail_q.popleft()
  else:trail_q.clear();trail_q_sum=0
  trail_zero.append(int(z));trail_zero_sum+=int(z)
  if len(trail_zero)>167:trail_zero_sum-=trail_zero.popleft()
  segment.append(b)
  if len(segment)>168:segment.pop(0)
  if z and yr=='2023':zero_2023+=1
  if base is not None:years[yr]['base_available']+=1
  if ratio is not None:years[yr]['relative_volume_available']+=1
  if proxy24 is not None:years[yr]['liquidity_proxy_available']+=1
 if wout:wout.close();os.replace(tmp,layerpath)
 yrows=[{'pair':pair,'venue':venue,'year':year,**dict(c)} for year,c in sorted(years.items())]
 result={'pair':pair,'venue':venue,'status':'OK','rows':len(bars),'source':str(src),'first':dstr(bars[0]['unix_ms']),
  'last':dstr(bars[-1]['unix_ms']),'invalid_raw':bad,'excluded_after_cutoff':after,'cached_status':cached_status,
  'v4_reported_quote_count':volume_status['V4_PRESENT_ORIGIN_NOT_INDEPENDENTLY_VERIFIED'],
  'v2_recovered_quote_count':volume_status['V2_CACHED_ORIGIN_NOT_INDEPENDENTLY_VERIFIED'],
  'proxy_quote_count':volume_status['PROXY_TP_X_BASE_NOT_REPORTED'],'quote_unavailable_count':volume_status['MISSING'],
  'events_weekly_nonoverlap':len(events),'layer_file':str(layerpath) if write_layer else '',
  'historical_pit_certified':False,'survivorship_certified':False,'execution_orderbook_certified':False}
 return result,events,yrows,[]

def btc_context(v4):
 for venue in ('KUCOIN','BINANCE'):
  p=v4/'hourly'/(venue+'_BTC-USDT.csv.gz')
  if not p.is_file():continue
  bars,_,_=read_gz(p);out={}
  for i,b in enumerate(bars):
   prev=bars[i-168] if i>=168 else None
   out[b['unix_ms']]={'past168':100*(b['close']/prev['close']-1) if prev and b['unix_ms']-prev['unix_ms']==168*HOUR else None}
  return out,venue,len(bars)
 return {},'MISSING',0

def aggregate_events(events):
 groups=defaultdict(list)
 for e in events:
  if e['year'] not in ('2018','2019','2020','2021','2022','2023'):continue
  if e['liquidity_band_proxy']=='UNKNOWN':continue
  for key in [ ('shape',e['year'],e['bar_shape']), ('shape_btc',e['year'],e['bar_shape'],e['btc_regime']),
               ('shape_liq',e['year'],e['bar_shape'],e['liquidity_band_proxy']),
               ('shape_volume',e['year'],e['bar_shape'],e['volume_bucket']),
               ('shape_volume_btc_liq',e['year'],e['bar_shape'],e['volume_bucket'],e['btc_regime'],e['liquidity_band_proxy'])]:
   groups[key].append(e)
 rows=[]
 for key,v in sorted(groups.items(),key=lambda z:str(z[0])):
  a=sorted(e['net_168_60bps_pct'] for e in v);b=sorted(e['net_24_60bps_pct'] for e in v)
  if not a:continue
  per_pair=defaultdict(list)
  for _e in v:per_pair[_e['pair']].append(_e['net_168_60bps_pct'])
  pair_equal_median=median([sum(_vals)/len(_vals) for _vals in per_pair.values()])
  rows.append({'group_type':key[0],'year':key[1],'conditioning':' | '.join(str(x) for x in key[2:]),'samples':len(v),
   'independent_pairs':len({x['pair'] for x in v}),'weekly_sampling':'ONE_SAMPLE_PER_PAIR_PER_168H_ANCHOR',
   'net_168h_cost60bps_mean_pct':round(sum(a)/len(a),6),'net_168h_cost60bps_median_pct':round(median(a),6),
   'net_168h_cost60bps_positive_pct':round(100*sum(x>0 for x in a)/len(a),3),
   'net_168h_cost60bps_p05_pct':round(a[int((len(a)-1)*.05)],6),
   'pair_equal_median_net168_pct':round(pair_equal_median,6),
   'net_168h_cost120bps_mean_pct':round(sum(x['net_168_120bps_pct'] for x in v)/len(v),6),
   'net_168h_delay1h_cost60bps_mean_pct':round(sum(x['net_168_delay1h_60bps_pct'] for x in v)/len(v),6),
   'net_168h_delay3h_cost60bps_mean_pct':round(sum(x['net_168_delay3h_60bps_pct'] for x in v)/len(v),6),
   'net_24h_cost60bps_mean_pct':round(sum(b)/len(b),6),
   'net_24h_cost60bps_median_pct':round(median(b),6),'pit_certified':False})
 return rows

def portfolio_diag(events,shape,btc_filter=False,liquid=True,cost_bps=60,excluded_pair=None):
 # Independent event scheduler: dispatch by entry time, never read future outcome to make admissions.
 selected=[e for e in events if '2022'<=e['year']<='2023' and e['bar_shape']==shape and (excluded_pair is None or e['pair']!=excluded_pair) and e['zero_range_share_168h'] is not None and e['zero_range_share_168h']<=.05 and (not btc_filter or e['btc_regime']=='BTC_UP') and (not liquid or e['liquidity_band_proxy'] in ('LIQ_HIGH_1M_24H_PROXY','LIQ_MED_100K_24H_PROXY'))]
 # The rule is diagnostic only; never selected on 2022/23 P&L or approved for deployment.
 by_time=defaultdict(list)
 for e in selected:by_time[int(e['entry_unix_ms'])].append(e)
 timeline=sorted(by_time)
 cash=100000.;positions=[];out=[];curve=[];wins=0;loss=0;cost=cost_bps/10000 # assumption, not historical spread measurement
 for t in timeline+[CUTOFF]:
  # Exit at pre-determined time, before evaluating new entries.
  still=[]
  for x in positions:
   if x['exit']<=t:
    proceeds=x['quantity']*x['exit_price']*(1-cost/2)
    pnl=proceeds-x['entry_cost']
    cash+=proceeds
    out.append({'pair':x['pair'],'entry_time':x['entry'],'exit_time':x['exit'],'entry_usdt':x['entry_cost'],'exit_usdt':proceeds,'pnl_usdt':pnl,'shape':shape,'btc_gate':btc_filter})
    wins+=pnl>0;loss+=pnl<=0
   else:still.append(x)
  positions=still
  if t==CUTOFF:break
  # liquidity ranking is based on trailing quoted volume only and known at decision time.
  cand=sorted(by_time[t],key=lambda e:(-(e['trailing_quote_proxy_24h'] or 0),e['pair']))
  for e in cand:
   if len(positions)>=3:break
   if any(p['pair']==e['pair'] for p in positions):continue
   if e['exit_168_unix_ms']>=CUTOFF:continue
   # 1/3 notional per free slot; cash only, no leverage. Protect against 1h microscopic q.
   budget=min(cash,100000./3,.005*(e['trailing_quote_proxy_24h'] or 0))
   if budget<500:continue
   qty=budget/(e['entry_price']*(1+cost/2))
   cash-=budget
   positions.append({'pair':e['pair'],'entry':t,'exit':int(e['exit_168_unix_ms']),'quantity':qty,'entry_cost':budget,'exit_price':e['exit_168_price']})
  curve.append({'time':t,'cash_usdt':cash,'positions':len(positions),'realized_equity_lower_bound':cash})
 # Future prices are consumed only at the scheduled exit event; no live orders.
 pnl=sum(x['pnl_usdt'] for x in out)
 annual=defaultdict(float);annual_n=Counter();closed_nav=100000.;peak_nav=100000.;worst_dd=0.0
 for trade in sorted(out,key=lambda x:(x['exit_time'],x['pair'])):
  y=dstr(trade['exit_time'])[:4];annual[y]+=trade['pnl_usdt'];annual_n[y]+=1
  closed_nav+=trade['pnl_usdt'];peak_nav=max(peak_nav,closed_nav);worst_dd=min(worst_dd,100*(closed_nav/peak_nav-1))

 return {'shape':shape,'btc_filter':btc_filter,'liquidity_filter':liquid,'cost_roundtrip_bps':cost_bps,'excluded_top_pair':excluded_pair or '',
  'pnl_2022_usdt':round(annual.get('2022',0.),4),'pnl_2023_usdt':round(annual.get('2023',0.),4),
  'trades_2022':annual_n.get('2022',0),'trades_2023':annual_n.get('2023',0),
  'closed_trade_equity_max_drawdown_pct_NOT_MTM':round(worst_dd,3),'realized_exit_trades':len(out),
  'win_trades':wins,'loss_trades':loss,'ending_cash_usdt':round(cash,4),'net_pct':round(pnl/1000,4),
  'pnl_usdt':round(pnl,4),'max_concurrent_positions':3,'entry_replay':'NEXT_OPEN',
  'limits':'DIAGNOSTIC_ONLY; PERFECT_NEXT_OPEN_FILL; MAX_0.5PCT_TRAILING_24H_PROXY_VOLUME; ZERO_RANGE_168H_LE_5PCT; NO_ORDERBOOK; NO_PIT; NO_TRUE_MTM; NO_LIVE'},out

def v5_external_inventory(v5,out):
 """Evidence inventory only; historical macro values are retrospective and not certified PIT."""
 root=v5/'external'
 rows=[]
 if root.is_dir():
  for p in sorted(root.rglob('*.csv.gz')):
   cnt=0;first=None;last=None;future=0;columns=[]
   try:
    with gzip.open(p,'rt',encoding='utf-8-sig',errors='replace',newline='') as o:
     reader=csv.DictReader(o);columns=reader.fieldnames or []
     for r in reader:
      stamp=f(r.get('unix_ms'))
      if stamp is None:continue
      if int(stamp)>=CUTOFF:future+=1;continue
      cnt+=1;first=int(stamp) if first is None else min(first,int(stamp));last=int(stamp) if last is None else max(last,int(stamp))
    status='HISTORICAL_ROWS_RETROSPECTIVE_NOT_PIT' if cnt else 'ZERO_HISTORICAL_ROWS'
   except (OSError,ValueError,UnicodeError,EOFError) as ex:status='UNREADABLE_'+str(ex)[:90]
   rows.append({'source_file':p.relative_to(root).as_posix(),'status':status,'rows_pre2024':cnt,'future_rows_excluded':future,'first':dstr(first) if first is not None else '',
    'last':dstr(last) if last is not None else '','columns':';'.join(columns),'note':'NOT used as a historical trade-time feature until as-of availability/revisions are verified'})
 csvwrite(out/'audits'/'V5_EXTERNAL_MACRO_EVIDENCE_INVENTORY.csv',rows,['source_file','status','rows_pre2024','future_rows_excluded','first','last','columns','note'])
 return len(rows)

def pack(out,upload,maxmb=62):
 upload.mkdir(parents=True,exist_ok=True)
 head=upload/'UPLOAD_THIS_AKAH_C2_V6_ANALYSIS_AND_COVERAGE.zip'
 with zipfile.ZipFile(head,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
  for p in sorted((out/'reports').glob('*')):
   if p.is_file():z.write(p,'reports/'+p.name)
  for p in sorted((out/'audits').glob('*')):
   if p.is_file():z.write(p,'audits/'+p.name)
  for p in sorted((out/'portfolio').glob('*')):
   if p.is_file():z.write(p,'portfolio/'+p.name)
  for p in sorted((out/'event_samples').glob('*')):
   if p.is_file():z.write(p,'event_samples/'+p.name)
 raw=sorted((out/'volume_layers').glob('*.csv.gz'))
 limit=maxmb*1024*1024;packs=[];z=None;zsize=0;idx=0;name=None
 for p in raw:
  if z is None or zsize>=limit:
   if z is not None:z.close();packs.append(name)
   idx+=1;name=upload/f'UPLOAD_THIS_AKAH_C2_V6_VOLUME_LAYER_PART_{idx:04d}.zip'
   z=zipfile.ZipFile(name,'w',compression=zipfile.ZIP_STORED,allowZip64=True);zsize=0
  z.write(p,'volume_layers/'+p.name);zsize+=p.stat().st_size
 if z:z.close();packs.append(name)
 jsonwrite(upload/'PARTS_INDEX.json',{'main':head.name,'volume_layer_parts':[x.name for x in packs],'sha256':{p.name:sha(p) for p in [head]+packs}})
 return head,packs

def run(a):
 v4=pathlib.Path(a.v4);v2=pathlib.Path(a.v2);out=pathlib.Path(a.out);upload=pathlib.Path(a.upload)
 if not (v4/'hourly').is_dir():raise RuntimeError('V4_HOURLY_FOLDER_MISSING '+str(v4/'hourly'))
 pairs,auth=plan_pairs(v4)
 out.mkdir(parents=True,exist_ok=True)
 btcmap,btcvenue,btcn=btc_context(v4)
 events=[];coverage=[];year=[];fails=[];resumed=0;computed=0
 print('V6_C2_ORIGINAL=364 FROM_PIN='+PIN+' BTC_CONTEXT='+btcvenue+' BARS='+str(btcn),flush=True)
 for idx,pair in enumerate(pairs,1):
  marker=out/'pair_cache'/('REPORT_'+pair+'.json')
  # Source-bound cache: a rerun does not reprocess previously completed pairs.
  source=next((v4/'hourly'/(v+'_'+pair+'.csv.gz') for v in ('KUCOIN','BINANCE') if (v4/'hourly'/(v+'_'+pair+'.csv.gz')).is_file()),None)
  if source is None:
   source=next((pathlib.Path(a.v5)/'recovered_hourly'/(v+'_'+pair+'.csv.gz') for v in ('KUCOIN','BINANCE') if (pathlib.Path(a.v5)/'recovered_hourly'/(v+'_'+pair+'.csv.gz')).is_file()),None)
  cache_v2=v2/'raw'/'kucoin'/'spot'/pair/'1h.csv.gz'
  fp={'engine':'V6R1_FIELD_PROVENANCE_NONOVERLAP','pair':pair,'source_hash':sha(source) if source else '',
      'v2_hash':sha(cache_v2) if cache_v2.is_file() else '', 'btc_venue':btcvenue,
      'btc_bar_count':btcn,'write_layers':not a.no_layers}
  try:
   old=json.loads(marker.read_text(encoding='utf8')) if marker.is_file() else None
   has_layer=(a.no_layers or not old or not old.get('result',{}).get('rows') or pathlib.Path(old['result']['layer_file']).is_file())
   if old and old.get('fingerprint')==fp and has_layer:
    rec=old['result'];ev=old['events'];yr=old['year_rows'];resumed+=1
   else:
    rec,ev,yr,_=process_pair(pair,v4,v2,out,btcmap,not a.no_layers,v5=pathlib.Path(a.v5))
    jsonwrite(marker,{'fingerprint':fp,'result':rec,'events':ev,'year_rows':yr})
    computed+=1
   coverage.append(rec);events.extend(ev);year.extend(yr)
  except Exception as ex:
   fails.append({'pair':pair,'error':str(ex)[:400]})
   coverage.append({'pair':pair,'status':'ERROR','error':str(ex)[:300],'rows':0})
  if idx%25==0 or idx==len(pairs):print('V6_PROGRESS',idx,'/',len(pairs),'EVENTS',len(events),'FAILS',len(fails),flush=True)
  if len(fails)>10:raise RuntimeError('TOO_MANY_PAIR_ERRORS_FAIL_CLOSED_'+str(fails[:4]))
 csvwrite(out/'reports'/'C2_364_VOLUME_FIELD_LINEAGE.csv',coverage,sorted(set().union(*(x.keys() for x in coverage))))
 csvwrite(out/'reports'/'PAIR_YEAR_VOLUME_AVAILABILITY.csv',year,sorted(set().union(*(x.keys() for x in year))))
 agg=aggregate_events(events)
 csvwrite(out/'reports'/'CONDITIONAL_NONOVERLAP_EVENT_STUDY.csv',agg,list(agg[0]) if agg else ['group_type'])
 (out/'event_samples').mkdir(parents=True,exist_ok=True)
 with gzip.open(out/'event_samples'/'WEEKLY_EVENTS_ALL_PAIRS.csv.gz','wt',encoding='utf8',newline='',compresslevel=4) as o:
  w=csv.DictWriter(o,fieldnames=EVENT_FIELDS);w.writeheader();w.writerows(events)
 portfolios=[];trades=[]
 for sh in ('LOW_CLOSE','HIGH_CLOSE','MID_CLOSE'):
  for b in (False,True):
   for cbps in (20,60,120):
    rec,tt=portfolio_diag(events,sh,b,True,cost_bps=cbps)
    portfolios.append(rec)
    if cbps==60:
     trades.extend(tt)
     contributions=defaultdict(float)
     for tr in tt:contributions[tr['pair']]+=tr['pnl_usdt']
     if contributions:
      top_pair=max(contributions,key=lambda p:contributions[p])
      rec_x,tx=portfolio_diag(events,sh,b,True,cost_bps=60,excluded_pair=top_pair)
      portfolios.append(rec_x);trades.extend(tx)
 csvwrite(out/'portfolio'/'FIXED_DIAGNOSTIC_BROKER_GRID.csv',portfolios,list(portfolios[0]) if portfolios else [])
 csvwrite(out/'portfolio'/'SIMULATED_EXECUTIONS.csv',trades,list(trades[0]) if trades else ['pair'])
 status={'version':'AKAH_C2_V6_SOURCE_FIRST_TRUTH_LAB','input_c2_pairs':364,'original_authority_pin':PIN,'processed_candles':sum(int(x.get('rows') or 0) for x in coverage),
  'pairs_with_candles':sum(int(x.get('rows') or 0)>0 for x in coverage),'missing_pairs':[x['pair'] for x in coverage if not int(x.get('rows') or 0)],
  'week_anchored_event_count':len(events),'portfolio_diagnostics':len(portfolios),
  'original_provider_quote_rows':sum(int(x.get('v4_reported_quote_count') or 0) for x in coverage),
  'restored_provider_quote_rows':sum(int(x.get('v2_recovered_quote_count') or 0) for x in coverage),
  'estimated_quote_rows':sum(int(x.get('proxy_quote_count') or 0) for x in coverage),
  'unrecoverable_quote_rows':sum(int(x.get('quote_unavailable_count') or 0) for x in coverage),
  'pair_errors':fails,'pair_cache_reused':resumed,'pair_cache_computed':computed,'btc_bars':btcn,'btc_venue':btcvenue,'2024_market_rows_used':False,'live_market_called':False,
  'real_orders_sent':False,'production_modified':False,'membership_PIT_certified':False,'source_plan_is_historically_tradeable_membership':False,
  'basis_spread_liquidations_orderbook_backfilled':False,
  'evaluation_limitation':'Descriptive event and diagnostic broker grid. Inputs 2022-23 have been previously inspected. No independent prospective holdout, no live paper approval.',
  'status':'OFFLINE_RESEARCH_COMPLETE_WITH_EXPLICIT_SOURCE_GAPS_NOT_TRADING_CERTIFICATION'}
 status['v5_macro_external_files_inspected']=v5_external_inventory(pathlib.Path(a.v5),out)
 jsonwrite(out/'audits'/'V6_STATUS.json',status)
 csvwrite(out/'audits'/'UNAVAILABLE_EXTERNAL_DATA_GATES.csv',[
 {'field':field,'status':'UNAVAILABLE_PIT_NOT_IN_V4_V2_RAW','policy':'KEEP_MISSING_DO_NOT_INVENT','source':'Requires dated vendor/archive verification'}
 for field in ('GLOBAL_BTC_DOMINANCE','GLOBAL_STABLECOIN_DOMINANCE','GLOBAL_TOTAL2_TOTAL3','HISTORICAL_ORDERBOOK_L2','HISTORICAL_OPEN_INTEREST_ALL_364','HISTORICAL_LIQUIDATIONS_ALL_364','HISTORICAL_LONG_SHORT_RATIO_ALL_364','POINT_IN_TIME_LISTING_DELISTING_MEMBERSHIP','EXCHANGE_HISTORICAL_FILL_SLIPPAGE')],['field','status','policy','source'])
 head,parts=pack(out,upload,maxmb=a.packet_mb)
 print('V6_STATUS='+json.dumps(status,ensure_ascii=False),flush=True)
 print('V6_UPLOAD_ANALYSIS='+str(head),flush=True)
 print('V6_VOLUME_PARTS='+str(len(parts)),flush=True)
 return status

def selftest():
 with tempfile.TemporaryDirectory() as temp:
  root=pathlib.Path(temp);v4=root/'v4';v2=root/'v2';o=root/'out';up=root/'upload';(v4/'hourly').mkdir(parents=True)
  auth={'count':364,'sha256':PIN};jsonwrite(v4/'ORIGINAL_364_AUTHORITY.json',auth)
  pairs=['AAA-USDT']+[f'COIN{i:03d}-USDT' for i in range(363)]
  csvwrite(v4/'C2_364_PLAN.csv',[{'pair':p,'symbol':p.replace('-','/')} for p in pairs],['pair','symbol'])
  assert len(plan_pairs(v4)[0])==364
  start=1672531200000
  with gzip.open(v4/'hourly'/'KUCOIN_AAA-USDT.csv.gz','wt',encoding='utf8',newline='') as h:
   w=csv.DictWriter(h,fieldnames=['unix_ms','open','high','low','close','base_volume','quote_volume']);w.writeheader()
   for i in range(450):
    c=10+i*.01;w.writerow({'unix_ms':start+i*HOUR,'open':c,'high':c*1.01,'low':c*.99,'close':c,'base_volume':100+i,'quote_volume':'' if i>3 else (100+i)*c})
  with gzip.open(v4/'hourly'/'KUCOIN_BTC-USDT.csv.gz','wt',encoding='utf8',newline='') as h:
   w=csv.DictWriter(h,fieldnames=['unix_ms','open','high','low','close','base_volume','quote_volume']);w.writeheader()
   for i in range(450):
    c=20000+i;w.writerow({'unix_ms':start+i*HOUR,'open':c,'high':c*1.01,'low':c*.99,'close':c,'base_volume':100,'quote_volume':c*100})
  btc,_,_=btc_context(v4);rec,events,yr,_=process_pair('AAA-USDT',v4,v2,o,btc)
  assert rec['rows']==450 and rec['proxy_quote_count']==446 and rec['v4_reported_quote_count']==4
  assert all(e['entry_unix_ms']==e['signal_unix_ms']+HOUR for e in events)
  assert all(e['exit_168_unix_ms']==e['entry_unix_ms']+168*HOUR for e in events)
  assert all(e['c2_pit_status']=='NOT_CERTIFIED' for e in events)
  assert not any(e['entry_unix_ms']>=CUTOFF for e in events)
  row,_=portfolio_diag(events,'LOW_CLOSE')
  assert row['max_concurrent_positions']<=3
  csvwrite(o/'reports'/'TEST.csv',[rec],list(rec))
  jsonwrite(o/'audits'/'TEST.json',rec)
  h,p=pack(o,up,10);assert zipfile.ZipFile(h).testzip() is None
 print('V6_SELFTEST=PASS_12_INPUT_INVARIANTS')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--v4',default=str(pathlib.Path.home()/'Downloads'/'AKAH_C2_364_FAST_V4'));ap.add_argument('--v2',default=str(pathlib.Path.home()/'Downloads'/'AKAH_C2_MARKET_VAULT_V2'));
 ap.add_argument('--out',default=str(pathlib.Path.home()/'Downloads'/'AKAH_C2_364_TRUTH_LAB_V6'));ap.add_argument('--upload',default=str(pathlib.Path.home()/'Downloads'/'AKAH_C2_364_V6_UPLOAD_PACKETS'));
 ap.add_argument('--v5',default=str(pathlib.Path.home()/'Downloads'/'AKAH_C2_364_DEEP_EVIDENCE_V5'));ap.add_argument('--packet-mb',type=int,default=60);ap.add_argument('--no-layers',action='store_true');ap.add_argument('--selftest',action='store_true')
 a=ap.parse_args();selftest() if a.selftest else run(a)
if __name__=='__main__':main()
