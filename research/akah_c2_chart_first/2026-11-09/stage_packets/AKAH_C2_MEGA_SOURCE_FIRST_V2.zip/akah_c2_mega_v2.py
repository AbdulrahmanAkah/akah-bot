#!/usr/bin/env python3
"""AKAH C2 market-evidence vault V2: data first, no trading, pre-2024 only.
Run from owner's Windows terminal. Standard library only. Never import project scripts.

Source caveat: C2 operational membership from RD18 is a research authority
candidate, not independent point-in-time exchange eligibility certification.
Traded-symbol ledgers are never accepted as membership registries.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, gzip, hashlib, html, io, importlib.util, json, math, os, pathlib, re, shutil, statistics, sys, time, urllib.error, urllib.parse, urllib.request, zipfile
from collections import Counter, defaultdict
from decimal import Decimal
UTC=dt.timezone.utc
BEGIN=dt.datetime(2011,1,1,tzinfo=UTC)
ARCHIVE_BEGIN=dt.datetime(2017,1,1,tzinfo=UTC)
CUTOFF=dt.datetime(2024,1,1,tzinfo=UTC)
CUT_S=int(CUTOFF.timestamp())
CUT_MS=CUT_S*1000
VERSION='AKAH_C2_MARKET_EVIDENCE_MEGA_V2'
SOURCE_TABLE=pathlib.Path('data/research/rd18_p3x_a3_inputs/c2-operational-membership.csv')
UA='AKAH-C2-market-evidence-research/2.0 (read-only)'
PAIR_RE=re.compile(r'^([A-Z0-9]{2,26})-(USDT|USDC|BTC|ETH)$')
DATE_NAMES={'date','day','asof','as_of','as_of_date','asof_date','timestamp','event_time','utc_date','observed_at','decision_time','valid_from','effective_at','trade_date','signal_date','candle_time','time','hour','dt'}
PAIR_NAMES=['symbol','pair','market','instrument','ticker','trading_pair','base_quote','market_symbol','base_asset']
C2_NAMES=['universe','universe_id','universe_name','cohort','cohort_id','universe_code','portfolio_universe']
FIELDS=['unix_ms','open','high','low','close','base_volume','quote_volume','trade_count','taker_buy_quote_volume']
NOW=dt.datetime.now(UTC).isoformat()

def iso(ts):return dt.datetime.fromtimestamp(ts,UTC).isoformat().replace('+00:00','Z')
def stamp_to_s(v):
 if v is None:return None
 s=str(v).strip()
 if not s:return None
 try:
  if re.fullmatch(r'\d+(?:\.\d+)?',s):
   q=float(s)
   if q>1e14:q/=1e6
   elif q>1e11:q/=1e3
   return int(q) if 631152000 <=q <= CUT_S+4*365*86400 else None
  s=s.replace('Z','+00:00');v=dt.datetime.fromisoformat(s)
  if v.tzinfo is None:v=v.replace(tzinfo=UTC)
  return int(v.timestamp())
 except (ValueError,TypeError,OverflowError):return None

def norm_pair(v):
 if v is None:return None
 s=str(v).upper().strip().replace('/','-').replace('_','-').replace(' ','')
 if not re.fullmatch(r'[A-Z0-9-]+',s):return None
 for q in ('USDT','USDC','BTC','ETH'):
  if s.endswith(q) and not s.endswith('-'+q):s=s[:-len(q)]+'-'+q;break
 return s if PAIR_RE.fullmatch(s) else None

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def dump(path,value):
 path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 p=path.with_name(path.name+'.part')
 with p.open('w',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False,default=str);f.write('\n')
 os.replace(p,path)

def write_csv(path,items,fields):
 path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(items)

def sample_csv(path,n=10):
 with path.open('r',encoding='utf-8-sig',errors='replace',newline='') as f:
  r=csv.DictReader(f);return r.fieldnames or [],[x for _,x in zip(range(n),r)]

def source_authority(repo,out,downloads=None):
 """Select ONLY explicitly named operational C2 membership source; no trade-ledger union.
 Different C2-shaped trade reports are evidence but not authority. Resolve what is
 extractable while recording noncertification, rather than blocking all market collection.
 """
 target=repo/SOURCE_TABLE
 result={'primary_source':str(target),'authority_class':'RESEARCH_C2_OPERATIONAL_MEMBERSHIP_NOT_HISTORICAL_PIT_CERTIFICATION',
         'source_exists':target.is_file(),'c2_pair_membership_proof':'UNRESOLVED','members':[],
         'point_in_time_certified':False,'conflicts_not_used_for_symbol_selection':[],
         'excluded_2024_or_later_metadata_rows':0,'timestamp_field':None}
 if not target.is_file():
  result['status']='PRIMARY_MEMBERSHIP_FILE_MISSING';return result
 result['source_sha256']=sha(target)
 cols,ex=sample_csv(target,12);result['columns']=cols
 lc={x.strip().lower():x for x in cols if x}
 pcols=[lc[k] for k in PAIR_NAMES if k in lc];ucols=[lc[k] for k in C2_NAMES if k in lc]
 dates=[lc[k] for k in DATE_NAMES if k in lc]
 result['timestamp_field']=dates[0] if dates else None
 if not pcols:
  result['status']='PRIMARY_MEMBERSHIP_PAIR_COLUMN_MISSING';result['evidence_sample']=ex[:3];return result
 # Only primary membership, no outcome or asset-performance files.
 members=set();rows=0;used=0;examples=[];days=defaultdict(set);date_valid=0;bad=0
 with target.open('r',encoding='utf-8-sig',errors='replace',newline='') as f:
  reader=csv.DictReader(f)
  for row in reader:
   rows+=1
   if ucols and not any(str(row.get(k,'')).strip().upper()=='C2' for k in ucols):continue
   symbol=next((norm_pair(row.get(k)) for k in pcols if norm_pair(row.get(k))),None)
   if not symbol:bad+=1;continue
   st=next((stamp_to_s(row.get(k)) for k in dates if stamp_to_s(row.get(k)) is not None),None)
   if st is not None:
    date_valid+=1
    if st>=CUT_S:
     result['excluded_2024_or_later_metadata_rows']+=1;continue
    days[symbol].add(dt.datetime.fromtimestamp(st,UTC).strftime('%Y-%m-%d'))
   # Only explicit eligibility exclusions; unknown flags never guessed.
   for field in ('is_eligible','eligible','is_member','membership'):
    if field in lc and str(row.get(lc[field],'')).strip().lower() in ('false','0','no','excluded','ineligible'):
     symbol=None;break
   if not symbol:continue
   members.add(symbol);used+=1
   if len(examples)<15:examples.append({'pair':symbol,'asof_pre2024':iso(st) if st is not None else None})
 result.update({'scanned_rows':rows,'C2_membership_rows_pre2024':used,'invalid_symbol_rows':bad,
                'records_with_parseable_date':date_valid,'members':sorted(members),'member_count':len(members),
                'date_observation_count':sum(len(v) for v in days.values()),'sample_safe':examples,
                'membership_observed_first_and_last':{p:{'first':min(d),'last':max(d),'observations':len(d)} for p,d in days.items() if d}})
 # Explicit authority remains an operational candidate: no certification from output.
 result['status']='C2_PRIMARY_OPERATIONAL_CANDIDATE_EXTRACTED_NOT_PIT_CERTIFIED' if members else 'C2_PRIMARY_FILE_EMPTY_AFTER_PRE2024_SCOPE'
 result['c2_pair_membership_proof']='PRIMARY_NAMED_C2_SOURCE_ROWS_ONLY' if members else 'UNRESOLVED'
 # Preserve ambiguity from earlier audit, without using it to add or remove members.
 if downloads:
  cand=downloads/'AKAH_C2_CANDIDATE_SYMBOL_SETS.csv'
  if cand.is_file():
   with cand.open(encoding='utf-8-sig',newline='',errors='replace') as f:
    r=csv.DictReader(f)
    for row in r:
     p=row.get('path','').lower()
     if any(w in p for w in ('trade-ledger','_trades.csv','expanded_universe_trades.csv','asset-attribution')):
      if len(result['conflicts_not_used_for_symbol_selection'])<16:
       result['conflicts_not_used_for_symbol_selection'].append({'source':row.get('path'), 'pair_count':row.get('symbol_count'),'reason':'TRADES_NOT_MEMBERSHIP'})
 return result

class Journal:
 def __init__(self,work,cap_gb=30):
  self.work=pathlib.Path(work);self.work.mkdir(parents=True,exist_ok=True)
  self.log=self.work/'RETRIEVAL_JOURNAL.jsonl';self.records={};self.total_new=0;self.cap=int(cap_gb*1024**3)
  self.consecutive_network_errors=0
  raw=self.work/'raw'
  if raw.exists():
   self.total_new=sum(p.stat().st_size for p in raw.rglob('*') if p.is_file())
  if self.log.exists():
   with self.log.open(encoding='utf-8',errors='replace') as f:
    for line in f:
     try:
      v=json.loads(line);self.records[v['key']]=v
     except:pass
 def record(self,key,**kw):
  obj={'key':key,'at_utc':dt.datetime.now(UTC).isoformat(),**kw}
  self.records[key]=obj
  with self.log.open('a',encoding='utf-8') as f:f.write(json.dumps(obj,ensure_ascii=False,default=str)+'\n')
 def available(self,expected_bytes=0):
  # Permanent disk reserve, no silent corruption or runaway disk use.
  try:free=shutil.disk_usage(self.work).free
  except:free=10**12
  return self.total_new+expected_bytes <=self.cap and free>= (2*1024**3 + expected_bytes)

def get_json(url,tries=3):
 for k in range(tries):
  try:
   req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/json'})
   with urllib.request.urlopen(req,timeout=35) as resp:return json.load(resp)
  except urllib.error.HTTPError as e:
   if e.code in (400,404,403):raise
   if k>=tries-1:raise
  except (urllib.error.URLError,ValueError,TimeoutError,OSError):
   if k>=tries-1:raise
  time.sleep(min(10,2**k))

def download_archive(journal,url,dest,key,validate_zip=True):
 dest=pathlib.Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.is_file() and (not validate_zip or zipfile.is_zipfile(dest)):
  return 'CACHED'
 if dest.exists():dest.unlink()
 prev=journal.records.get(key,{})
 if prev.get('status')=='NOT_PUBLISHED_404':return 'NOT_PUBLISHED_404'
 if journal.consecutive_network_errors>=8:
  journal.record(key,status='NETWORK_CIRCUIT_BREAKER_CHECK_CONNECTIVITY_THEN_RESUME',url=url)
  return 'NETWORK_CIRCUIT_BREAKER_CHECK_CONNECTIVITY_THEN_RESUME'
 if not journal.available():
  journal.record(key,status='DISK_OR_ARCHIVE_BUDGET_EXHAUSTED',url=url);return 'DISK_OR_ARCHIVE_BUDGET_EXHAUSTED'
 for try_no in range(3):
  temp=dest.with_name(dest.name+'.part')
  try:
   req=urllib.request.Request(url,headers={'User-Agent':UA})
   with urllib.request.urlopen(req,timeout=60) as resp:
    size=int(resp.headers.get('Content-Length','0') or 0)
    if size and not journal.available(size):
     journal.record(key,status='DISK_OR_ARCHIVE_BUDGET_EXHAUSTED',url=url,declared_bytes=size)
     return 'DISK_OR_ARCHIVE_BUDGET_EXHAUSTED'
    with temp.open('wb') as f:
     while True:
      chunk=resp.read(1<<19)
      if not chunk:break
      if not journal.available(len(chunk)):
       raise RuntimeError('DISK_OR_ARCHIVE_BUDGET_EXHAUSTED_DURING_DOWNLOAD')
      f.write(chunk)
   if validate_zip:
    with zipfile.ZipFile(temp) as z:
     if z.testzip() is not None:raise ValueError('ARCHIVE_CRC_FAILED')
   os.replace(temp,dest);journal.total_new+=dest.stat().st_size
   journal.consecutive_network_errors=0
   journal.record(key,status='DOWNLOADED',url=url,size_bytes=dest.stat().st_size,sha256=sha(dest))
   return 'DOWNLOADED'
  except urllib.error.HTTPError as e:
   if temp.exists():temp.unlink()
   if e.code==404:
    journal.consecutive_network_errors=0
    journal.record(key,status='NOT_PUBLISHED_404',url=url)
    return 'NOT_PUBLISHED_404'
   err=f'HTTP_{e.code}'
  except Exception as e:
   if temp.exists():temp.unlink()
   err=str(e)[:220]
   if 'BUDGET_EXHAUSTED' in err:
    journal.record(key,status=err,url=url);return err
  if try_no<2:time.sleep(min(12,2**(try_no+1)))
 journal.consecutive_network_errors+=1
 journal.record(key,status='NETWORK_OR_VALIDATION_ERROR',url=url,error=err)
 return 'NETWORK_OR_VALIDATION_ERROR'

def months(start=ARCHIVE_BEGIN,end=CUTOFF):
 y,m=start.year,start.month
 while (y,m)<(end.year,end.month):
  yield f'{y}-{m:02d}'
  m+=1
  if m==13:m=1;y+=1

def get_months(journal,base,root,pairs,kind,interval):
 """Download monthly public exchange archives; failed 404 is an explicit gap."""
 status=Counter()
 for symbol in pairs:
  b=symbol.replace('-','')
  for mo in months():
   if kind=='spot':
    url=f'https://data.binance.vision/data/spot/monthly/klines/{b}/{interval}/{b}-{interval}-{mo}.zip'
    rel=pathlib.Path('binance')/'spot'/'klines'/b/interval/(b+'-'+interval+'-'+mo+'.zip')
   elif kind=='futures_um':
    url=f'https://data.binance.vision/data/futures/um/monthly/klines/{b}/{interval}/{b}-{interval}-{mo}.zip'
    rel=pathlib.Path('binance')/'futures_um'/'klines'/b/interval/(b+'-'+interval+'-'+mo+'.zip')
   elif kind=='aggTrades':
    url=f'https://data.binance.vision/data/spot/monthly/aggTrades/{b}/{b}-aggTrades-{mo}.zip'
    rel=pathlib.Path('binance')/'spot'/'aggTrades'/b/(b+'-aggTrades-'+mo+'.zip')
   else:raise ValueError(kind)
   key=f'archive/{kind}/{b}/{interval}/{mo}'
   res=download_archive(journal,url,root/rel,key)
   status[res]+=1
  print('ARCHIVE',kind,interval,symbol,dict(status),flush=True)
  if journal.consecutive_network_errors>=8:break
 return dict(status)

def kucoin_pair(journal,root,pair,interval):
 # 1200 candles/request (KuCoin documented maximum 1500); never extrapolate empty candles.
 sec=3600 if interval=='1hour' else 86400
 step=sec*1200
 dest=root/'kucoin'/'spot'/pair/(interval+'.csv.gz')
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():return {'status':'CACHED','rows':None}
 arr={};attempts=0;errors=0;empty=0
 for start in range(int(ARCHIVE_BEGIN.timestamp()),CUT_S,step):
  end=min(CUT_S-1,start+step-1)
  params=urllib.parse.urlencode({'symbol':pair,'type':interval,'startAt':start,'endAt':end})
  url='https://api.kucoin.com/api/v1/market/candles?'+params
  key=f'kucoin/{pair}/{interval}/{start}'
  try:
   data=get_json(url);attempts+=1
   if str(data.get('code'))!='200000':raise ValueError('KUCOIN_API_'+str(data.get('code')))
   bars=data.get('data') or []
   if not bars:empty+=1
   for v in bars:
    t=int(v[0]);
    if not int(ARCHIVE_BEGIN.timestamp())<=t<CUT_S:continue
    arr[t]=[t*1000,*[float(v[j]) for j in (1,3,4,2,5,6)],None,None]
   journal.record(key,status='OK',bars=len(bars))
  except Exception as e:
   errors+=1;journal.record(key,status='ERROR',error=str(e)[:180])
   if errors>=5 and not arr:break
  time.sleep(.10)
 if arr:
  with gzip.open(dest,'wt',encoding='utf-8',newline='') as f:
   w=csv.writer(f);w.writerow(FIELDS)
   for t in sorted(arr):w.writerow(arr[t])
 return {'status':'OK' if arr else 'NO_ROWS','rows':len(arr),'requests':attempts,'errors':errors,'empty_blocks':empty,'sha256':sha(dest) if dest.exists() else None}

def funding_pair(journal,root,pair):
 """Binance USD-M funding rates. Funding is not open interest nor spot liquidity."""
 b=pair.replace('-','');dest=root/'binance'/'futures_um'/'fundingRate'/(b+'.csv.gz')
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():return {'status':'CACHED'}
 start=int(dt.datetime(2019,1,1,tzinfo=UTC).timestamp()*1000);end=CUT_MS-1
 rows={};bad=0;n=0
 while start<end:
  query=urllib.parse.urlencode({'symbol':b,'startTime':start,'endTime':end,'limit':1000})
  url='https://fapi.binance.com/fapi/v1/fundingRate?'+query
  try:
   data=get_json(url);n+=1
   if not isinstance(data,list):raise ValueError('INVALID_FUNDING_RESPONSE')
   if not data:break
   last=start
   for item in data:
    ts=int(item.get('fundingTime',0))
    if ts>=CUT_MS or ts<start:continue
    rows[ts]=[ts,item.get('fundingRate'),item.get('markPrice')]
    last=max(last,ts)
   if last<=start:break
   start=last+1
   if len(data)<1000:break
  except Exception as e:
   bad+=1;journal.record(f'funding/{b}/{start}',status='ERROR',error=str(e)[:150]);break
  time.sleep(.15)
 if rows:
  with gzip.open(dest,'wt',encoding='utf-8',newline='') as f:
   w=csv.writer(f);w.writerow(['unix_ms','funding_rate','mark_price'])
   for t in sorted(rows):w.writerow(rows[t])
 return {'status':'OK' if rows else 'NOT_AVAILABLE','rows':len(rows),'requests':n,'errors':bad,'sha256':sha(dest) if dest.exists() else None}

def defillama(journal,root):
 """Do not fetch unbounded API datasets that would read sealed 2024+ records.
 These sources are valid market-context sources but provide full-history payloads
 without a documented end-time cutoff. Strict research boundary prevails.
 """
 candidates={'stablecoin_supply':'https://api.llama.fi/stablecoincharts/all',
             'defi_total_tvl':'https://api.llama.fi/charts'}
 out={}
 for name,url in candidates.items():
  out[name]={'status':'NOT_FETCHED_STRICT_PRE2024_BOUNDARY',
             'reason':'API returns full unbounded dataset including 2024+; no verified endAt filter',
             'source':url}
  journal.record('market_context/'+name,**out[name])
 return out

def bitstamp_btc(journal,root):
 """Supplementary BTC/USD daily price history before Binance launched; NOT same venue as C2."""
 dest=root/'market_context'/'bitstamp_BTCUSD_daily_pre2024.csv.gz'
 if dest.exists():return {'status':'CACHED'}
 rows={};bad=0;pages=0;step=86400
 for start in range(int(BEGIN.timestamp()),CUT_S,step*900):
  end=min(CUT_S-1,start+step*900-1)
  url='https://www.bitstamp.net/api/v2/ohlc/btcusd/?'+urllib.parse.urlencode({'step':step,'limit':1000,'start':start,'end':end,'exclude_current_candle':'true'})
  try:
   j=get_json(url);pages+=1
   for v in j.get('data',{}).get('ohlc',[]):
    t=int(v['timestamp'])
    if int(BEGIN.timestamp())<=t<CUT_S:rows[t]=[t*1000,float(v['open']),float(v['high']),float(v['low']),float(v['close']),float(v['volume']),None,None,None]
  except Exception as e:
   bad+=1;journal.record('bitstamp/'+str(start),status='ERROR',error=str(e)[:120])
  time.sleep(.15)
 if rows:
  dest.parent.mkdir(parents=True,exist_ok=True)
  with gzip.open(dest,'wt',encoding='utf-8',newline='') as f:
   w=csv.writer(f);w.writerow(FIELDS)
   for t in sorted(rows):w.writerow(rows[t])
 return {'status':'OK' if rows else 'NOT_AVAILABLE','rows':len(rows),'pages':pages,'errors':bad,'sha256':sha(dest) if dest.exists() else None}

def read_binance_daily(root,symbol,interval='1d',kind='spot'):
 b=symbol.replace('-','');sub='spot' if kind=='spot' else 'futures_um'
 folder=root/'binance'/sub/'klines'/b/interval
 out={};invalid=0;files=0
 if not folder.exists():return [],{'files':0,'invalid_rows':0}
 for fp in sorted(folder.glob('*.zip')):
  try:
   with zipfile.ZipFile(fp) as z:
    names=[n for n in z.namelist() if n.lower().endswith('.csv')]
    if len(names)!=1:invalid+=1;continue
    with z.open(names[0]) as raw:
     reader=csv.reader(io.TextIOWrapper(raw,encoding='utf-8-sig',errors='replace',newline=''))
     for v in reader:
      if len(v)<8:continue
      try:
       t=int(v[0]);t=t//1000 if t>=10**14 else t
       if not 1_483_228_800_000<=t<CUT_MS:continue
       op,hi,lo,cl,vol,q=[float(v[k]) for k in (1,2,3,4,5,7)]
       if not all(math.isfinite(x) for x in (op,hi,lo,cl,vol,q)) or min(op,hi,lo,cl)<=0 or lo>min(op,cl) or hi<max(op,cl):invalid+=1;continue
       out[t]={'unix_ms':t,'open':op,'high':hi,'low':lo,'close':cl,'base_volume':vol,'quote_volume':q,
               'trade_count':float(v[8]) if len(v)>8 and str(v[8]).isdigit() else None,
               'taker_buy_quote_volume':float(v[10]) if len(v)>10 and v[10] else None}
      except (ValueError,IndexError,OverflowError):invalid+=1
   files+=1
  except (OSError,zipfile.BadZipFile):invalid+=1
 return [out[t] for t in sorted(out)],{'files':files,'invalid_rows':invalid,'first':iso(min(out)//1000) if out else None,'last':iso(max(out)//1000) if out else None}

def read_kucoin_daily(root,symbol,interval='1day'):
 path=root/'kucoin'/'spot'/symbol/(interval+'.csv.gz')
 if not path.exists():return [],{'files':0}
 vals=[]
 with gzip.open(path,'rt',encoding='utf-8') as f:
  for x in csv.DictReader(f):
   try:
    t=int(x['unix_ms'])
    if t<CUT_MS and t>1_483_228_800_000:
     row={k:(float(x[k]) if x.get(k) not in ('',None,'None') else None) for k in FIELDS if k!='unix_ms'}
     row['unix_ms']=t;vals.append(row)
   except (ValueError,TypeError):pass
 return sorted(vals,key=lambda x:x['unix_ms']),{'files':1}

def daily_returns(vals):
 out=[]
 for i in range(1,len(vals)):
  if vals[i]['unix_ms']-vals[i-1]['unix_ms']!=86400000:continue
  if vals[i-1]['close']>0:out.append(math.log(vals[i]['close']/vals[i-1]['close']))
 return out

def mean(x):return sum(x)/len(x) if x else None

def med(x):return statistics.median(x) if x else None

def corr(x,y):
 z=[(a,b) for a,b in zip(x,y) if a is not None and b is not None and math.isfinite(a) and math.isfinite(b)]
 if len(z)<15:return None
 a,b=zip(*z);ma=mean(a);mb=mean(b)
 aa=sum((v-ma)**2 for v in a);bb=sum((v-mb)**2 for v in b)
 return sum((v-ma)*(w-mb) for v,w in z)/math.sqrt(aa*bb) if aa>0 and bb>0 else None

def analyse_symbol(symbol,rows,btc_map):
 if not rows:return None,[],None
 feat=[];sorted_rows=sorted(rows,key=lambda x:x['unix_ms']);lastclose=None;track=0.;drawdown=0.;per_year=defaultdict(list)
 closes=[x['close'] for x in sorted_rows];qvols=[x.get('quote_volume') for x in sorted_rows]
 prev_gain=prev_loss=None;trs=[];closes_dates={x['unix_ms']:x['close'] for x in sorted_rows}
 ema12=ema26=ema50=ema200=macd_signal=None;obv=0
 for i,r in enumerate(sorted_rows):
  t=r['unix_ms'];c=r['close'];year=dt.datetime.fromtimestamp(t/1000,UTC).year
  per_year[year].append(r)
  if lastclose is not None and c>0:
   gain=max(c-lastclose,0);loss=max(lastclose-c,0)
   if prev_gain is None:prev_gain=gain;prev_loss=loss
   else:prev_gain=(prev_gain*13+gain)/14;prev_loss=(prev_loss*13+loss)/14
  tr=max(r['high']-r['low'],abs(r['high']-(lastclose or c)),abs(r['low']-(lastclose or c)))
  trs.append(tr)
  ema12=c if ema12 is None else (2/13)*c+(11/13)*ema12
  ema26=c if ema26 is None else (2/27)*c+(25/27)*ema26
  ema50=c if ema50 is None else (2/51)*c+(49/51)*ema50
  ema200=c if ema200 is None else (2/201)*c+(199/201)*ema200
  macd=ema12-ema26
  macd_signal=macd if macd_signal is None else (2/10)*macd+(8/10)*macd_signal
  if lastclose is not None:obv+=(1 if c>lastclose else -1 if c<lastclose else 0)*(r.get('base_volume') or 0)
  track=max(track,c);drawdown=min(drawdown,c/track-1)
  def histret(n):
   return c/closes[i-n]-1 if i>=n and t-sorted_rows[i-n]['unix_ms']==n*86400000 else None
  def sma(n):return mean(closes[i-n+1:i+1]) if i>=n-1 else None
  def atr(n):return mean(trs[-n:]) if len(trs)>=n else None
  rsi=100-100/(1+prev_gain/prev_loss) if prev_loss and prev_gain is not None else (100 if prev_loss==0 and prev_gain else None)
  vs=qvols[max(0,i-20):i]
  volume_ratio=r.get('quote_volume')/mean([float(v) for v in vs if v is not None]) if r.get('quote_volume') and any(v for v in vs if v is not None) and mean([float(v) for v in vs if v is not None]) else None
  ratio_btc=c/btc_map[t] if btc_map.get(t) else None
  sd20=statistics.pstdev(closes[i-19:i+1]) if i>=19 else None
  row={'pair':symbol,'day_utc':iso(t/1000)[:10],'close':c,'quote_volume_usdt_exchange':r.get('quote_volume'),
       'ret1':histret(1),'ret7':histret(7),'ret30':histret(30),'ret90':histret(90),'ret180':histret(180),
       'sma20':sma(20),'sma50':sma(50),'sma200':sma(200),
       'ema12':ema12,'ema26':ema26,'ema50':ema50,'ema200':ema200,
       'macd_12_26':macd,'macd_signal_9':macd_signal,'macd_histogram':macd-macd_signal,
       'bollinger_upper_20_2sd':sma(20)+2*sd20 if sd20 is not None else None,
       'bollinger_lower_20_2sd':sma(20)-2*sd20 if sd20 is not None else None,
       'obv_cumulative_exchange_base_volume':obv,'atr14_pct':atr(14)/c if atr(14) else None,
       'rsi14':rsi,'volume_ratio_20d':volume_ratio,'relative_price_to_btc':ratio_btc,
       'range_pct':(r['high']-r['low'])/c,
       'candle_body_pct':(r['close']-r['open'])/r['open'],
       'upper_wick_pct':(r['high']-max(r['open'],r['close']))/c,
       'lower_wick_pct':(min(r['open'],r['close'])-r['low'])/c}
  # OBSERVATIONAL LABELS ONLY. Not causal features: outcomes are ex-post.
  for horizon in (7,30):
   fut=closes_dates.get(t+horizon*86400000)
   row[f'ex_post_forward_{horizon}d']=fut/c-1 if fut else None
  feat.append(row);lastclose=c
 summaries=[]
 for y,yr in sorted(per_year.items()):
  close=[v['close'] for v in yr];volumes=[v.get('quote_volume') for v in yr if v.get('quote_volume') is not None]
  maxclose=-1;dd=0
  for c in close:maxclose=max(maxclose,c);dd=min(dd,c/maxclose-1)
  summaries.append({'pair':symbol,'year':y,'daily_bars':len(yr),'first_utc':iso(yr[0]['unix_ms']/1000)[:10],
   'last_utc':iso(yr[-1]['unix_ms']/1000)[:10],'price_first_close':close[0],'price_last_close':close[-1],
   'close_to_close_return_pct':100*(close[-1]/close[0]-1),'max_close_drawdown_pct':100*dd,
   'median_daily_quote_volume':med(volumes),'sum_daily_quote_volume':sum(volumes),
   'daily_return_volatility_pct':100*statistics.pstdev(daily_returns(yr)) if len(daily_returns(yr))>2 else None})
 return {'pair':symbol,'bars':len(sorted_rows),'earliest':iso(sorted_rows[0]['unix_ms']/1000),'latest':iso(sorted_rows[-1]['unix_ms']/1000),
         'total_close_drawdown_pct':100*drawdown,'years':len(summaries)},feat,summaries

def plot_svg(path,symbol,rows):
 """True data-driven line chart, no image model or external dependency. Lower volume panel."""
 if len(rows)<2:return
 rows=sorted(rows,key=lambda x:x['unix_ms']);W,H=1200,490; pad=64; plotW=W-2*pad; upperH=340
 closes=[r['close'] for r in rows];logs=[math.log(v) for v in closes];lo=min(logs);hi=max(logs);rang=max(hi-lo,1e-12)
 coords=' '.join(f'{pad+int(i*plotW/(len(rows)-1))},{30+int((hi-v)/rang*upperH)}' for i,v in enumerate(logs))
 vols=[r.get('quote_volume') or 0 for r in rows];vmax=max(vols) or 1
 bars=[]
 for i,v in enumerate(vols):
  if i%max(1,len(rows)//200)==0:
   x=pad+i*plotW/(len(rows)-1);h=(v/vmax)*70;bars.append(f'<rect x="{x:.1f}" y="{460-h:.1f}" width="3" height="{h:.1f}" fill="#9fbad1"/>')
 el=f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="#102132"/><text x="64" y="22" fill="white" font-size="19">{html.escape(symbol)} — daily close (log scale); quote volume</text><line x1="64" y1="370" x2="1136" y2="370" stroke="#556b7c"/><polyline points="{coords}" fill="none" stroke="#63d0c5" stroke-width="2"/>{''.join(bars)}<text x="64" y="485" fill="#a8b8c5" font-size="13">{iso(rows[0]['unix_ms']/1000)[:10]}</text><text x="1060" y="485" fill="#a8b8c5" font-size="13">{iso(rows[-1]['unix_ms']/1000)[:10]}</text></svg>'''
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(el,encoding='utf-8')

R43_SOURCE_PIN='2778E5EA5F34E77912A1B705A34296E4AD7A1D292E4B85FE593A163AF4C5F929'

def import_local_c2_tape(repo,downloads,vault,pairs):
 """Import ONLY canonical R27 frozen 2022 and first 8759h of 2023, for C2
 pairs intersecting existing canonical tape. Requires exact SHA-pinned reader.
 No 2024 raw record ever read, and no tape pair added to C2 membership.
 """
 res={'status':'NOT_AVAILABLE','pairs_imported':0,'rows_imported':0,'missing':[],
      'last_permitted_utc':'2023-12-31T22:00:00Z_LAST_HOURLY_OPEN','source_reader_sha_pin':R43_SOURCE_PIN}
 candidates=[downloads/'AKAH_R13R27_MEGA_WORK'/'R13R27_FROZEN_PLAN.json',downloads/'R13R27_FROZEN_PLAN.json']
 plan=next((p for p in candidates if p.is_file()),None)
 if not plan:res['blocker']='R27_PLAN_MISSING';return res
 try:
  meta=json.loads(plan.read_text(encoding='utf-8-sig'));eligible=meta.get('eligible',{})
  if not isinstance(eligible,dict):raise ValueError('BAD_R27_ELIGIBLE')
 except Exception as e:res['blocker']=str(e);return res
 found=None
 roots=[downloads/'AKAH_R50_CONTINUOUS_SURVIVAL_WORK',downloads/'AKAH_R50R1_SHA_CHAIN_RECOVERY_WORK',downloads]
 for d in roots:
  if found:break
  if not d.is_dir():continue
  for fp in d.glob('AKAH_R50*.zip'):
   try:
    with zipfile.ZipFile(fp) as z:
     for name in z.namelist():
      if not name.replace('\\','/').endswith('/r43_data.py'):continue
      raw=z.read(name)
      if hashlib.sha256(raw).hexdigest().upper()==R43_SOURCE_PIN:
       found=(fp,name,raw);break
   except (OSError,zipfile.BadZipFile):pass
   if found:break
 if not found:res['blocker']='SHA_PINNED_R43_READER_NOT_FOUND_IN_R50_ARCHIVE';return res
 reader_file=vault.parent/'tools'/'r43_verified_reader.py';reader_file.parent.mkdir(parents=True,exist_ok=True)
 reader_file.write_bytes(found[2])
 spec=importlib.util.spec_from_file_location('r43_verified_reader',reader_file)
 try:
  if not spec or not spec.loader:raise ValueError('INVALID_MODULE_LOADER')
  mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  if not all(hasattr(mod,k) for k in ('REC','START','H','validate_row')):raise ValueError('READER_FORMAT_MISSING')
  if mod.START.year!=2022:raise ValueError('READER_START_YEAR_NOT_2022')
 except Exception as e:res['blocker']='SHA_PIN_READER_LOAD_FAILED_'+str(e)[:90];return res
 local=vault/'local_canonical_tape';local.mkdir(parents=True,exist_ok=True)
 res.update({'status':'BOUNDED_SOURCE_IMPORT','reader_archive':str(found[0]),'reader_member':found[1],
             'plan_sha256':sha(plan),'reader_record_bytes':mod.REC.size})
 for pair in pairs:
  if pair not in eligible:res['missing'].append({'pair':pair,'reason':'NOT_IN_R27_FROZEN_ELIGIBLE'});continue
  pos=eligible[pair]
  fp=repo/'.akah_bot/v2r2_common_causal_tape_v1/pairs'/(pair+'.1H.bars.bin')
  out=local/(pair+'_2022_2023_17519H.csv.gz')
  if out.exists():res['pairs_imported']+=1;res['rows_imported']+=17519;continue
  if not fp.exists() or not isinstance(pos,int) or pos<0 or fp.stat().st_size<(pos+17519)*mod.REC.size:
   res['missing'].append({'pair':pair,'reason':'TAPE_OR_AUTHORIZED_OFFSET_NOT_PRESENT'});continue
  rows=[]
  try:
   with fp.open('rb') as f:
    f.seek(pos*mod.REC.size)
    for i in range(17519):
     raw=f.read(mod.REC.size)
     row=mod.validate_row(raw,i)
     o,h,l,c,v=[float(row[k]) for k in range(5)]
     if not math.isfinite(c) or min(o,h,l,c)<=0 or l>min(o,c) or h<max(o,c):raise ValueError('INVALID_OHLC')
     t=mod.START+i*mod.H
     if int(t.timestamp())>=CUT_S:raise ValueError('CROSSED_SEALED_2024_CUTOFF')
     # quote turnover is an estimate, never a certified native exchange field.
     rows.append((int(t.timestamp()*1000),o,h,l,c,v,c*v,None,None))
   with gzip.open(out,'wt',encoding='utf-8',newline='') as g:
    w=csv.writer(g);w.writerow(FIELDS);w.writerows(rows)
   res['pairs_imported']+=1;res['rows_imported']+=len(rows)
  except Exception as e:
   res['missing'].append({'pair':pair,'reason':'VALIDATION_ERROR_'+str(e)[:90]})
   if out.exists():out.unlink()
 if not res['pairs_imported']:res['status']='NO_AUTHORIZED_C2_LOCAL_TAPE_AVAILABLE'
 return res

def read_local_tape_daily(vault,pair):
 path=vault/'local_canonical_tape'/(pair+'_2022_2023_17519H.csv.gz')
 if not path.is_file():return [],{'files':0}
 byday=defaultdict(list)
 with gzip.open(path,'rt',encoding='utf-8') as f:
  for r in csv.DictReader(f):
   t=int(r['unix_ms']);byday[t//86400000].append(r)
 rows=[]
 for day,vals in sorted(byday.items()):
  if len(vals)!=24:continue # incomplete last day cannot be used for daily candle
  rows.append({'unix_ms':day*86400000,'open':float(vals[0]['open']),
    'high':max(float(x['high']) for x in vals),'low':min(float(x['low']) for x in vals),
    'close':float(vals[-1]['close']),'base_volume':sum(float(x['base_volume']) for x in vals),
    'quote_volume':sum(float(x['quote_volume']) for x in vals),
    'trade_count':None,'taker_buy_quote_volume':None})
 return rows,{'files':1,'quote_volume_native':False,'scope':'2022_2023_only'}

def gaps_daily(rows):
 if not rows:return {'observed_days':0,'missing_days_inside_active_span':None,'max_gap_days':None,'gaps':[]}
 ts=sorted(set(int(x['unix_ms']) for x in rows));allg=[]
 for a,b in zip(ts,ts[1:]):
  diff=(b-a)//86400000-1
  if diff>0:allg.append({'gap_after_utc':iso(a/1000)[:10],'gap_until_utc':iso(b/1000)[:10],'missing_days':diff})
 return {'observed_days':len(ts),'missing_days_inside_active_span':sum(x['missing_days'] for x in allg),
         'max_gap_days':max((x['missing_days'] for x in allg),default=0),'gaps':allg}

def cross_venue_checks(binance,kucoin,pair):
 z={x['unix_ms']:x for x in binance};match=[];rows=[]
 for a in kucoin:
  b=z.get(a['unix_ms'])
  if b and b['close']>0 and a['close']>0:
   x=a['close']/b['close']-1
   match.append(x)
   if abs(x)>.05:rows.append({'pair':pair,'day_utc':iso(a['unix_ms']/1000)[:10],
      'binance_close':b['close'],'kucoin_close':a['close'],'close_difference_pct':100*x})
 return {'pair':pair,'overlap_days':len(match),'median_absolute_close_difference_pct':100*med([abs(x) for x in match]) if match else None,
         'maximum_absolute_close_difference_pct':100*max((abs(x) for x in match),default=0) if match else None,
         'days_with_gt_5pct_difference':sum(abs(x)>.05 for x in match)},rows

def btc_daily_relation(rows,btc):
 a={x['unix_ms']:x['close'] for x in rows};b={x['unix_ms']:x['close'] for x in btc}
 xx=[];yy=[]
 for t in sorted(set(a)&set(b)):
  ta=t-86400000
  if ta in a and ta in b:
   xx.append(math.log(a[t]/a[ta]));yy.append(math.log(b[t]/b[ta]))
 r=corr(xx,yy)
 v=statistics.pvariance(yy) if len(yy)>2 else 0
 cov=mean([(x-mean(xx))*(y-mean(yy)) for x,y in zip(xx,yy)]) if xx and yy else None
 return {'pair':'', 'overlap_daily_returns':len(xx),'correlation_to_btc':r,'beta_to_btc':cov/v if v and cov is not None else None}

def market_breadth(dataset):
 events=defaultdict(list)
 for p,rows in dataset.items():
  for i,r in enumerate(rows):
   if i<30 or r['unix_ms']-rows[i-30]['unix_ms'] !=30*86400000:continue
   p30=r['close']/rows[i-30]['close']-1
   sma=mean([x['close'] for x in rows[max(0,i-49):i+1]]) if i>=49 else None
   events[iso(r['unix_ms']/1000)[:10]].append((p,p30,r['close']>sma if sma else None))
 out=[]
 for day,val in sorted(events.items()):
  known=[x for x in val if x[2] is not None]
  out.append({'day_utc':day,'observed_c2_pairs':len(val),'c2_pairs_positive_30d':sum(x[1]>0 for x in val),
   'fraction_positive_30d':sum(x[1]>0 for x in val)/len(val),
   'fraction_above_sma50':sum(x[2] for x in known)/len(known) if known else None,
   'median_30d_return_pct':100*med([x[1] for x in val]),
   'warning':'C2_OBSERVED_MARKET_BREADTH_NOT_GLOBAL_CRYPTO_DOMINANCE_NOT_PIT_CERTIFIED'})
 return out

def analyse_all(vault,report_dir,pairs):
 """Data-derived descriptive analysis only. Never choose strategies using 2022–2023 outcomes."""
 report_dir.mkdir(parents=True,exist_ok=True)
 dataset={};source_report=[];venue_checks=[];venue_divergence=[];gap_report=[]
 for p in pairs:
  b,bmeta=read_binance_daily(vault,p)
  k,kmeta=read_kucoin_daily(vault,p)
  t,tmeta=read_local_tape_daily(vault,p) if not (b or k) else ([],{})
  v=b if b else k if k else t
  source='BINANCE_SPOT_1D_ARCHIVE' if b else ('KUCOIN_SPOT_1D_API' if k else ('LOCAL_CANONICAL_R27_1H_ESTIMATED_QUOTE' if t else 'NO_DAILY_SOURCE'))
  g=gaps_daily(v)
  gap_report.append({'pair':p,'source':source,'observed_days':g['observed_days'],
                     'missing_days_inside_active_span':g['missing_days_inside_active_span'],
                     'max_gap_days':g['max_gap_days'],'first_utc':iso(v[0]['unix_ms']/1000)[:10] if v else None,
                     'last_utc':iso(v[-1]['unix_ms']/1000)[:10] if v else None,
                     'listing_before_first_observation_unknown':True})
  for gap in g['gaps']:
   if gap['missing_days']>=2:venue_divergence.append({'pair':p,'day_utc':gap['gap_after_utc'],
          'binance_close':None,'kucoin_close':None,'close_difference_pct':None,
          'data_gap_until':gap['gap_until_utc'],'missing_days':gap['missing_days']})
  if b and k:
   vc,delta=cross_venue_checks(b,k,p);venue_checks.append(vc)
   venue_divergence.extend(delta)
  source_report.append({'pair':p,'chosen_source':source,'rows':len(v),**(bmeta if b else kmeta if k else tmeta)})
  if v:dataset[p]=v
 btc=dataset.get('BTC-USDT',[]);btc_map={v['unix_ms']:v['close'] for v in btc}
 yearly=[];quality=[];factors=[];records=[];btc_rel=[]
 feature_columns=[]
 for p,series in sorted(dataset.items()):
  summ,feat,yrs=analyse_symbol(p,series,btc_map)
  yearly.extend(yrs or []);quality.append(summ)
  if not feature_columns and feat:feature_columns=list(feat[0])
  d=report_dir/'features'/f'{p}_DAILY_FACTORS.csv.gz';d.parent.mkdir(parents=True,exist_ok=True)
  with gzip.open(d,'wt',encoding='utf-8',newline='') as f:
   w=csv.DictWriter(f,fieldnames=feature_columns);w.writeheader();w.writerows(feat)
  plot_svg(report_dir/'charts'/f'{p}_DAILY_LOG_PRICE_VOLUME.svg',p,series)
  weekly=list({dt.datetime.fromtimestamp(r['unix_ms']/1000,UTC).strftime('%G-W%V'):r for r in series}.values())
  monthly=list({dt.datetime.fromtimestamp(r['unix_ms']/1000,UTC).strftime('%Y-%m'):r for r in series}.values())
  plot_svg(report_dir/'charts'/f'{p}_WEEKLY_LOG_PRICE_VOLUME.svg',p+' weekly snapshots',weekly)
  plot_svg(report_dir/'charts'/f'{p}_MONTHLY_LOG_PRICE_VOLUME.svg',p+' monthly snapshots',monthly)
  rr=btc_daily_relation(series,btc);rr['pair']=p;btc_rel.append(rr)
  for feature in ('ret7','ret30','ret90','ret180','atr14_pct','rsi14','volume_ratio_20d','lower_wick_pct','upper_wick_pct'):
   for h in (7,30):
    x=[v.get(feature) for v in feat];y=[v.get(f'ex_post_forward_{h}d') for v in feat]
    valid=sum(a is not None and b is not None for a,b in zip(x,y))
    factors.append({'pair':p,'historical_feature':feature,'ex_post_horizon_days':h,'eligible_observations':valid,'descriptive_correlation':corr(x,y),'multiple_testing_and_selection_caution':'RESEARCH_ONLY_NOT_SIGNAL'})
  records.append((p,len(series)))
 write_csv(report_dir/'C2_DATA_GAPS.csv',gap_report,['pair','source','observed_days','missing_days_inside_active_span','max_gap_days','first_utc','last_utc','listing_before_first_observation_unknown'])
 write_csv(report_dir/'C2_CROSS_VENUE_COMPARISON.csv',venue_checks,['pair','overlap_days','median_absolute_close_difference_pct','maximum_absolute_close_difference_pct','days_with_gt_5pct_difference'])
 write_csv(report_dir/'C2_CROSS_VENUE_AND_DATA_GAP_EVENTS.csv',venue_divergence,['pair','day_utc','binance_close','kucoin_close','close_difference_pct','data_gap_until','missing_days'])
 write_csv(report_dir/'C2_PAIR_RELATION_TO_BTC_DAILY.csv',btc_rel,['pair','overlap_daily_returns','correlation_to_btc','beta_to_btc'])
 breadth=market_breadth(dataset)
 write_csv(report_dir/'C2_OBSERVED_MARKET_BREADTH.csv',breadth,['day_utc','observed_c2_pairs','c2_pairs_positive_30d','fraction_positive_30d','fraction_above_sma50','median_30d_return_pct','warning'])
 write_csv(report_dir/'C2_DAILY_YEARLY_REAL_MARKET_SUMMARY.csv',yearly,['pair','year','daily_bars','first_utc','last_utc','price_first_close','price_last_close','close_to_close_return_pct','max_close_drawdown_pct','median_daily_quote_volume','sum_daily_quote_volume','daily_return_volatility_pct'])
 write_csv(report_dir/'C2_RAW_SOURCE_COVERAGE.csv',source_report,['pair','chosen_source','rows','files','invalid_rows','first','last'])
 write_csv(report_dir/'C2_EXPLORATORY_FEATURE_ASSOCIATIONS.csv',factors,['pair','historical_feature','ex_post_horizon_days','eligible_observations','descriptive_correlation','multiple_testing_and_selection_caution'])
 dump(report_dir/'C2_DESCRIPTIVE_ANALYSIS_STATUS.json',{'analysed_pairs':len(dataset),'requested_pairs':len(pairs),'available_daily_rows':sum(n for _,n in records),
  'pairs_without_daily_data':sorted(set(pairs)-set(dataset)),'no_strategy_selection':True,
  'no_pit_certification':True,'analysis_period_end_exclusive':CUTOFF.isoformat(),
  'ex_post_columns_are_descriptive_not_entry_signals':True,'confidence':'NO_OUT_OF_SAMPLE_EDGE_PROVEN'})
 summaries_2022=[r for r in yearly if r['year']==2022]
 summaries_2023=[r for r in yearly if r['year']==2023]
 report_text=[
  '# AKAH C2 — market-data-first findings (descriptive only)',
  '',f'- C2 operational-candidate pairs requested: {len(pairs)}; daily chart pairs available: {len(dataset)}.',
  f'- Parsed daily price rows from documented available sources: {sum(n for _,n in records)}.',
  f'- Pairs with 2022 price observations: {len(summaries_2022)}; 2023: {len(summaries_2023)}.',
  f'- Median first-to-last daily closing return in 2022: {med([r["close_to_close_return_pct"] for r in summaries_2022])}.',
  f'- Median first-to-last daily closing return in 2023: {med([r["close_to_close_return_pct"] for r in summaries_2023])}.',
  f'- Available cross-venue overlapping series: {len(venue_checks)}.',
  '', '## Epistemic restrictions',
  '- These assets come from a named C2 operational-membership research input, NOT a proven exchange-wide point-in-time membership oracle.',
  '- Association with later returns is descriptive and highly vulnerable to multiple testing. No strategy or entry is inferred.',
  '- Individual exchange pair volume is NOT global crypto market capitalization, BTC dominance, or consolidated capital flows.',
  '- Zero volume/gaps are never interpolated. Date series ends before 2024-01-01 UTC.',
  '- Historical price coverage begins at a venue\'s first retrievable row, not necessarily token creation.',
  '- Earlier user-exposed 2022–2023 results are not independent out-of-sample confirmation.'
 ]
 (report_dir/'READ_ANALYSIS_FIRST.md').write_text('\n'.join(report_text)+'\n',encoding='utf-8')
 return {'pairs_with_daily_bars':len(dataset),'total_bars':sum(n for _,n in records),'pairs_without':sorted(set(pairs)-set(dataset))} 

def packetize(root,downloads,report,packet_mb=90):
 """Upload summary first; split raw archives into <= packet_mb chunks.
 Guarantees no file renamed to imply completeness. Packet index records all omissions.
 """
 packets=downloads/'AKAH_C2_MARKET_VAULT_UPLOAD_PACKETS';packets.mkdir(parents=True,exist_ok=True)
 summary=packets/'UPLOAD_THIS_AKAH_C2_ANALYSIS_AND_COVERAGE.zip'
 report_files=[x for x in report.rglob('*') if x.is_file()]
 with zipfile.ZipFile(summary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for fp in report_files:z.write(fp,fp.relative_to(report.parent).as_posix())
  for f in (root.parent/'C2_MEMBERSHIP_AUTHORITY_V2.json',root.parent/'C2_FULL_VAULT_RUN_STATUS.json'):
   if f.exists():z.write(f,f.name)
 journal=root.parent/'RETRIEVAL_JOURNAL.jsonl'
 if journal.exists():z.write(journal,'RETRIEVAL_JOURNAL.jsonl')
 archive_files=[x for x in root.rglob('*') if x.is_file()]
 batches=[];current=[];total=0;maxbytes=packet_mb*1024**2
 for fp in sorted(archive_files):
  sz=fp.stat().st_size
  if sz>maxbytes:
   batches.append({'oversize':str(fp),'bytes':sz,'reason':'ZIP_ENTRY_TOO_LARGE_FOR_UPLOAD_PART; REMAINS_LOCAL'})
   continue
  if current and total+sz>maxbytes:
   batches.append(current);current=[];total=0
  current.append(fp);total+=sz
 if current:batches.append(current)
 index=[]
 for i,batch in enumerate(batches,1):
  if isinstance(batch,dict):index.append(batch);continue
  name=f'UPLOAD_THIS_AKAH_C2_RAW_DATA_PART_{i:04d}.zip';path=packets/name
  with zipfile.ZipFile(path,'w',zipfile.ZIP_STORED) as z:
   for f in batch:z.write(f,f.relative_to(root.parent).as_posix())
  index.append({'name':name,'bytes':path.stat().st_size,'files':len(batch),'sha256':sha(path)})
 dump(packets/'UPLOAD_PACKET_MANIFEST.json',{'summary_packet':summary.name,'raw_parts':index,'root':str(root),'warning':'RAWS_NEED_ALL_PARTS_FOR_FULL_REVIEW; EXISTING_MARKET_GAPS_REMAIN'})
 return {'summary':str(summary),'parts':len([v for v in index if 'name' in v]),'oversize':len([v for v in index if 'oversize' in v]),'packet_dir':str(packets)}

def run(args):
 repo=pathlib.Path(args.repo);dl=pathlib.Path(args.downloads)
 work=dl/'AKAH_C2_MARKET_VAULT_V2';vault=work/'raw';report=work/'analysis';work.mkdir(exist_ok=True,parents=True)
 journal=Journal(work,args.archive_budget_gb)
 membership=source_authority(repo,work,dl);dump(work/'C2_MEMBERSHIP_AUTHORITY_V2.json',membership)
 pairs=membership['members'];print('C2_PRIMARY_MEMBERSHIP_STATUS='+membership['status'],flush=True)
 print('C2_SOURCE_PAIR_COUNT='+str(len(pairs)),flush=True)
 status={'schema':VERSION,'asof_utc':NOW,'c2_primary_authority':membership['status'], 'authority_conflicts_used':False,
  'C2_pairs_from_operational_membership':pairs,'scope_before_2024':True,'live_orders':0,'production_mutations':0,
  'independent_pit_certified':False,'run_started_utc':dt.datetime.now(UTC).isoformat(),
  'market_categories':{},'unavailable_categories':{},'source_data_origin':'OWNER_LOCAL_TERMINAL'}
 if not pairs:
  status['status']='PRIMARY_C2_AUTHORITY_NOT_RESOLVED_NO_C2_DOWNLOADING'
  dump(work/'C2_FULL_VAULT_RUN_STATUS.json',status)
  print('STOP_C2_MEMBERSHIP_SOURCE_NOT_FOUND; no unrelated symbols substituted',flush=True)
  return False
 # Import bounded local canonical C2-compatible hours first, even when network is unavailable.
 status['market_categories']['local_canonical_c2_2022_2023_tape']=import_local_c2_tape(repo,dl,vault,pairs)
 # Primary data priority before expensive minute/tick archives.
 if args.no_network:
  status['network']='OFF_FOR_TEST_ONLY'
 else:
  for kind,interval in [('spot','1d'),('spot','1h'),('futures_um','1d')]:
   print('STAGE',kind,interval,flush=True)
   status['market_categories'][kind+'_'+interval]=get_months(journal,'',vault,pairs,kind,interval)
  for p in pairs:
   for tf in ('1day','1hour'):
    status['market_categories'][f'kucoin_{p}_{tf}']=kucoin_pair(journal,vault,p,tf)
   status['market_categories']['funding_'+p]=funding_pair(journal,vault,p)
  status['market_categories']['market_context']=defillama(journal,vault)
  status['market_categories']['bitstamp_btc_early']=bitstamp_btc(journal,vault)
  # Analysis-first checkpoint: user gets real evidence before expensive minute/tick archives.
  try:
   status['descriptive_analysis']=analyse_all(vault,report,pairs)
   status['status']='CORE_MARKET_ANALYSIS_CHECKPOINT'
   dump(work/'C2_FULL_VAULT_RUN_STATUS.json',status)
   interim=packetize(vault,dl,report,packet_mb=args.packet_mb)
   print('CORE_ANALYSIS_PACKET='+interim['summary'],flush=True)
  except Exception as e:
   status['analysis_checkpoint_error']=repr(e)
  # Expensive granularities follow the full core set, checkpointed and disk-capped.
  if not args.skip_minute:
   status['market_categories']['spot_1m']=get_months(journal,'',vault,pairs,'spot','1m')
  if not args.skip_aggtrades:
   status['market_categories']['spot_aggTrades']=get_months(journal,'',vault,pairs,'aggTrades','na')
 try:status['descriptive_analysis']=analyse_all(vault,report,pairs)
 except Exception as e:status['analysis_error']=repr(e)
 status['unavailable_categories']={
  'BTC_DOMINANCE_GLOBAL_HISTORY':'NOT_PUBLISHED_AS_GLOBAL_MARKET_CAP_IN_C2_OHLCV; NEED_VERIFIABLE_HISTORICAL_TOTAL_CAP_LICENSE',
  'TOTAL_TOTAL2_TOTAL3_GLOBAL_MARKET_CAP':'NOT_INFERRED_FROM_EXCHANGE_QUOTE_VOLUME_OR_TOP_C2_ONLY',
  'HISTORICAL_FULL_ORDER_BOOK':'NOT_RECONSTRUCTIBLE_FROM_KLINES; INTRABAR_DEPTH_MISSING',
  'HISTORICAL_OPEN_INTEREST':'BINANCE_ENDPOINT_RESTRICTS_RETENTION; 2022-2023 NOT_AUTOMATICALLY_AVAILABLE',
  'ON_CHAIN_SUPPLY_UNLOCKS_NEWS':'NEED_ASSET_IDENTITY_RESOLUTION_AND_VERIFIABLE_SOURCE; NO_FABRICATED_VALUES',
  'ALL_VENUES_FROM_TOKEN_GENESIS':'NO_SINGLE_EXCHANGE HAS HISTORY SINCE TOKEN_CREATION',
  'NON_C2_QUARANTINED_UNIVERSE_CANDIDATES':'NEVER_INCLUDED_IN_C2_DATA_VAULT'
 }
 status['completed_utc']=dt.datetime.now(UTC).isoformat();status['retrieval_status_counts']=dict(Counter(x.get('status','UNKNOWN') for x in journal.records.values()))
 status['status']='PARTIAL_OR_BEST_EFFORT_WITH_PROVENANCE' if args.no_network else ('DATA_AVAILABLE_FOR_ANALYSIS_WITH_GAPS' if status.get('descriptive_analysis',{}).get('pairs_with_daily_bars',0)>0 else 'NO_MARKET_ROWS_RETRIEVED')
 dump(work/'C2_FULL_VAULT_RUN_STATUS.json',status)
 status['packets']=packetize(vault,dl,report,packet_mb=args.packet_mb)
 dump(work/'C2_FULL_VAULT_RUN_STATUS.json',status)
 print('AKAH_C2_MEGA_STATUS='+status['status'],flush=True)
 print('ANALYSIS_PACKET='+status['packets']['summary'],flush=True)
 print('RAW_PACKETS='+str(status['packets']['parts']),flush=True)
 return status['status']!='NO_MARKET_ROWS_RETRIEVED'

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--downloads',required=True)
 p.add_argument('--archive-budget-gb',type=float,default=30);p.add_argument('--packet-mb',type=int,default=90)
 p.add_argument('--skip-minute',action='store_true');p.add_argument('--skip-aggtrades',action='store_true');p.add_argument('--no-network',action='store_true')
 a=p.parse_args();sys.exit(0 if run(a) else 2)
if __name__=='__main__':main()
