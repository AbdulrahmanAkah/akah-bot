import csv, datetime as dt, json, pathlib, shutil, sys, tempfile, zipfile
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import akah_c2_mega_v2 as v

def fixture(tmp):
 repo=tmp/'repo';source=repo/'data/research/rd18_p3x_a3_inputs/c2-operational-membership.csv';source.parent.mkdir(parents=True,exist_ok=True)
 source.write_text('universe,pair,as_of_date,eligible\nC2,BTC-USDT,2022-01-01,true\nC2,ETH-USDT,2022-01-01,true\nC2,WIF-USDT,2024-05-01,true\nD2,XRP-USDT,2022-01-01,true\nC2,LTC-USDT,2022-01-01,false\n',encoding='utf-8')
 (repo/'governance').mkdir(parents=True,exist_ok=True)
 (repo/'governance/expanded_universe_trades.csv').write_text('universe,pair\nC2,XRP-USDT\n',encoding='utf-8')
 downloads=tmp/'Downloads';downloads.mkdir()
 vault=downloads/'AKAH_C2_MARKET_VAULT_V2/raw'
 for pair in ['BTCUSDT','ETHUSDT']:
  for year in (2022,2023):
   fp=vault/'binance/spot/klines'/pair/'1d'/f'{pair}-1d-{year}-01.zip';fp.parent.mkdir(parents=True,exist_ok=True)
   rows=[]
   for i in range(31):
    t=int(dt.datetime(year,1,i+1,tzinfo=dt.timezone.utc).timestamp()*1000)
    cl=100+i
    rows.append(f'{t},{cl},{cl+1},{cl-1},{cl},100,0,10000,3,30,3000,0')
   with zipfile.ZipFile(fp,'w',zipfile.ZIP_DEFLATED) as z:z.writestr(fp.name[:-4]+'.csv','\n'.join(rows)+'\n')
 return repo,downloads

def test():
 with tempfile.TemporaryDirectory() as d:
  repo,dl=fixture(pathlib.Path(d));out=dl/'AKAH_C2_MARKET_VAULT_V2'
  m=v.source_authority(repo,out,dl)
  assert m['members']==['BTC-USDT','ETH-USDT'],m
  assert m['excluded_2024_or_later_metadata_rows']==1
  assert m['point_in_time_certified'] is False
  args=type('A',(),{'repo':str(repo),'downloads':str(dl),'archive_budget_gb':.01,'packet_mb':1,'skip_minute':True,'skip_aggtrades':True,'no_network':True})()
  assert v.run(args)
  status=json.loads((out/'C2_FULL_VAULT_RUN_STATUS.json').read_text())
  assert status['descriptive_analysis']['pairs_with_daily_bars']==2,status
  csvfile=out/'analysis/C2_DAILY_YEARLY_REAL_MARKET_SUMMARY.csv'
  rows=list(csv.DictReader(csvfile.open(encoding='utf-8-sig')))
  assert len(rows)==4,rows
  assert set(x['year'] for x in rows)=={'2022','2023'},rows
  assert not any('2024' in x['first_utc'] for x in rows)
  assert (dl/'AKAH_C2_MARKET_VAULT_UPLOAD_PACKETS/UPLOAD_THIS_AKAH_C2_ANALYSIS_AND_COVERAGE.zip').exists()
  assert len(list((out/'analysis/charts').glob('*.svg')))==6
  print('INTEGRATION_TEST_PASS',{'pairs':len(m['members']),'year_rows':len(rows),'excluded_2024_rows':m['excluded_2024_or_later_metadata_rows']})
if __name__=='__main__':test()

def test_bounded_tape_no_2024():
 import struct,hashlib,gzip
 with tempfile.TemporaryDirectory() as d:
  tmp=pathlib.Path(d);repo=tmp/'repo';dl=tmp/'Downloads';dl.mkdir()
  raw='import struct, datetime as dt\nREC=struct.Struct("<5d")\nSTART=dt.datetime(2022,1,1,tzinfo=dt.timezone.utc)\nH=dt.timedelta(hours=1)\ndef validate_row(data,i): return REC.unpack(data)\n'.encode()
  digest=hashlib.sha256(raw).hexdigest().upper();old=v.R43_SOURCE_PIN;v.R43_SOURCE_PIN=digest
  try:
   zipf=dl/'AKAH_R50_TEST.zip'
   with zipfile.ZipFile(zipf,'w') as z:z.writestr('engine/r43_data.py',raw)
   (dl/'AKAH_R13R27_MEGA_WORK').mkdir()
   (dl/'AKAH_R13R27_MEGA_WORK/R13R27_FROZEN_PLAN.json').write_text(json.dumps({'eligible':{'BTC-USDT':0,'ETH-USDT':0}}))
   tape=repo/'.akah_bot/v2r2_common_causal_tape_v1/pairs/BTC-USDT.1H.bars.bin';tape.parent.mkdir(parents=True)
   with tape.open('wb') as f:
    for i in range(17519):f.write(struct.pack('<5d',100,120,99,100+(i%10),1))
   vault=dl/'AKAH_C2_MARKET_VAULT_V2/raw'
   result=v.import_local_c2_tape(repo,dl,vault,['BTC-USDT'])
   assert result['status']=='BOUNDED_SOURCE_IMPORT',result
   assert result['rows_imported']==17519
   series,meta=v.read_local_tape_daily(vault,'BTC-USDT')
   assert len(series)==729,len(series) # 365 days (2022) +364 full days (2023)
   assert all(r['unix_ms']<v.CUT_MS for r in series)
   assert series[-1]['unix_ms']==int(dt.datetime(2023,12,30,tzinfo=dt.timezone.utc).timestamp()*1000)
   print('BOUNDED_TAPE_TEST_PASS',{'rows':result['rows_imported'],'complete_days':len(series)})
  finally:v.R43_SOURCE_PIN=old

if __name__=='__main__':
 test_bounded_tape_no_2024()
