import pandas as pd,numpy as np,glob,os,json,time
O='/mnt/data/C2_PEAK_FORENSICS';st=time.time();files=sorted(glob.glob(O+'/EVENTS_*.csv.gz'))
rows=[];sample=[];non=[];pairs=[];allcnt=0;yearstats={}
for fi,f in enumerate(files):
 d=pd.read_csv(f);allcnt+=len(d)
 if d.empty:continue
 d=d.sort_values('signal_ms')
 # Nonoverlap 30d cooldown; observation selection purely historical timestamps, no performance conditioning
 timearr=d.signal_ms.to_numpy(np.int64)
 chosen=[];last=0
 for k,t in enumerate(timearr):
  if t-last>=720*3600000:chosen.append(k);last=t
 nd=d.iloc[chosen].copy();non.append(nd)
 pairs.append({'pair':d.pair.iloc[0],'venue':d.venue.iloc[0],'raw_events':len(d),'nonoverlap_events':len(nd),'years':','.join(str(x) for x in sorted(d.year.unique()))})
 if fi%70==0:print('AGG',fi,'events',allcnt,'nonoverlap',sum(len(x) for x in non),'elapsed',round(time.time()-st,1),flush=True)
allnon=pd.concat(non,ignore_index=True)
allnon.to_csv(O+'/THIRTY_DAY_NONOVERLAPPING_IMPULSES.csv.gz',index=False,compression='gzip')
pd.DataFrame(pairs).to_csv(O+'/PAIR_COUNTS.csv',index=False)
# cohort summaries + strict complete records conditional
out=[]
for yr in [2018,2019,2020,2021,2022,2023]:
 s=allnon[allnon.year==yr];s720=s[s.full_720==1]
 if not len(s):continue
 row={'year':yr,'events30d':len(s),'pairs':s.pair.nunique(),'complete720':len(s720),'median_max_high_168_pct':round(float(s.best_168_peak_pct.median()),3),'median_exit_24h_pct':round(float(s.ret24_pct.median()),3),'median_exit_72h_pct':round(float(s.ret72_pct.median()),3),'median_exit_168h_pct':round(float(s.ret168_pct.median()),3),'median_hours_to_peak_168':round(float(s.hours_to_peak.median()),1),'share_first168_peak_surpassed_before720_COMPLETE':round(float((s720.peak168_to720_extra_pct>.1).mean()),4) if len(s720) else None,'median_peak_extension_pct_COMPLETE':round(float(s720.peak168_to720_extra_pct.median()),3) if len(s720) else None,'share_weeks_profitable_after_0p6pct_fee':round(float((s.ret168_pct.dropna()>.6).mean()),4)}
 out.append(row)
pd.DataFrame(out).to_csv(O+'/YEAR_SUMMARY.csv',index=False)
# As-of features separately in 2022 & 2023, no chosen threshold except ordinary categorical factor and clear subjective thresholds labeled exploratory
allnon['daily_trend']=np.select([allnon.past24_pct>0,allnon.past24_pct<0],['UP','DOWN'],default='UNAVAILABLE_OR_FLAT')
allnon['weekly_trend']=np.select([allnon.past168_pct>0,allnon.past168_pct<0],['UP','DOWN'],default='UNAVAILABLE_OR_FLAT')
allnon['volume_class']=pd.cut(allnon.relative_base_volume_168h,[-np.inf,.75,1.5,np.inf],labels=['LOW','NORMAL','HIGH'])
allnon['impulse_class']=pd.cut(allnon.signal_up_pct,[0,1.5,3,6,np.inf],labels=['1-1.5%','1.5-3%','3-6%','>6%'])
summ=[]
for yr in [2022,2023]:
 s=allnon[allnon.year==yr]
 for dim in ['daily_trend','weekly_trend','volume_class','impulse_class','btc_regime','liquidity_band_proxy']:
  for v,g in s.groupby(dim,dropna=False,observed=True):
   if len(g)<20:continue
   gg=g[g.full_720==1]; t=g.ret168_pct.dropna()
   summ.append({'year':yr,'feature':dim,'value':str(v),'events':len(g),'pairs':g.pair.nunique(),'median_ret24_pct':round(float(g.ret24_pct.median()),3),'median_ret168_pct':round(float(t.median()),3) if len(t) else None,'week_win_after_0p6_fee':round(float((t>.6).mean()),4) if len(t) else None,'median_168_peak_pct':round(float(g.best_168_peak_pct.median()),3),'pct_first_168_peak_beaten_over_720_complete':round(100*float((gg.peak168_to720_extra_pct>.1).mean()),2) if len(gg) else None})
pd.DataFrame(summ).to_csv(O+'/ASOF_FACTOR_COMPARISON.csv',index=False)
# cross of daily/weekly and BTC states, only 2022-23, with independent 30d events
multi=[]
for keys,g in allnon[allnon.year.isin([2022,2023])].groupby(['year','daily_trend','weekly_trend','btc_regime'],dropna=False):
 if len(g)<40:continue
 u=g.ret168_pct.dropna();g720=g[g.full_720==1]
 multi.append({'year':keys[0],'daily':keys[1],'weekly':keys[2],'btc':keys[3],'events':len(g),'pairs':g.pair.nunique(),'median_24h_pct':round(float(g.ret24_pct.median()),3),'median_168h_pct':round(float(u.median()),3) if len(u) else None,'win168_after_0p6_cost_pct':round(100*float((u>.6).mean()),2) if len(u) else None,'pct_peak_beaten_by_720':round(100*float((g720.peak168_to720_extra_pct>.1).mean()),2) if len(g720) else None})
pd.DataFrame(multi).to_csv(O+'/MULTIFRAME_AND_BTC_COMBINED.csv',index=False)
# Compare naive top-picking bias: full samples only, 2022-2023, high-liquidity subset, 720 observations
peaks=[]
for yr in [2022,2023]:
 s=allnon[(allnon.year==yr)&(allnon.full_720==1)]
 for label,cond in [('all',np.ones(len(s),dtype=bool)),('quote_high_1m',s.liquidity_band_proxy.astype(str).str.contains('HIGH',case=False,regex=False).to_numpy()),('btc_up',s.btc_regime.astype(str).str.contains('UP',case=False,regex=False).to_numpy())]:
  ss=s[cond]
  if not len(ss):continue
  p=ss.peak168_to720_extra_pct
  peaks.append({'year':yr,'subset':label,'events_complete720':len(ss),'pct_week_peak_not_final_at_30d':round(100*float((p>.1).mean()),2),'median_extra_peak_gain_pct':round(float(p.median()),3),'p90_extra_peak_gain_pct':round(float(p.quantile(.9)),3),'p99_extra_peak_gain_pct':round(float(p.quantile(.99)),3)})
pd.DataFrame(peaks).to_csv(O+'/PEAK_FINALITY_AUDIT.csv',index=False)
json.dump({'raw_event_count':int(allcnt),'pairs_in_events':len(files),'nonoverlap_event_count':len(allnon),'years':[int(y) for y in sorted(allnon.year.unique())],'definition':'hourly 1% or greater close/open impulse; buy next bar open; highest high in next 168h and additional high within 720h, including all impulses with incomplete futures marked censored, monthly cooldown for nonoverlap','observations_not_causal_strategy':True,'2024_excluded':True},open(O+'/AUDIT_SUMMARY.json','w'),indent=2)
print('DONE',json.dumps(json.load(open(O+'/AUDIT_SUMMARY.json'))),'elapsed',round(time.time()-st,1));print(pd.DataFrame(out).to_string(index=False));print(pd.DataFrame(peaks).to_string(index=False))
