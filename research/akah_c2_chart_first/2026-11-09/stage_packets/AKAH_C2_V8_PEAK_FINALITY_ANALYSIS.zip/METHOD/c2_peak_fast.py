import os,zipfile,glob,io,gzip,json,sys,time
import numpy as np,pandas as pd
from numba import njit
ROOT='/mnt/data';OUT=ROOT+'/C2_PEAK_FORENSICS';os.makedirs(OUT,exist_ok=True)
raw_files=sorted(glob.glob(ROOT+'/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip'))
parts=int(sys.argv[1]) if len(sys.argv)>1 else 1
layers={};handles=[]
for p in sorted(glob.glob(ROOT+'/UPLOAD_THIS_AKAH_C2_V6_VOLUME_LAYER_PART_*.zip')):
 z=zipfile.ZipFile(p);handles.append(z)
 for x in z.namelist():
  if x.startswith('volume_layers/') and x.endswith('.csv.gz'):layers[x.split('/')[-1].replace('V6_','').replace('.csv.gz','')]=(z,x)
@njit

def calc(t,o,h,l,c,vl):
 n=len(t);records=np.empty((n,18),dtype=np.float64); count=0
 for j in range(168,n-1):
  if o[j]<=0 or c[j]<=0 or c[j]/o[j]<1.01 or h[j]<c[j] or l[j]>o[j]: continue
  if t[j+1]-t[j]!=3600000:continue
  if not np.isfinite(vl[j]):pass
  entry=j+1;p=o[entry]
  if p<=0:continue
  upper=min(j+721,n);cut=upper
  for k in range(j+1,upper-1):
   if t[k+1]-t[k]!=3600000:
    cut=k+1;break
  e168=min(cut,j+169)
  maxh=-1.; pos=-1
  for k in range(entry,e168):
   if h[k]>maxh:maxh=h[k];pos=k
  if pos<0:continue
  max720=maxh
  for k in range(e168,cut):
   if h[k]>max720:max720=h[k]
  r24=np.nan;r72=np.nan;r168=np.nan;r336=np.nan;r720=np.nan
  if j+24<cut:r24=100*(c[j+24]/p-1)
  if j+72<cut:r72=100*(c[j+72]/p-1)
  if j+168<cut:r168=100*(c[j+168]/p-1)
  if j+336<cut:r336=100*(c[j+336]/p-1)
  if j+720<cut:r720=100*(c[j+720]/p-1)
  # first 168h max, compare to best within 720h (not global)
  later_higher=max720>maxh*1.001
  post24=-1.; post72=-1.;post168=-1.
  for k in range(pos+1,min(cut,pos+169)):
   if k<=pos+24 and h[k]>post24:post24=h[k]
   if k<=pos+72 and h[k]>post72:post72=h[k]
   if h[k]>post168:post168=h[k]
  past24=np.nan;past168=np.nan
  if t[j]-t[j-24]==24*3600000:past24=100*(c[j]/c[j-24]-1)
  if t[j]-t[j-168]==168*3600000:past168=100*(c[j]/c[j-168]-1)
  cloc=(c[j]-l[j])/(h[j]-l[j]) if h[j]>l[j] else np.nan
  records[count]=np.array([j,100*(c[j]/o[j]-1),past24,past168,cloc,100*(maxh/p-1),pos-j,100*(max720/maxh-1),r24,r72,r168,r336,r720,1. if later_higher else 0.,1. if j+168<cut else 0.,1. if j+720<cut else 0.,float(cut-j-1),vl[j]])
  count+=1
 return records[:count]
cols=['i','signal_up_pct','past24_pct','past168_pct','close_location','best_168_peak_pct','hours_to_peak','peak168_to720_extra_pct','ret24_pct','ret72_pct','ret168_pct','ret336_pct','ret720_pct','later_peak_higher','full_168','full_720','hours_observable','base_volume']
z=zipfile.ZipFile(raw_files[parts-1]);nread=0;processed=0;event_count=0;errors=[];start=time.time()
for ix,name in enumerate(z.namelist()):
 if not name.startswith('hourly/'):continue
 key=name.split('/')[-1].replace('.csv.gz','');pair=key.split('_',1)[-1];venue=key.split('_',1)[0]
 if os.path.exists(OUT+'/EVENTS_'+key+'.csv.gz') and os.path.getsize(OUT+'/EVENTS_'+key+'.csv.gz')>100:processed+=1;continue
 try:
  d=pd.read_csv(io.BytesIO(gzip.decompress(z.read(name))),usecols=['unix_ms','open','high','low','close','base_volume'])
  d=d.dropna(subset=['unix_ms','open','high','low','close']).drop_duplicates('unix_ms',keep='last').sort_values('unix_ms')
  d=d[(d.unix_ms<1704067200000)&(d.unix_ms>0)];n=len(d);nread+=n
  if n<200:continue
  t=d.unix_ms.to_numpy(np.int64);o=d.open.to_numpy(float);h=d.high.to_numpy(float);l=d.low.to_numpy(float);c=d.close.to_numpy(float);v=d.base_volume.to_numpy(float)
  arr=calc(t,o,h,l,c,v)
  if len(arr)==0:continue
  out=pd.DataFrame(arr,columns=cols);pos=out.i.to_numpy(np.int64);out.drop(columns=['i'],inplace=True)
  out.insert(0,'pair',pair);out.insert(1,'venue',venue);out.insert(2,'signal_ms',t[pos]);out.insert(3,'year',pd.to_datetime(t[pos],unit='ms',utc=True).year)
  if key in layers:
   try:
    lz,lname=layers[key]
    vd=pd.read_csv(io.BytesIO(gzip.decompress(lz.read(lname))),usecols=['unix_ms','relative_base_volume_168h','btc_regime','btc_past_168h_pct','liquidity_band_proxy','zero_range_share_168h'])
    aligned=vd.drop_duplicates('unix_ms').set_index('unix_ms').reindex(t[pos])
    for cc in aligned.columns:out[cc]=aligned[cc].to_numpy()
   except Exception as ex:errors.append([key,'layer',str(ex)[:100]])
  # save per-pair with manageable files, all events retained
  out.to_csv(OUT+'/EVENTS_'+key+'.csv.gz',index=False,compression='gzip')
  # condensed records for aggregation
  # persisted per-pair; no huge in-memory concatenation
  event_count+=len(out)
  processed+=1
  if ix%55==0:print('PART',parts,'PROGRESS',ix,'processed',processed,'hours',nread,'elapsed',round(time.time()-start,1),flush=True)
 except Exception as ex:errors.append([key,'raw',str(ex)[:150]])

json.dump({'part':parts,'assets':processed,'hours':nread,'new_events':event_count,'errors':errors,'elapsed_s':time.time()-start},open(OUT+f'/PART_{parts}_AUDIT.json','w'),indent=2)
print('DONE PART',parts,'assets',processed,'hours',nread,'new_events',event_count,'elapsed',round(time.time()-start,1),'ERR',len(errors),flush=True)
