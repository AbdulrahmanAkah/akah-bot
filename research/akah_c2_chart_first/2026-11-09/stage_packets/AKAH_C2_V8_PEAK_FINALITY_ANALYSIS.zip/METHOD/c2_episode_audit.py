import os,sys,zipfile,glob,io,gzip,json,time
import numpy as np,pandas as pd
from numba import njit
R='/mnt/data';O=R+'/C2_PEAK_FORENSICS';os.makedirs(O,exist_ok=True)
part=int(sys.argv[1]);zs=sorted(glob.glob(R+'/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip')); z=zipfile.ZipFile(zs[part-1]);start=time.time();errors=[];cnt=0;epcount=0
@njit
def episodes(t,o,h,l,c,dd):
 n=len(c);rows=np.empty((n,16),np.float64);N=0;i=168
 while i<n-1:
  if t[i+1]-t[i]!=3600000 or o[i]<=0 or c[i]<1.01*o[i]:i+=1;continue
  st=i;entry=i+1;entryp=o[entry]
  pmax=h[i];pidx=i; j=i+1;end=j;confirmed=0
  while j<n:
   if t[j]-t[j-1]!=3600000:break
   if h[j]>pmax:pmax=h[j];pidx=j
   if c[j]<=pmax*(1-dd):confirmed=1;end=j;break
   j+=1
  if confirmed==0:end=min(j,n-1)
  follow=min(n,end+721);cut=follow
  for k in range(end+1,follow):
   if t[k]-t[k-1]!=3600000:cut=k;break
  topafter=-1.
  for k in range(end+1,cut):
   if h[k]>topafter:topafter=h[k]
  finishp=o[end+1] if confirmed and end+1<n and t[end+1]-t[end]==3600000 else np.nan
  past24=np.nan;past168=np.nan
  if t[st]-t[st-24]==24*3600000:past24=100*(c[st]/c[st-24]-1)
  if t[st]-t[st-168]==168*3600000:past168=100*(c[st]/c[st-168]-1)
  rows[N]=np.array([st,entryp,pmax,pidx,end,confirmed,finishp,100*(pmax/entryp-1) if entryp>0 else np.nan,100*(finishp/entryp-1) if entryp>0 and np.isfinite(finishp) else np.nan,100*(topafter/pmax-1) if topafter>=0 else np.nan,1 if cut==end+721 else 0,past24,past168,float(end-st),float(pidx-st),float(c[st]/o[st]*100-100)])
  N+=1
  i=max(st+1,end+1)
 return rows[:N]
col=['start_i','entry_open','expost_peak','peak_i','confirmation_i','confirmed','confirmation_next_open','upper_bound_peak_return_pct','confirmed_exit_return_pct','later_top_vs_peak_pct','complete_follow_720','prior_24h_pct','prior_168h_pct','hours_until_confirmation','hours_to_peak','start_impulse_pct']
records=[]
for ix,name in enumerate(z.namelist()):
 if not name.startswith('hourly/'):continue
 key=name.split('/')[-1].replace('.csv.gz','')
 try:
  df=pd.read_csv(io.BytesIO(gzip.decompress(z.read(name))),usecols=['unix_ms','open','high','low','close']);df=df.drop_duplicates('unix_ms').sort_values('unix_ms').dropna();df=df[df.unix_ms<1704067200000]
  if len(df)<200:continue
  t=df.unix_ms.to_numpy(np.int64);o=df.open.to_numpy(float);h=df.high.to_numpy(float);l=df.low.to_numpy(float);c=df.close.to_numpy(float)
  for dd in [.1,.2]:
   a=episodes(t,o,h,l,c,dd)
   if not len(a):continue
   x=pd.DataFrame(a,columns=col);x['pair']=key.split('_',1)[-1];x['venue']=key.split('_',1)[0];x['drawdown_threshold_pct']=dd*100
   x['start_ms']=t[x.start_i.to_numpy(np.int64)];x['year']=pd.to_datetime(x.start_ms,unit='ms',utc=True).dt.year
   x['peak_ms']=t[x.peak_i.to_numpy(np.int64)];x['confirmation_ms']=t[x.confirmation_i.to_numpy(np.int64)]
   x.drop(columns=['start_i','peak_i','confirmation_i'],inplace=True)
   records.append(x);epcount+=len(x)
  cnt+=1
  if ix%80==0:print('EP PART',part,ix,'events',epcount,'elapsed',round(time.time()-start,1),flush=True)
 except Exception as exc: errors.append([key,str(exc)[:150]])
if records:
 out=pd.concat(records,ignore_index=True);out.to_csv(O+f'/TREND_EPISODES_DD10_DD20_PART{part}.csv.gz',index=False,compression='gzip')
json.dump({'part':part,'pairs':cnt,'episodes':epcount,'errors':errors},open(O+f'/EPISODE_AUDIT_PART{part}.json','w'),indent=2)
print('DONE EP',part,cnt,epcount,'elapsed',round(time.time()-start,1),flush=True)
