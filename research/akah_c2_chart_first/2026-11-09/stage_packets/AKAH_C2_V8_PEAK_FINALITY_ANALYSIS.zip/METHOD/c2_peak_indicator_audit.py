import os,zipfile,glob,io,gzip,time,json
import pandas as pd,numpy as np
O='/mnt/data/C2_PEAK_FORENSICS';R='/mnt/data';st=time.time()
e=pd.concat([pd.read_csv(f) for f in glob.glob(O+'/TREND_EPISODES_DD10_DD20_PART*.csv.gz')],ignore_index=True)
e=e[e.year.isin([2022,2023])].copy()
features={};zs=[]
for p in sorted(glob.glob(R+'/UPLOAD_THIS_AKAH_C2_V5_ENRICHED_PART_*.zip')):
 z=zipfile.ZipFile(p);zs.append(z)
 for name in z.namelist():
  if name.startswith('features_daily/') and name.endswith('.csv.gz'):
   key=name.split('/')[-1].replace('C2_','').replace('.csv.gz','');features[key]=(z,name)
print('Daily features inventory',len(features),'episodes',len(e),flush=True)
allrows=[];errors=[];fcols=['rsi14_wilder','macd','macd_signal','sma20','sma50','sma200','atr14_wilder','bollinger20_width_pct','donchian20_breakout_high','donchian20_breakdown_low','stochastic14_pct','chaikin_money_flow20','realized_volatility30_pct','volume_ratio30','taker_buy_ratio']
for ix,(key,g) in enumerate(e.groupby(['venue','pair'],sort=False)):
 venue,pair=key;find=f'{venue}_{pair}'; f=features.get(find)
 if f is None:continue
 try:
  d=pd.read_csv(io.BytesIO(gzip.decompress(f[0].read(f[1]))),usecols=lambda c:c in fcols+['unix_ms','close']).drop_duplicates('unix_ms').sort_values('unix_ms')
  if d.empty:continue
  # Daily timestamps are 00:00 UTC opens. Values only become known at next UTC midnight.
  ready=d.unix_ms.to_numpy(np.int64)+86400000
  gg=g.copy()
  for stage,tcol in [('entry','start_ms'),('peak','peak_ms'),('confirm','confirmation_ms')]:
   t=gg[tcol].to_numpy(np.int64)
   loc=np.searchsorted(ready,t,side='right')-1
   ok=loc>=0
   for col in fcols+['close']:
    if col not in d:continue
    src=d[col].to_numpy();dst=np.full(len(gg),np.nan);dst[ok]=src[loc[ok]];gg[f'{stage}_{col}']=dst
   gg[f'{stage}_daily_age_hours']=np.where(ok,(t-ready[np.maximum(loc,0)])/3600000,np.nan)
  for stage in ['entry','peak','confirm']:
   px=gg[f'{stage}_close'];gg[f'{stage}_price_vs_sma50_pct']=100*(px/gg[f'{stage}_sma50']-1);gg[f'{stage}_price_vs_sma200_pct']=100*(px/gg[f'{stage}_sma200']-1)
   gg[f'{stage}_macd_hist']=gg[f'{stage}_macd']-gg[f'{stage}_macd_signal']
  allrows.append(gg)
  if ix%70==0:print('JOIN',ix,'rows',sum(len(x) for x in allrows),'elapsed',round(time.time()-st,1),flush=True)
 except Exception as exc:errors.append([find,str(exc)[:200]])
a=pd.concat(allrows,ignore_index=True);a.to_csv(O+'/EPISODES_DAILY_ASOF_INDICATORS.csv.gz',index=False,compression='gzip')
# Compare peak indicators vs start and confirmation for genuine reversal-defined episodes, and false final peak follow-up.
summary=[]
for yr in [2022,2023]:
 for dd in [10,20]:
  g=a[(a.year==yr)&(a.drawdown_threshold_pct==dd)&(a.confirmed==1)&(a.complete_follow_720==1)]
  if not len(g):continue
  for label,sub in [('ALL',g),('NO_LATER_HIGH',g[g.later_top_vs_peak_pct<=.1]),('LATER_HIGH',g[g.later_top_vs_peak_pct>.1])]:
   if len(sub)<50:continue
   row={'year':yr,'dd_threshold':dd,'peak_finality_group':label,'n_episodes':len(sub),'pairs':sub.pair.nunique(),'median_expost_max_gain_pct':sub.upper_bound_peak_return_pct.median(),'median_confirmed_exit_gain_pct':sub.confirmed_exit_return_pct.median(),'share_positive_exit_after_0p6pct_cost':(sub.confirmed_exit_return_pct>.6).mean()}
   for stage in ['entry','peak','confirm']:
    for col in ['rsi14_wilder','price_vs_sma50_pct','price_vs_sma200_pct','macd_hist','bollinger20_width_pct','stochastic14_pct','chaikin_money_flow20','realized_volatility30_pct','volume_ratio30']:
     x=sub.get(f'{stage}_{col}',pd.Series(dtype=float)).dropna();row[f'{stage}_{col}_median']=round(float(x.median()),4) if len(x) else None
     row[f'{stage}_{col}_availability_pct']=round(100*len(x)/len(sub),2)
   summary.append(row)
pd.DataFrame(summary).to_csv(O+'/PEAK_VS_ENTRY_VS_CONFIRM_INDICATOR_SUMMARY.csv',index=False)
# peak phase comparison of daily RSI and MA features by stage. Cohort not causal final top identification.
json.dump({'episodes_examined':len(e),'joined_to_daily':len(a),'daily_feature_files':len(features),'joined_venues_pairs':len(allrows),'errors':errors,'asof_daily_publication':'daily_open_ms+24h; only previously closed UTC days','no_future_daily_at_decision':True},open(O+'/INDICATOR_JOIN_AUDIT.json','w'),indent=2)
print('DONE',len(a),'elapsed',round(time.time()-st,1),'errors',len(errors))
print(pd.DataFrame(summary)[['year','dd_threshold','peak_finality_group','n_episodes','median_expost_max_gain_pct','median_confirmed_exit_gain_pct','entry_rsi14_wilder_median','peak_rsi14_wilder_median','confirm_rsi14_wilder_median']].to_string(index=False))
