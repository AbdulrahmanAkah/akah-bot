#!/usr/bin/env python3
"""BTC simple as-of benchmark. Historical research, not financial advice.
Compare daily BTC 200d trend using signal at prior close and execution at next open.
2022/2023 only. No post-2023 data. Same KuCoin source as single-venue V12.
"""
import glob,zipfile,io,json
import pandas as pd,numpy as np
from pathlib import Path
ROOT=Path('/mnt/data');OUT=ROOT/'AKAH_C2_V12_TREND_RESEARCH';OUT.mkdir(exist_ok=True)
ss=[]
for path in sorted(glob.glob(str(ROOT/'UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip'))):
 with zipfile.ZipFile(path) as z:
  if 'daily/KUCOIN_BTC-USDT.csv.gz' in z.namelist():
   d=pd.read_csv(io.BytesIO(z.read('daily/KUCOIN_BTC-USDT.csv.gz')),compression='gzip');break
else:raise SystemExit('Missing BTC-USDT KuCoin daily history')
d=d.sort_values('unix_ms').drop_duplicates('unix_ms')
d=d[(d.unix_ms>=pd.Timestamp('2020-11-01',tz='UTC').value//10**6)&(d.unix_ms<pd.Timestamp('2024-01-01',tz='UTC').value//10**6)].copy()
d['sma200']=d.close.rolling(200,min_periods=200).mean();d['day']=d.unix_ms//86400000;d=d.set_index('day')
begin=pd.Timestamp('2022-01-01',tz='UTC').value//10**6//86400000
end=pd.Timestamp('2024-01-01',tz='UTC').value//10**6//86400000
for alloc in (.5,1.0):
 for fee,slip in ((.003,.001),(.006,.002)):
  cash=100000.;units=0.;pk=cash;dd=0.;y22=1e5;orders=0;days=[]
  for day in range(begin,end):
   if day not in d.index or day-1 not in d.index:continue
   r=d.loc[day];sig=d.loc[day-1];eligible=bool(np.isfinite(sig.sma200) and sig.close>sig.sma200)
   if units>0 and not eligible:
    cash+=units*float(r.open)*(1-slip)*(1-fee);units=0;orders+=1
   if units==0 and eligible:
    nominal=min(cash*alloc,cash/(1+fee))
    units=nominal/(float(r.open)*(1+slip));cash-=nominal*(1+fee);orders+=1
   nav=cash+units*float(r.close);pk=max(pk,nav);dd=min(dd,nav/pk-1)
   days.append((day,nav))
   if day==pd.Timestamp('2022-12-31',tz='UTC').value//10**6//86400000:y22=nav
  if units:
   cash+=units*float(d.loc[end-1].close)*(1-slip)*(1-fee)
  ss.append({'allocation':alloc,'fee_per_side':fee,'slippage_per_side':slip,'total_return_pct':100*(cash/1e5-1),'2022_pct':100*(y22/1e5-1),'2023_pct':100*(cash/y22-1),'daily_max_dd_pct':100*dd,'orders':orders})
pd.DataFrame(ss).to_csv(OUT/'BTC_200D_BASELINE.csv',index=False)
print(pd.DataFrame(ss).to_string(index=False))
