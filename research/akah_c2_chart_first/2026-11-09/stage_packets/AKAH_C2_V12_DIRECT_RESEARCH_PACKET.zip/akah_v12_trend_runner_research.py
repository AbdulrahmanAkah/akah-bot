#!/usr/bin/env python3
"""AKAH C2 V12 — audited daily trend-runner proof of concept.
Read-only pre-2024 research. No live trading. Hypotheses are diagnostic, NOT approved policies.
C2 universe candidate, not PIT certified. No future labels used for decisions.
"""
import os,glob,io,zipfile,math,json,collections
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path('/mnt/data')
END=pd.Timestamp('2024-01-01',tz='UTC').value//1000000
START=pd.Timestamp('2022-01-01',tz='UTC').value//1000000
DAY=86400000
RAW=ROOT/'UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip'
OUT=ROOT/'AKAH_C2_V12_TREND_RESEARCH';OUT.mkdir(exist_ok=True)

def load_data():
    vals={}
    for fn in sorted(glob.glob(str(RAW))):
        with zipfile.ZipFile(fn) as z:
            for nm in z.namelist():
                if not nm.startswith('daily/') or not nm.endswith('.csv.gz'):continue
                src=nm[6:-7];venue,pair=src.split('_',1)
                if pair in vals and venue!='KUCOIN':continue
                a=pd.read_csv(io.BytesIO(z.read(nm)),compression='gzip')
                if not {'unix_ms','open','high','low','close','base_volume'}.issubset(a.columns):continue
                a=a.loc[(a.unix_ms<END)&(a.unix_ms>START-450*DAY)].sort_values('unix_ms').drop_duplicates('unix_ms').copy()
                for k in ['open','high','low','close','base_volume']:
                    a[k]=pd.to_numeric(a[k],errors='coerce')
                a=a.loc[(a.open>0)&(a.high>=a.low)&(a.high>=a.open)&(a.low<=a.open)&(a.close>0)&(a.high>=a.close)&(a.low<=a.close)].copy()
                if len(a)<100:continue
                a['day']=(a.unix_ms//DAY).astype(int)
                a=a.set_index('day').asfreq('D') if False else a.set_index('day').sort_index()
                vals[pair]=(venue,a)
    return vals

def feature(d,btc=None):
    # reindex calendar day, never forward-fill market values, so gaps interrupt rolling features
    a=d.reindex(range(d.index.min(),d.index.max()+1)).copy()
    c=a.close;h=a.high;l=a.low;v=a.base_volume
    prev=c.shift(1)
    tr=pd.concat([h-l,abs(h-prev),abs(l-prev)],axis=1).max(axis=1,skipna=False)
    a['atr14']=tr.rolling(14,min_periods=14).mean()
    for k in [10,20,50,100,200]:a[f'ma{k}']=c.rolling(k,min_periods=k).mean()
    for k in [5,10,20,55]:a[f'high{k}prev']=h.shift(1).rolling(k,min_periods=k).max()
    for k in [5,10,20]:a[f'low{k}prev']=l.shift(1).rolling(k,min_periods=k).min()
    for k in [7,30,90]:a[f'ret{k}']=c/c.shift(k)-1
    a['quote_proxy']=v*c
    a['q20']=a.quote_proxy.shift(1).rolling(20,min_periods=20).median()
    a['vboost']=a.quote_proxy/(a.q20+1e-9)
    a['volmed20']=a.quote_proxy.shift(1).rolling(20,min_periods=20).median()
    a['atr_frac']=a.atr14/c
    a['break20']= (c>a.high20prev) & (prev<=a.high20prev.shift(1))
    a['break55']= (c>a.high55prev) & (prev<=a.high55prev.shift(1))
    # recovery after confirmed 10d retracement within 30d uptrend, no future price peek
    a['recover']=(c>a.high5prev)&(prev<=a.high5prev.shift(1))&(c>a.ma50)&(a.ret30>.10)&(a.low10prev<a.ma20.shift(1))
    a['bear_reclaim']=(c>a.high10prev)&(prev<=a.high10prev.shift(1))&(a.ret30<-.15)&(c>a.ma10)
    a['validsignal']=a[['open','high','low','close','atr14','volmed20','ret30']].notna().all(axis=1)
    a['start_lag_ms']=(a.index.to_numpy(np.int64)-1)*DAY
    return a

print('DATA read',flush=True)
raw=load_data(); print('DATA usable sources',len(raw),flush=True)
assert 'BTC-USDT' in raw
btc=feature(raw['BTC-USDT'][1]); btc_close=btc.close
btc_reg=(btc_close>btc.ma200)&(btc_close.pct_change(30,fill_method=None)>0)
# combine yesterday's breadth measured only from known histories (conditional-on-future-name issue reported)
F={}
for k,(src,d) in raw.items():
    if len(d)<120:continue
    f=feature(d);F[k]=(src,f)
print('FEATURE candidates',len(F),flush=True)
# Date-level events computed after day close, applied at NEXT open.
calendar=range(START//DAY,END//DAY)
variants=[
 dict(name='TREND20_WIDE',entry='break20',guard=False,wide=3.5,trail='atr',maxpct=.23),
 dict(name='TREND20_BTC_GUARD',entry='break20',guard=True,wide=3.5,trail='atr',maxpct=.23),
 dict(name='TREND55_WIDE',entry='break55',guard=False,wide=4.5,trail='atr',maxpct=.30),
 dict(name='TREND55_BTC_GUARD',entry='break55',guard=True,wide=4.5,trail='atr',maxpct=.30),
 dict(name='RECOVER_TREND',entry='recover',guard=False,wide=3.5,trail='atr',maxpct=.23),
 dict(name='BEAR_RECLAIM',entry='bear_reclaim',guard=False,wide=3.5,trail='atr',maxpct=.23),
 dict(name='TREND20_BTC_PYRAMID',entry='break20',guard=True,wide=3.5,trail='atr',maxpct=.23,pyramid=True),
]
# pre-build signals as of close; due to incomplete point-in-time universe these remain research-only.
signals={v['name']:collections.defaultdict(list) for v in variants}
for k,(src,a) in F.items():
    # same-venue quote_proxy is a lower bound on accessible market volume, not true book depth
    for v in variants:
        x=a.loc[(a.index>=START//DAY-1)&(a.index<END//DAY-1)]
        mask=x[v['entry']].fillna(False)&x.validsignal&x.volmed20.gt(1e5)&x.atr_frac.between(.01,.25)
        # no knowing future weekly bar: daily cumulative past only
        if v['entry'] in ('break20','break55','recover'):
            mask &= x.ret30.gt(-.25) & x.ma20.gt(x.ma50*.85)
        if v['guard']:
            common=btc_reg.reindex(x.index).fillna(False)
            mask &= common
        u=x.loc[mask]
        for day,r in u.iterrows():
            # rank observable: 30d positive relative BTC and volume vs prior days; penalty extreme atr
            btc_r=float(btc.ret30.get(day,np.nan))
            rs=float(r.ret30)-btc_r if np.isfinite(btc_r) else float(r.ret30)
            score=rs+min(float(r.vboost),4)*.025-(max(float(r.atr_frac),.01))*.35
            signals[v['name']][day+1].append((score,k,float(r.atr14),float(r.volmed20),float(r.close),src))
for name in signals:
    for dt in signals[name]:signals[name][dt].sort(key=lambda x:(-x[0],x[1]))
print('SIGNALS', {n:sum(len(v) for v in dd.values()) for n,dd in signals.items()},flush=True)

def simulate(v,fee=.003,slip=.001,top_exclude=(),risk=.004,cap=.12,particip=.005):
    x=signals[v['name']]
    cash=100000.;positions={};cooldown={};closed=[];navs=[];oldpeak=cash;maxdd=0.;censor=0;mark={};yr_last={};trade_id=0
    for day in calendar:
        # At the OPEN only: process gaps/forced missing-bar exits. Intraday stop fills
        # are NOT known yet and cannot finance an entry at this morning's open.
        for k,p in list(positions.items()):
            a=F[k][1];r=a.loc[day] if day in a.index else None
            if r is None or not np.isfinite(r.open) or not np.isfinite(r.low):
                price=p['lastclose']*.90;reason='MISSING_BAR_CENSOR';censor+=1
            elif float(r.open)<=p['stop']:
                price=float(r.open);reason='GAP_BELOW_STOP'
            else:
                price=None;reason=None
            if price is not None:
                execp=price*(1-slip);proceeds=p['units']*execp*(1-fee);cash+=proceeds
                net=proceeds-p['spent']
                closed.append(dict(pair=k,entry_day=p['entry_day'],exit_day=day,entry_price=p['entryprice'],exit_price=execp,initial_stop=p['initialstop'],exit_reason=reason,entry_notional=p['notional'],net_usd=net,net_return_pct=100*net/p['spent'],mfe_pct=100*(p['high_water']/p['entryprice']-1),mae_pct=100*(p['low_water']/p['entryprice']-1),holding_days=day-p['entry_day'],venue=F[k][0]))
                cooldown[k]=day+3;del positions[k]
        # When a prior-day winner has already lifted its stop beyond entry+costs,
        # finance a LIMITED new leg at today's open. It uses only yesterday's
        # close and yesterday's precommitted stop. No lookahead or unpaid capital.
        if v.get('pyramid',False):
            for k,p in sorted(positions.items(),key=lambda kv:kv[0]):
                if p['adds']>=2:continue
                if p['stop']<p['entryprice']*1.015:continue
                origR=p['entryprice']-p['initialstop']
                req=(1.5 if p['adds']==0 else 3.0)*origR
                if p['lastclose'] < p['entryprice']+req:continue
                a=F[k][1];r=a.loc[day] if day in a.index else None
                if r is None or not np.isfinite(r.open) or float(r.open)<=0:continue
                px=float(r.open)*(1+slip)
                if px<=p['stop']:continue
                nav=cash+sum(pp['units']*(float(F[kk][1].loc[day].open) if day in F[kk][1].index and np.isfinite(F[kk][1].loc[day].open) else pp['lastclose']) for kk,pp in positions.items())
                risk_per_unit=(px-p['stop'])/px
                prevol=float(a.loc[day-1].volmed20) if day-1 in a.index and np.isfinite(a.loc[day-1].volmed20) else 0
                notional=min(nav*.06,nav*.002/max(risk_per_unit,.01),prevol*particip,cash/(1+fee),max(0.,nav*.22-p['notional']))
                if notional<100:continue
                units=notional/px;cash-=notional*(1+fee)
                p['units']+=units;p['spent']+=notional*(1+fee);p['notional']+=notional;p['adds']+=1
        # New entries at next-day open; not using day's high, low, close for selection.
        for score,k,atr,medianvol,signal_close,src in x.get(day,[]):
            if k in top_exclude or k in positions or day<cooldown.get(k,0) or len(positions)>=6:continue
            a=F[k][1];r=a.loc[day] if day in a.index else None
            if r is None or not np.isfinite(r.open) or float(r.open)<=0:continue
            px=float(r.open)*(1+slip)
            dist=min(max(v['wide']*atr,.05*px),v['maxpct']*px)
            stop=px-dist
            # nav at open from same day's OPEN only
            nav=cash
            for kk,pp in positions.items():
                aa=F[kk][1];rr=aa.loc[day] if day in aa.index else None
                pr=float(rr.open) if rr is not None and np.isfinite(rr.open) else pp['lastclose']
                nav+=pp['units']*pr
            notional=min(nav*cap,nav*risk/max(dist/px,1e-6),medianvol*particip,cash/(1+fee))
            if notional<100:continue
            units=notional/px;cost=notional*(1+fee);cash-=cost
            positions[k]=dict(units=units,spent=cost,notional=notional,entryprice=px,entry_day=day,initialstop=stop,stop=stop,high_water=px,low_water=px,lastclose=px,atr=atr,adds=0)
            # Initial stop is active in entry day, even though not known low at entry; checks after entry at open.
        for k,p in list(positions.items()):
            a=F[k][1];r=a.loc[day] if day in a.index else None
            if r is None or not np.isfinite(r.close):continue
            r_open=float(r.open);r_low=float(r.low);r_high=float(r.high);r_close=float(r.close)
            if r_low<=p['stop']:
                # Worst-case OHLC assumption: precommitted stop is hit when day low crosses.
                # No same-day reinvestment of the intraday sale.
                exitp=min(r_open,p['stop'])*(1-slip)
                proceeds=p['units']*exitp*(1-fee);cash+=proceeds
                net=proceeds-p['spent'];closed.append(dict(pair=k,entry_day=p['entry_day'],exit_day=day,entry_price=p['entryprice'],exit_price=exitp,initial_stop=p['initialstop'],exit_reason='ENTRY_DAY_STOP_ADVERSE' if p['entry_day']==day else 'STOP_PRECOMMITTED',entry_notional=p['notional'],net_usd=net,net_return_pct=100*net/p['spent'],mfe_pct=100*(p['high_water']/p['entryprice']-1),mae_pct=100*(min(p['low_water'],r_low)/p['entryprice']-1),holding_days=day-p['entry_day'],venue=F[k][0]));cooldown[k]=day+3;del positions[k];continue
            p['high_water']=max(p['high_water'],r_high);p['low_water']=min(p['low_water'],r_low)
            p['lastclose']=r_close
            # STOP for next day based on info learned at daily close; never lower stop.
            atr_today=float(r.atr14) if np.isfinite(r.atr14) else p['atr']
            newstop=max(p['initialstop'],p['high_water']-v['wide']*atr_today)
            # price can close below a newly raised stop; liquidate at NEXT open, not retroactively.
            p['stop']=max(p['stop'],newstop)
        nav=cash+sum(pp['units']*pp['lastclose'] for pp in positions.values())
        oldpeak=max(oldpeak,nav);maxdd=min(maxdd,nav/oldpeak-1)
        navs.append((day,nav,len(positions)))
        if day==pd.Timestamp('2022-12-31',tz='UTC').value//1000000//DAY:yr_last[2022]=nav
    # ALL positions liquidated last available close at final day with fees and slippage; no 2024 use.
    for k,p in list(positions.items()):
        exitp=p['lastclose']*(1-slip);proceeds=p['units']*exitp*(1-fee);cash+=proceeds
        net=proceeds-p['spent'];closed.append(dict(pair=k,entry_day=p['entry_day'],exit_day=calendar[-1],entry_price=p['entryprice'],exit_price=exitp,initial_stop=p['initialstop'],exit_reason='END_2023',entry_notional=p['notional'],net_usd=net,net_return_pct=100*net/p['spent'],mfe_pct=100*(p['high_water']/p['entryprice']-1),mae_pct=100*(p['low_water']/p['entryprice']-1),holding_days=calendar[-1]-p['entry_day'],venue=F[k][0]))
    df=pd.DataFrame(closed); nd=pd.DataFrame(navs,columns=['day','nav','open_positions']);n22=yr_last.get(2022,100000.)
    tops=df.groupby('pair').net_usd.sum().sort_values(ascending=False) if len(df) else pd.Series(dtype=float)
    return dict(policy=v['name'],fee_side=fee,slip_side=slip,trades=len(df),unique_pairs=df.pair.nunique() if len(df) else 0,nav=float(cash),ret_pct=100*(cash/100000-1),ret2022_pct=100*(n22/100000-1),ret2023_pct=100*(cash/n22-1),max_dd_pct=100*maxdd,mean_trade_pct=float(df.net_return_pct.mean()) if len(df) else None,median_trade_pct=float(df.net_return_pct.median()) if len(df) else None,median_hold=float(df.holding_days.median()) if len(df) else None,profit_concentration_top3=float(tops.iloc[:3].sum()),top_pairs=list(tops.head(3).index),gap_censors=censor),df,nd

if __name__=='__main__':
    report=[];best=[]
    for v in variants:
        r,tr,nav=simulate(v);report.append(r); print('BASE',r,flush=True)
        tr.to_csv(OUT/(v['name']+'_TRADES.csv'),index=False);nav.to_csv(OUT/(v['name']+'_NAV.csv'),index=False)
        r2,_,_=simulate(v,fee=.006,slip=.002); print('STRESS',r2,flush=True)
        if len(tr):
            rr,_,_=simulate(v,fee=.006,slip=.002,top_exclude=set(r['top_pairs']));print('EXCLUDE_3_DOUBLE',rr,flush=True)
        report.append({**r2,'policy':v['name']+'_DOUBLE_COST'})
        if len(tr):report.append({**rr,'policy':v['name']+'_EXCLUDE_3_DOUBLE'})
    pd.DataFrame(report).to_csv(OUT/'V12_MULTIYEAR_TREND_STRESS.csv',index=False)
