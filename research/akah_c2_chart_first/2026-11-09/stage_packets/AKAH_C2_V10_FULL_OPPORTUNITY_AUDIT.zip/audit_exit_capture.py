import pandas as pd,numpy as np,zipfile,glob,io,json,os
P='/mnt/data/AKAH_C2_V10_OPPORTUNITY_ATLAS';H=3600000;END=1704067200000
tr=pd.read_csv('/mnt/data/AKAH_C2_V9/defensive_120h_trades.csv')
relevant=set(tr.pair);files=sorted(glob.glob('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip'))
raw={}
for f in files:
 with zipfile.ZipFile(f) as z:
  for n in z.namelist():
   if not n.startswith('hourly/') or not n.endswith('.csv.gz'):continue
   k=n[len('hourly/'):-len('.csv.gz')];venue,pair=k.split('_',1)
   if pair not in relevant:continue
   if pair in raw and venue!='KUCOIN':continue
   d=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=['unix_ms','open','high','low','close'])
   d=d[(d.unix_ms>0)&(d.unix_ms<END)].dropna().sort_values('unix_ms').drop_duplicates('unix_ms')
   raw[pair]={'venue':venue,'d':d}
rows=[]
for r in tr.itertuples(index=False):
 d=raw.get(r.pair,{}).get('d');
 if d is None:continue
 t=d.unix_ms.to_numpy(np.int64);o=d.open.to_numpy(float);c=d.close.to_numpy(float);h=d.high.to_numpy(float);l=d.low.to_numpy(float)
 j=np.searchsorted(t,r.entry_ms);k=np.searchsorted(t,r.exit_ms)
 if j>=len(t) or t[j]!=r.entry_ms:continue
 held=d.iloc[j:k];
 if held.empty:continue
 contiguous=(len(held)==(r.exit_ms-r.entry_ms)//H and t[k-1]-t[j]==(len(held)-1)*H)
 max_close=max(float(held.close.max()),float(r.entry));max_high=max(float(held.high.max()),float(r.entry));min_low=float(held.low.min())
 realized_before_fee=100*(r.exit/r.entry-1)
 available_close=100*(max_close/r.entry-1)
 oracle_high=100*(max_high/r.entry-1)
 mfe_capture=realized_before_fee/available_close if available_close>0 else np.nan
 r0={'pair':r.pair,'year':r.year,'entry_ms':r.entry_ms,'exit_ms':r.exit_ms,'holding_h':r.hours,'entry':r.entry,'exit':r.exit,'net_return_pct':r.ret_pct,
     'realized_usd':r.realized_usd,'realized_gross_pct':realized_before_fee,'best_close_gross_pct':available_close,'best_high_gross_pct':oracle_high,
     'worst_low_gross_pct':100*(min_low/r.entry-1),'fraction_of_best_close_realized':mfe_capture,
     'gross_points_left_vs_best_close':available_close-realized_before_fee,'continuous_holding':contiguous}
 for hh in (24,72,168):
  j2=np.searchsorted(t,r.exit_ms+hh*H,side='left');
  a=d.iloc[k:j2]
  r0[f'post_exit_max_close_{hh}h_pct']=100*(float(a.close.max())/r.exit-1) if len(a)>0 and t[j2-1]-t[k]==(len(a)-1)*H and t[k]==r.exit_ms else np.nan
  r0[f'post_exit_max_high_{hh}h_pct']=100*(float(a.high.max())/r.exit-1) if len(a)>0 and t[j2-1]-t[k]==(len(a)-1)*H and t[k]==r.exit_ms else np.nan
  r0[f'post_exit_end_close_{hh}h_pct']=100*(float(a.close.iloc[-1])/r.exit-1) if len(a)==hh and t[j2-1]==r.exit_ms+(hh-1)*H else np.nan
 rows.append(r0)
df=pd.DataFrame(rows)
df.to_csv(P+'/C2_V10_V9_TRADE_MFE_MAE_AND_POST_EXIT.csv',index=False)
summary=[]
for year,g in list(df.groupby('year'))+[('all',df)]:
 if g.empty:continue
 positive=g[g.best_close_gross_pct>0]
 d={'year':year,'n':len(g),'pairs':g.pair.nunique(),'median_ret_net_pct':g.net_return_pct.median(),'positive_realized_pct':100*(g.net_return_pct>0).mean(),
    'median_mfe_close_pct':g.best_close_gross_pct.median(),'median_mae_low_pct':g.worst_low_gross_pct.median(),
    'median_gross_points_left_vs_mfe':g.gross_points_left_vs_best_close.median(),
    'pct_trade_retrace_over_5pp_from_mfe':100*(g.gross_points_left_vs_best_close>5).mean(),
    'pct_positive_mfe_but_net_loss':100*((g.best_close_gross_pct>3)&(g.net_return_pct<0)).mean(),
    'median_capture_ratio_when_positive':positive.fraction_of_best_close_realized.median(),
    'pct_contiguous':100*g.continuous_holding.mean()}
 for h in (24,72,168):
  e=g[f'post_exit_end_close_{h}h_pct'];m=g[f'post_exit_max_close_{h}h_pct'];d[f'post_exit_complete_n_{h}h']=int(e.notna().sum());d[f'post_exit_median_end_{h}h_pct']=float(e.median());d[f'post_exit_pct_regain_more_5pct_{h}h']=float(100*(m.dropna()>5).mean())
 summary.append(d)
ss=pd.DataFrame(summary);ss.to_csv(P+'/C2_V10_V9_EXIT_CAPTURE_SUMMARY.csv',index=False)
print(ss.to_string(index=False),flush=True)
print('top forgone',df.sort_values('gross_points_left_vs_best_close',ascending=False)[['pair','year','net_return_pct','best_close_gross_pct','gross_points_left_vs_best_close','post_exit_max_close_168h_pct']].head(15).to_string(index=False),flush=True)
