import pandas as pd,numpy as np,zipfile,glob,io
P='/mnt/data/AKAH_C2_V10_OPPORTUNITY_ATLAS';H=3600000;END=1704067200000
tr=pd.read_csv('/mnt/data/AKAH_C2_V9/defensive_120h_trades.csv');symbols=set(tr.pair)
raw={}
for f in sorted(glob.glob('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip')):
 with zipfile.ZipFile(f) as z:
  for n in z.namelist():
   if not n.startswith('hourly/') or not n.endswith('.csv.gz'):continue
   key=n[len('hourly/'):-len('.csv.gz')];venue,pair=key.split('_',1)
   if pair not in symbols or (pair in raw and venue!='KUCOIN'):continue
   d=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=['unix_ms','open','close','high','low']);d=d[(d.unix_ms>0)&(d.unix_ms<END)].dropna().sort_values('unix_ms').drop_duplicates('unix_ms');raw[pair]=d
rows=[]
for r in tr.itertuples(index=False):
 d=raw.get(r.pair);
 if d is None:continue
 t=d.unix_ms.to_numpy(np.int64);o=d.open.to_numpy(float);c=d.close.to_numpy(float)
 i=np.searchsorted(t,r.entry_ms)
 if i>=len(t) or t[i]!=r.entry_ms:continue
 row={'pair':r.pair,'year':r.year,'entry_ms':int(r.entry_ms),'realized_v9_net_pct':r.ret_pct}
 for horizon in [12,24,48,72,96,120,168,240,336]:
  jj=np.searchsorted(t,r.entry_ms+horizon*H)
  if jj<len(t) and t[jj]==r.entry_ms+horizon*H and jj-i==horizon:
   # static notional, 0.30% per side, applies to exact same initial entry, ignoring portfolio capacity/reinvestment
   row[f'hold_{horizon}h_net_pct']=100*((o[jj]/r.entry)*(1-.003)/(1+.003)-1)
  else:row[f'hold_{horizon}h_net_pct']=np.nan
 if i+336<len(t) and t[i+336]==r.entry_ms+336*H:
  window=c[i:i+337];max_i=window.argmax()
  row['oracle_336h_best_close_pct']=100*((window[max_i]/r.entry)*(1-.003)/(1+.003)-1)
  row['oracle_336h_peak_after_h']=int(max_i)
 else:row['oracle_336h_best_close_pct']=np.nan;row['oracle_336h_peak_after_h']=np.nan
 rows.append(row)
df=pd.DataFrame(rows);df.to_csv(P+'/C2_V10_SAME_ENTRY_EXIT_HORIZON_MATRIX.csv',index=False)
s=[]
for year,g in list(df.groupby('year'))+[('all',df)]:
 for horizon in [12,24,48,72,96,120,168,240,336]:
  x=g[f'hold_{horizon}h_net_pct'].dropna()
  s.append({'year':year,'holding_h':horizon,'n':len(x),'win_rate_pct':100*(x>0).mean() if len(x) else np.nan,'mean_net_pct':x.mean(),'median_net_pct':x.median(),'p10_net_pct':x.quantile(.1),'p90_net_pct':x.quantile(.9),'oracle_336h_mean_net_pct':g.oracle_336h_best_close_pct.mean(),'oracle_336h_median_net_pct':g.oracle_336h_best_close_pct.median()})
ss=pd.DataFrame(s);ss.to_csv(P+'/C2_V10_SAME_ENTRY_EXIT_HORIZON_SUMMARY.csv',index=False)
print(ss.to_string(index=False))
