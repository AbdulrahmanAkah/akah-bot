import pandas as pd,numpy as np,zipfile,io,os
P='/mnt/data/AKAH_C2_V10_OPPORTUNITY_ATLAS';s=[];rows=[];H=3600000
w=pd.read_csv(P+'/C2_V10_ALL_CONFIRMED_SWING_WAVES.csv.gz');src=dict(zip(w.pair,w.venue))
with zipfile.ZipFile('/mnt/data/AKAH_C2_V8_ALL_1PCT_CANDLES.zip') as z:
 for n in z.namelist():
  if not n.endswith('.csv.gz'):continue
  key=os.path.basename(n).replace('EVENTS_','').replace('.csv.gz','');venue,pair=key.split('_',1)
  if src.get(pair)!=venue:continue
  cols=['pair','year','signal_ms','ret24_pct','ret72_pct','ret168_pct','btc_past_168h_pct','past168_pct','relative_base_volume_168h','liquidity_band_proxy']
  d=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=lambda c:c in cols).sort_values('signal_ms');d=d[d.year.isin([2022,2023])];
  for col in cols:
   if col not in d:d[col]=np.nan
  if d.empty:continue
  # Chronological, fixed-spacing, no hindsight filtering for selection
  mask=np.zeros(len(d),bool);last=-1e30
  for i,t in enumerate(d.signal_ms.to_numpy('int64')):
   if t-last>=168*H:mask[i]=1;last=t
  d=d.loc[mask].copy();d['btc_regime']=np.select([d.btc_past_168h_pct<0,d.btc_past_168h_pct>=0],['BTC_DOWN','BTC_UP'],default='UNKNOWN')
  d['asset_7d_state']=np.select([d.past168_pct<0,d.past168_pct>=0],['ASSET_DOWN','ASSET_UP'],default='UNKNOWN')
  d['liq_approx']=np.where(d.liquidity_band_proxy.eq('LIQ_HIGH_1M_24H_PROXY'),'HIGH_1M_PROXY','OTHER')
  rows.append(d)
e=pd.concat(rows,ignore_index=True)
e.to_csv(P+'/C2_V10_TIME_SPACED_IMPULSE_RESULTS.csv.gz',index=False,compression='gzip')
out=[]
for cols in [['year'],['year','btc_regime'],['year','btc_regime','asset_7d_state'],['year','btc_regime','liq_approx']]:
 for key,g in e.groupby(cols):
  d=dict(zip(cols,key if isinstance(key,tuple) else (key,)));d['events']=len(g);d['pairs']=g.pair.nunique()
  for h in [24,72,168]:
   a=pd.to_numeric(g[f'ret{h}_pct'],errors='coerce').dropna()-.6
   d[f'ret{h}_known_n']=len(a);d[f'ret{h}_mean_net_pct']=float(a.mean()) if len(a) else np.nan
   d[f'ret{h}_median_net_pct']=float(a.median()) if len(a) else np.nan;d[f'ret{h}_winrate_pct']=float(100*(a>0).mean()) if len(a) else np.nan
  out.append(d)
r=pd.DataFrame(out);r.to_csv(P+'/C2_V10_ALL_IMPULSE_BTC_AND_ASSET_REGIME_OUTCOMES.csv',index=False)
print(r[['year','btc_regime','asset_7d_state','events','ret72_known_n','ret72_mean_net_pct','ret72_median_net_pct','ret72_winrate_pct']].to_string(index=False),flush=True)
