import pandas as pd, numpy as np, zipfile, io, glob, os, json, time, collections
P='/mnt/data/AKAH_C2_V10_OPPORTUNITY_ATLAS';H=3600000
BEGIN=1640995200000;END=1704067200000
PRED='/mnt/data/AKAH_C2_V9/predicted_2022_2023.pkl'
RALLY_RETRACES=(.01,.05,.10,.20)
# 'Original source priority' is KuCoin series if it has >=1h historical coverage, else Binance; do not stitch mismatched venues.
archives=sorted(glob.glob('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip'))
member={}
for f in archives:
 with zipfile.ZipFile(f) as z:
  for n in z.namelist():
   if n.startswith('hourly/') and n.endswith('.csv.gz'):
    k=n[len('hourly/'):-len('.csv.gz')]; venue, pair=k.split('_',1)
    if venue=='KUCOIN' or pair not in member: member[pair]=(f,n,venue)
print('SOURCE_PAIRS',len(member),flush=True)
pred=pd.read_pickle(PRED)
pred['guard']=((pred.score>=2.234)&(pred.relative_strength_168>0)&(pred.btc_168>0)&(pred.btc_720>0)&(pred.btc_200d>0))
pred=pred.sort_values(['pair','signal_ms'])
pred_by={pair:{'t':g.signal_ms.to_numpy(np.int64),'guard_t':g.loc[g.guard,'signal_ms'].to_numpy(np.int64),'model_t':g.loc[g.score>=2.234,'signal_ms'].to_numpy(np.int64)} for pair,g in pred.groupby('pair')}
trade=pd.read_csv('/mnt/data/AKAH_C2_V9/defensive_120h_trades.csv')
tr_by={pair:g.entry_ms.to_numpy(np.int64) for pair,g in trade.sort_values('entry_ms').groupby('pair')}
wave_rows=[]; event_rows=[]; coverage_rows=[]
def has_between(t, start, end):
 if t is None or len(t)==0:return False
 j=np.searchsorted(t,start,side='left');return j<len(t) and t[j]<=end

def track_segment(pair,venue,t,o,h,l,c,v,s,e,th):
 # Drawdown-verified turning points, based on hourly CLOSES only; low/peak known only retrospectively.
 if e-s<3:return
 i=s;low=i;peak=None;active=False
 while i<e:
  p=c[i]
  if not active:
   if p<c[low]:low=i
   if p>=c[low]*(1+th):active=True;peak=i
  else:
   if p>c[peak]:peak=i
   if p<=c[peak]*(1-th):
    if peak>low and c[low]>0 and c[peak]>c[low]:
     yy=int(pd.Timestamp(t[low],unit='ms',tz='UTC').year)
     if yy in (2022,2023):
      up_pct=100*(c[peak]/c[low]-1)
      # all +1% hourly candles, without requiring future 72/168h results
      cs=o[low+1:peak+1]; ce=c[low+1:peak+1];
      ix=np.flatnonzero((cs>0)&(ce/cs>=1.01))
      first=low+1+int(ix[0]) if len(ix) else None
      valid_pred=pred_by.get(pair,{})
      cand_sig=valid_pred.get('t');g_sig=valid_pred.get('guard_t');msig=valid_pred.get('model_t')
      v9entry=tr_by.get(pair)
      inside=lambda a:has_between(a,int(t[low]),int(t[peak]))
      first_stage=100*(c[first]-c[low])/(c[peak]-c[low]) if first is not None and c[peak]>c[low] else np.nan
      # First actual threshold touch, measured causally at close of crossing hour
      cross=low+int(np.flatnonzero(c[low:peak+1]>=c[low]*(1+th))[0]);
      q_proxy=np.nan
      if cross-24>=s and t[cross-1]-t[cross-24]==23*H:
       q_proxy=float(np.sum(np.maximum(v[cross-24:cross],0)*c[cross-24:cross]))
      # Maximum close in wave is ex post. The first recognized reversal occurs at t[i].
      wave_rows.append(dict(pair=pair,venue=venue,year=yy,threshold_pct=100*th,
        trough_ms=int(t[low]),peak_ms=int(t[peak]),confirm_ms=int(t[i]),
        trough_close=float(c[low]),peak_close=float(c[peak]),confirm_close=float(c[i]),
        rise_pct=float(up_pct),duration_h=int((t[peak]-t[low])//H),confirmation_lag_h=int((t[i]-t[peak])//H),
        first_impulse_ms=int(t[first]) if first is not None else np.nan,
        first_impulse_position_pct=float(first_stage) if np.isfinite(first_stage) else np.nan,
        first_impulse_delay_h=int((t[first]-t[low])//H) if first is not None else np.nan,
        has_impulse=bool(first is not None),has_v9_model_input=inside(cand_sig),
        has_v9_score_top10=inside(msig),has_v9_guard_pass=inside(g_sig),
        has_v9_executed_entry=inside(v9entry),
        liquidity_proxy_at_threshold_cross=q_proxy,
        liquid_1m=bool(np.isfinite(q_proxy) and q_proxy>=1e6),liquid_5m=bool(np.isfinite(q_proxy) and q_proxy>=5e6),
        under_24h=int((t[peak]-t[low])//H)<24))
    low=i;peak=None;active=False
  i+=1

start=time.time(); read_n=0;errors=[]
for pair,(file,n,venue) in sorted(member.items()):
 try:
  with zipfile.ZipFile(file) as z:
   a=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=['unix_ms','open','high','low','close','base_volume'])
  a=a[(a.unix_ms>0)&(a.unix_ms<END)].dropna(subset=['unix_ms','open','high','low','close']).sort_values('unix_ms').drop_duplicates('unix_ms')
  a=a[(a.close>0)&(a.open>0)&(a.high>0)&(a.low>0)].copy()
  if a.empty:continue
  t=a.unix_ms.to_numpy(np.int64);o=a.open.to_numpy(float);h=a.high.to_numpy(float);l=a.low.to_numpy(float);c=a.close.to_numpy(float);v=a.base_volume.fillna(0).to_numpy(float)
  segs=np.r_[0,np.flatnonzero(np.diff(t)!=H)+1,len(t)]
  for s,e in zip(segs[:-1],segs[1:]):
   if t[e-1]<BEGIN:continue
   for th in RALLY_RETRACES:track_segment(pair,venue,t,o,h,l,c,v,int(s),int(e),th)
  for yr in (2022,2023):
   sub=(t>=BEGIN if yr==2022 else t>=1672531200000)&(t<(1672531200000 if yr==2022 else END))
   count=int(sub.sum()); pct=(c[sub]/o[sub]-1)*100
   coverage_rows.append(dict(pair=pair,venue=venue,year=yr,hourly_candles=count,impulses_ge_1pct=int((pct>=1).sum()),impulses_ge_3pct=int((pct>=3).sum()),impulses_ge_5pct=int((pct>=5).sum())))
  read_n+=1
  if read_n%50==0:print('PROGRESS',read_n,'/',len(member),'waves',len(wave_rows),'secs',round(time.time()-start,1),flush=True)
 except Exception as e:errors.append({'pair':pair,'error':str(e)[:200]});print('ERROR',pair,str(e)[:100],flush=True)
w=pd.DataFrame(wave_rows); cov=pd.DataFrame(coverage_rows)
w.to_csv(P+'/C2_V10_ALL_CONFIRMED_SWING_WAVES.csv.gz',index=False,compression='gzip')
cov.to_csv(P+'/C2_V10_ALL_ASSET_YEAR_IMPULSES.csv',index=False)
grp=w.groupby(['threshold_pct','year'])
s=grp.agg(waves=('pair','size'),assets=('pair','nunique'),median_rise_pct=('rise_pct','median'),mean_rise_pct=('rise_pct','mean'),median_hours_to_peak=('duration_h','median'),pct_with_1pct_bar=('has_impulse','mean'),pct_with_v9_model_input=('has_v9_model_input','mean'),pct_with_v9_top_decile=('has_v9_score_top10','mean'),pct_with_v9_guard=('has_v9_guard_pass','mean'),pct_with_v9_actual_entry=('has_v9_executed_entry','mean'),liquid1m=('liquid_1m','sum'),liquid5m=('liquid_5m','sum')).reset_index()
for f in ['pct_with_1pct_bar','pct_with_v9_model_input','pct_with_v9_top_decile','pct_with_v9_guard','pct_with_v9_actual_entry']:s[f]=100*s[f]
s.to_csv(P+'/C2_V10_WAVE_CAPTURE_FUNNEL.csv',index=False)
for cutoff in [5,10,20,50]:
 b=w[(w.threshold_pct==5)&(w.rise_pct>=cutoff)]
 by=b.groupby(['year','liquid_5m']).agg(waves=('pair','size'),median_rise=('rise_pct','median'),with_impulse=('has_impulse','sum'),v9_guard_pass=('has_v9_guard_pass','sum'),v9_entry=('has_v9_executed_entry','sum')).reset_index();by.insert(0,'wave_rise_min_pct',cutoff)
 by.to_csv(P+f'/C2_V10_BIG_WAVES_GE_{cutoff}PCT.csv',index=False)
# characteristics of V9-missed ≥20% waves for concrete case studies, importantly avoid record choosing on largest mere percent for low-liq
case=w[(w.threshold_pct==.05*100)&(w.rise_pct>=20)&(w.liquid_5m)&(~w.has_v9_executed_entry)].sort_values(['year','rise_pct'],ascending=[True,False])
case.groupby(['year'],group_keys=False).head(25).to_csv(P+'/C2_V10_LARGE_LIQUID_MISSED_WAVES_CASES.csv',index=False)
# selected opportunity details across 5%,10%,20%: how many 1%-less waves? 1% not good exhaustive front-end
op=w[(w.threshold_pct==5)&(w.rise_pct>=10)]
case=op[(op.liquid_5m)&(~op.has_impulse)].sort_values('rise_pct',ascending=False)
case.head(100).to_csv(P+'/C2_V10_RALLIES_WITHOUT_1PCT_HOURLY_CANDLE.csv',index=False)
print('FULL_SUMMARY\n',s.to_string(index=False),flush=True)
print('COVERAGE',cov.groupby('year')[['hourly_candles','impulses_ge_1pct','impulses_ge_3pct','impulses_ge_5pct']].sum().to_string(),flush=True)
print('CASE',len(case),'errors',errors,'time_sec',time.time()-start,flush=True)
json.dump({'input_raw_zip_files':archives,'pairs_in_archives':len(member),'pairs_read':read_n,'errors':errors,'analysis_years':[2022,2023],'min_move_definitions':[1,5,10,20],'price_basis':'hourly CLOSE-only retrospectively confirmed symmetric reversal','survivorship':'C2 plan not PIT-certified','future_data':'used only for offline wave labels; never used for live signals','benchmark':'V9 predicted signals have previously applied outcome-availability and liquidity filters','time_sec':time.time()-start},open(P+'/C2_V10_AUDIT.json','w'),indent=2)
