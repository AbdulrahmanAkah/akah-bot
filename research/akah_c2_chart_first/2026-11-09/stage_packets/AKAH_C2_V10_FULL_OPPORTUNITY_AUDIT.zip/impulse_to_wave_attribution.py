import pandas as pd,numpy as np,zipfile,io,os
P='/mnt/data/AKAH_C2_V10_OPPORTUNITY_ATLAS';w=pd.read_csv(P+'/C2_V10_ALL_CONFIRMED_SWING_WAVES.csv.gz');w=w[w.threshold_pct==5].copy()
by={pair:g.sort_values('trough_ms') for pair,g in w.groupby('pair')};nreads=0;s=[];early=[]
with zipfile.ZipFile('/mnt/data/AKAH_C2_V8_ALL_1PCT_CANDLES.zip') as z:
 for name in z.namelist():
  if not name.endswith('.csv.gz') or not name.startswith('ALL_CANDLES/EVENTS_'):continue
  base=os.path.basename(name).replace('EVENTS_','').replace('.csv.gz','');ven,pair=base.split('_',1)
  waves=by.get(pair)
  if waves is None or ven !=waves.venue.iloc[0]:continue
  cols=['pair','signal_ms','year','past24_pct','past168_pct','close_location','relative_base_volume_168h','zero_range_share_168h','btc_past_168h_pct','liquidity_band_proxy']
  d=pd.read_csv(io.BytesIO(z.read(name)),compression='gzip',usecols=lambda c:c in cols)
  d=d[d.year.isin([2022,2023])];
  if 'liquidity_band_proxy' not in d:d['liquidity_band_proxy']='UNKNOWN'
  for col in ['past24_pct','past168_pct','close_location','relative_base_volume_168h','zero_range_share_168h','btc_past_168h_pct']:
   if col not in d:d[col]=np.nan
  if d.empty:continue
  starts=waves.trough_ms.to_numpy('int64');ends=waves.peak_ms.to_numpy('int64');a=d.signal_ms.to_numpy('int64');j=np.searchsorted(starts,a,'right')-1
  ok=(j>=0);within=np.zeros(len(d),bool);within[ok]=(a[ok]<=ends[j[ok]])
  amp=np.full(len(d),np.nan);liq=np.zeros(len(d),bool)
  amp[within]=waves.rise_pct.to_numpy()[j[within]]
  liq[within]=waves.liquid_5m.to_numpy()[j[within]]
  d['in_5pct_upwave']=within;d['wave_gain_pct']=amp;d['liquid_wave5m']=liq
  d['is_first_upbar']=False
  # Find the exact earliest +1% candle in each historical wave (not live signal)
  first=waves.first_impulse_ms.to_numpy('float64');ids=np.flatnonzero(within);d.iloc[ids,d.columns.get_loc('is_first_upbar')]=(a[ids]==first[j[ids]])
  for yy,g in d.groupby('year'):
   s.append(dict(pair=pair,year=yy,impulses=len(g),impulses_in_any_5pct_wave=int(g.in_5pct_upwave.sum()),impulses_in_big_20pct_wave=int((g.wave_gain_pct>=20).sum()),impulses_in_liquid_big20=int(((g.wave_gain_pct>=20)&g.liquid_wave5m).sum())))
  first_big=d[d.is_first_upbar & (d.wave_gain_pct>=20)&d.liquid_wave5m]
  if len(first_big):early.append(first_big.assign(class_label='FIRST_IN_LIQUID_GE20_WAVE'))
  # comparable high-liquidity V8 source label is itself approximate, NOT a reliable market depth proxy
  noise=d[(~d.in_5pct_upwave)&d.liquidity_band_proxy.eq('LIQ_HIGH_1M_24H_PROXY')]
  if len(noise):early.append(noise.assign(class_label='IMPULSE_NOT_IN_CONFIRMED_5_WAVE'))
  nreads+=1
ss=pd.DataFrame(s);ss.to_csv(P+'/C2_V10_IMPULSE_TO_WAVE_BY_PAIR_YEAR.csv',index=False)
print('overall',ss.groupby('year')[['impulses','impulses_in_any_5pct_wave','impulses_in_big_20pct_wave','impulses_in_liquid_big20']].sum().to_string(),flush=True)
print('read',nreads,'of',len(by),'source pairs',flush=True)
e=pd.concat(early,ignore_index=True)
features=['past24_pct','past168_pct','close_location','relative_base_volume_168h','zero_range_share_168h','btc_past_168h_pct']
rows=[]
for (yy,lab),g in e.groupby(['year','class_label']):
 o={'year':yy,'class_label':lab,'events':len(g),'unique_pairs':g.pair.nunique()}
 for feat in features:
  x=pd.to_numeric(g[feat],errors='coerce').replace([np.inf,-np.inf],np.nan).dropna()
  o[feat+'_n']=len(x);o[feat+'_median']=x.median();o[feat+'_p25']=x.quantile(.25);o[feat+'_p75']=x.quantile(.75)
 rows.append(o)
pd.DataFrame(rows).to_csv(P+'/C2_V10_FIRST_IMPULSE_BIG_WAVE_VS_NOISE_FACTOR_PROFILE.csv',index=False)
print(pd.DataFrame(rows)[['year','class_label','events','unique_pairs','past24_pct_median','past168_pct_median','relative_base_volume_168h_median','btc_past_168h_pct_median']].to_string(index=False),flush=True)
