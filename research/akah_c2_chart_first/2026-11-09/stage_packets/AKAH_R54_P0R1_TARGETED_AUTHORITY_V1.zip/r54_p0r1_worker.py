#!/usr/bin/env python3
"""AKAH R54-P0R1 targeted authority evidence extraction. Read-only, no 2024 data."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import traceback
import zipfile

VERSION='R54_P0R1_TARGETED_AUTHORITY_BINDING_V1'
MAX_MEMBER_BYTES=1_000_000
MAX_CODE_BYTES=130_000
MAX_ARCHIVE_FILE=200_000_000
MAX_EVIDENCE_BYTES=3_500_000
MAX_DOWNLOAD_ZIPS=32
YEAR24=re.compile(r'(?<!\d)2024(?!\d)')
SENSITIVE=re.compile(r'(^|[/_.-])(password|secrets?|private.?key|api.?key|credentials?|\.env|token|wallet|account)([/_.-]|$)',re.I)
IGNORE_PATH=re.compile(r'(?i)(?:^|/)(?:__pycache__|\.git|\.venv|node_modules|v15_runtime_spill|cache-validation-|pytest-temp)(?:/|$)')
RELEVANT_NAME=re.compile(r'(?i)(rd33|r50|r53|r42|r44|historical.*universe|universe.*authority|2022|2023|membership|source.*authorit|tape.*witness|pit|execution.*cost|coverage|sha256|gate|manifest|checkpoint|report|results)')
SAFE_EXTS={'.json','.md','.txt','.csv','.py','.log'}
REPO_FILES=[
 '.akah_bot/transition_p38_export_v1/historical_source/scripts/research/run_rd33_temporal_mb_architecture.py',
 '.akah_bot/transition_p38_export_v1/historical_source/src/spotbot/research/rd33_temporal_mb_architecture.py',
 '.akah_bot/transition_p38_export_v1/historical_source/src/spotbot/research/rd33_temporal_mb_replay.py',
 '.akah_bot/transition_p38_export_v1/historical_source/scripts/research/run_rd04_d0_pit_universe_readiness.py',
 '.akah_bot/transition_p38_export_v1/historical_source/scripts/research/run_rd04_d1_pit_universe_replay.py',
 '.akah_bot/transition_p38_export_v1/historical_source/scripts/research/run_rd04_d2_universe_membership_attribution.py',
 '.akah_bot/transition_p38_export_v1/historical_source/src/spotbot/research/rd04_pit_universe.py',
 '.akah_bot/transition_p38_export_v1/historical_source/src/spotbot/research/point_in_time_universe_v2.py',
 '.akah_bot/transition_p38_export_v1/historical_source/data/research/rd18_p3x_a3b_runtime/effective-operational-membership.csv',
 'governance/AKAH_BOT_SYSTEM_CHARTER.json',
]
ARCHIVES_EXACT=[
 'AKAH_R53R1_OUTPUT_ONLY_RECOVERY.zip',
 'AKAH_R50R1_SHA_CHAIN_RECOVERY_ONEPASS.zip',
 'AKAH_R50_CONTINUOUS_SURVIVAL_ONEPASS.zip',
 'AKAH_R53_ARCHITECTURE_TOURNAMENT_ONEPASS.zip',
 'UPLOAD_THIS_AKAH_R53_ARCHITECTURE_RESULTS.zip',
 'UPLOAD_THIS_AKAH_R53R1_RECOVERED_ARCHITECTURE_RESULTS.zip',
]
EXTRA_PATTERNS=('UPLOAD_THIS_AKAH_R53','R53_CONTINUOUS_AND_INDEPENDENT_CHECKPOINT',
                'UPLOAD_THIS_AKAH_R50','UPLOAD_THIS_AKAH_RD33',
                'UPLOAD_THIS_AKAH_R42','UPLOAD_THIS_AKAH_R44')
# Only specific historical authority source, code, manifests, economic summary. Never market rows/trades.
ALLOW_CSV=re.compile(r'(?i)(frozen.*economic.*cells|r50.*baseline|summary.*results|portfolio.*results|comparison.*results)')
BLOCK_CONTENT=re.compile(r'(?i)(raw.*(tape|market|trade|candles|ohlcv)|hourly.*(bars|candles)|trade.*(ledger|rows|events|fills)|private|credentials?|\.env|api.?key|secret|wallet)')

def utcnow():return dt.datetime.now(dt.timezone.utc).isoformat()
def forbidden(s):return bool(YEAR24.search(str(s).replace('\\','/')))
def digest(data):return hashlib.sha256(data).hexdigest()
def dump(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8')+b'\n'
def candidate_safe(name):
    p=str(name).replace('\\','/')
    if forbidden(p) or SENSITIVE.search(p) or BLOCK_CONTENT.search(p) or IGNORE_PATH.search(p):return False
    return True

def read_capped(file,max_size=MAX_CODE_BYTES):
    sz=file.stat().st_size
    if sz>max_size:return None
    with open(file,'rb') as f:data=f.read(max_size+1)
    return data if len(data)<=max_size else None

def safe_entry(name,size):
    p=Path(name.replace('\\','/'))
    if str(p).startswith('/') or ':' in name or '..' in p.parts or not candidate_safe(name):return False
    suffix=p.suffix.lower()
    if suffix not in SAFE_EXTS:return False
    if size>MAX_MEMBER_BYTES:return False
    if suffix=='.csv' and not ALLOW_CSV.search(str(p)):return False
    # Python text is for understanding original policy, not executing it.
    if suffix=='.log' and size>25000:return False
    if suffix=='.py' and size>MAX_CODE_BYTES:return False
    if not RELEVANT_NAME.search(str(p)) and suffix not in ('.json','.md'):return False
    return True

def pin_flags(doc):
    """Extract evident field names only; never turn keyword matches into certifications."""
    if not isinstance(doc,dict):return {'json_type':type(doc).__name__}
    out={'top_level_keys':list(doc)[:100]}
    for k,v in doc.items():
        lk=k.lower()
        if any(z in lk for z in ['status','pass','authority','certif','gate','head','revision','year','sha256','hash','universe','tape','coverage']):
            if isinstance(v,(str,bool,int,float)):
                out.setdefault('primitive_fields',{})[k]=str(v)[:240]
            elif isinstance(v,dict):out.setdefault('nested_keys',{})[k]=list(v)[:50]
    return out

def sha_read(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while True:
            b=f.read(1024*1024)
            if not b:break
            h.update(b)
    return h.hexdigest()

def run(repo,downloads,stamp):
    report_dir=downloads/('AKAH_R54_P0R1_AUTHORITY_'+stamp)
    report_dir.mkdir(parents=True,exist_ok=False)
    events=[];evidence={}; code_files=[]; safe_summaries=[]
    total_ev_bytes=0
    def add_evidence(destination,data,origin):
        nonlocal total_ev_bytes
        if total_ev_bytes+len(data)>MAX_EVIDENCE_BYTES:
            events.append({'level':'WARNING','reason':'evidence_budget_exceeded','source':origin});return False
        if b'-----BEGIN PRIVATE KEY' in data or b'AKIA' in data:
            events.append({'level':'WARNING','reason':'suspicious_content_blocked','source':origin});return False
        if destination in evidence:
            events.append({'level':'WARNING','reason':'duplicate_output_name','source':origin});return False
        evidence[destination]=data;total_ev_bytes+=len(data);return True
    repo_checks=[]
    for rel in REPO_FILES:
        if not candidate_safe(rel):continue
        file=repo.joinpath(*rel.split('/'))
        row={'relative_path':rel,'exists':file.is_file()}
        if row['exists']:
            try:
                row['size_bytes']=file.stat().st_size
                if file.suffix.lower()=='.csv':
                    with open(file,'rb') as f: first=f.readline(4096)
                    row['first_line_header_only']=first.decode('utf-8-sig',errors='replace').strip()[:1200]
                    row['data_rows_read']=0
                elif file.suffix.lower()=='.py':
                    data=read_capped(file)
                    if data is None:row['status']='CODE_TOO_LARGE_FOR_EXTRACTION'
                    else:
                        row['sha256']=digest(data)
                        add_evidence('evidence/repo/'+rel,data,str(file))
                        code_files.append(row['relative_path'])
                elif rel.endswith('AKAH_BOT_SYSTEM_CHARTER.json'):
                    # governance may be huge: size-only for >1 MB; do NOT parse 2024 series.
                    if row['size_bytes']>1_000_000:row['status']='OVERSIZED_GOVERNANCE_SIZE_ONLY'
                    else:
                        data=read_capped(file,1_000_000)
                        row['sha256']=digest(data)
                        try: row['outline']=pin_flags(json.loads(data.decode('utf-8-sig')))
                        except (ValueError,UnicodeError):row['status']='NON_JSON_OR_UNDECODABLE'
                        # Do not copy generic governance document; may contain sensitive state.
            except (OSError,ValueError) as ex:row['error']=str(ex)[:200]
        repo_checks.append(row)

    # Narrow, bounded filename inventory from explicit safe dirs; no recursive walk.
    search_dirs=[
       'governance',
       '.akah_bot/transition_p38_export_v1/historical_source/data',
       '.akah_bot/transition_p38_export_v1/historical_source/data/research',
       '.akah_bot/transition_p38_export_v1/historical_source/data/research/rd18_p3x_a3b_runtime',
       '.akah_bot/transition_p38_export_v1/observer_output',
       'data', 'reports',
    ]
    directory_findings=[]
    for rel in search_dirs:
        dirp=repo.joinpath(*rel.split('/'));found=[];seen=0;truncated=False
        if dirp.is_dir():
            try:
                with os.scandir(dirp) as it:
                    for entry in it:
                        seen+=1
                        if seen>6000:truncated=True;break
                        if candidate_safe(entry.name) and RELEVANT_NAME.search(entry.name):
                            found.append({'name':entry.name,'is_dir':entry.is_dir(follow_symlinks=False)})
            except OSError as ex:events.append({'level':'WARNING','reason':'listdir_failed','path':rel,'error':str(ex)[:150]})
        directory_findings.append({'dir':rel,'exists':dirp.is_dir(),'entries_examined':seen,'truncated':truncated,'matching_names':found[:100]})

    # Downloads root only. Strictly allow named R50/R53 outputs and pinned archives.
    names={n for n in ARCHIVES_EXACT}
    try:
        with os.scandir(downloads) as it:
            for entry in it:
                if entry.is_file(follow_symlinks=False) and not forbidden(entry.name) and not SENSITIVE.search(entry.name):
                    if entry.name.lower().endswith(('.zip','.json','.json.gz')) and any(entry.name.startswith(pre) for pre in EXTRA_PATTERNS):
                        names.add(entry.name)
    except OSError as ex:events.append({'level':'ERROR','reason':'downloads_scan_failed','error':str(ex)})
    names=sorted(names,key=lambda s:(0 if s in ARCHIVES_EXACT else 1,s))[:MAX_DOWNLOAD_ZIPS]
    archives=[];standalone=[]
    for name in names:
        if forbidden(name):continue
        file=downloads/name
        if not file.is_file():
            if name in ARCHIVES_EXACT:archives.append({'filename':name,'status':'MISSING'})
            continue
        if file.suffix.lower()!='.zip':
            standalone.append({'filename':name,'size_bytes':file.stat().st_size,'status':'METADATA_ONLY_NO_CONTENT'})
            continue
        a={'filename':name,'size_bytes':file.stat().st_size,'status':'UNKNOWN','selected_members':[]}
        if a['size_bytes']>MAX_ARCHIVE_FILE:
            a['status']='ARCHIVE_TOO_LARGE';archives.append(a);continue
        try:
            a['zip_sha256']=sha_read(file)
            with zipfile.ZipFile(file) as z:
                members=z.infolist()
                a['entry_count']=len(members)
                a['has_2024_named_member']=any(forbidden(i.filename) for i in members)
                if a['has_2024_named_member']:
                    a['status']='SKIPPED_ENTIRE_ARCHIVE_HAS_2024_NAMED_MEMBER';archives.append(a);continue
                if len(members)>15000:
                    a['status']='ZIP_TOO_MANY_ENTRIES';archives.append(a);continue
                a['status']='SAFE_METADATA_EXTRACTED'
                eligible=[i for i in members if not i.is_dir() and safe_entry(i.filename,i.file_size)]
                # Select high-signal evidence first, forbid raw trade rows or price tapes.
                def priority(i):
                    n=i.filename.lower()
                    score=(30 if 'result' in n or 'authority' in n or 'sha256' in n else 0)
                    score+=(20 if 'r50' in n or 'r53' in n or 'rd33' in n else 0)
                    score+=(10 if 'baseline/' in n or 'witness' in n or 'manifest' in n else 0)
                    score+=(5 if n.endswith('.json') else 0)
                    score-=20 if n.endswith('.py') else 0
                    return (-score,n)
                eligible.sort(key=priority)
                used=0
                for member in eligible[:85]:
                    if used>800_000:break
                    try:
                        with z.open(member) as handle:data=handle.read(member.file_size+1)
                    except (OSError,RuntimeError,ValueError,zipfile.BadZipFile) as ex:
                        a['selected_members'].append({'name':member.filename,'error':str(ex)[:120]});continue
                    if len(data)>MAX_MEMBER_BYTES:continue
                    dest=('evidence/archives/'+re.sub(r'[^a-zA-Z0-9_.-]','_',name)+'/'+member.filename)
                    if not add_evidence(dest,data,f'{name}!{member.filename}'):continue
                    item={'name':member.filename,'size_bytes':len(data),'sha256':digest(data)}
                    if member.filename.lower().endswith('.json'):
                        try:
                            value=json.loads(data.decode('utf-8-sig'))
                            item['outline']=pin_flags(value)
                            if any(w in member.filename.lower() for w in ['result','authority','scope','gate','sha256','manifest']):
                                safe_summaries.append({'archive':name,'member':member.filename,'outline':item['outline']})
                        except (ValueError,UnicodeError):item['json_readable']=False
                    a['selected_members'].append(item)
                    used+=len(data)
        except (OSError,zipfile.BadZipFile,RuntimeError,ValueError) as ex:
            a['status']='ZIP_OPEN_FAILED';a['error']=str(ex)[:200]
        archives.append(a)

    # Git HEAD read-only: never `git checkout`, fetch, update, or modify repo.
    import subprocess
    identity={}
    for key,args in [('branch',['rev-parse','--abbrev-ref','HEAD']),('head',['rev-parse','HEAD'])]:
        try:
            rr=subprocess.run(['git','-C',str(repo)]+args,capture_output=True,text=True,timeout=12)
            identity[key]=rr.stdout.strip() if rr.returncode==0 else 'GIT_ERROR'
        except (OSError,subprocess.TimeoutExpired):identity[key]='GIT_UNAVAILABLE'
    coverage={}
    for role,match in [('RD33','rd33'),('R50','r50'),('R53','r53'),('R53R1','r53r1')]:
        refs=[f'{x["filename"]}!{y["name"]}' for x in archives for y in x.get('selected_members',[]) if match in y.get('name','').lower()]
        coverage[role]={'reference_count':len(refs),'references':refs[:30],'historical_authority_certified':False}
    gate={
      'source_artifacts_retrieved':bool(evidence),'rd33_source_files_retrieved':sum(x['exists'] and 'rd33' in x['relative_path'].lower() for x in repo_checks),
      'r50_archives_opened':sum(x['status']=='SAFE_METADATA_EXTRACTED' and 'R50' in x['filename'] for x in archives),
      'r53_archives_opened':sum(x['status']=='SAFE_METADATA_EXTRACTED' and 'R53' in x['filename'] for x in archives),
      'r50_frozen_12_cell_values_certified':False,
      'r53r1_48_portfolio_results_certified':False,
      'rd33_158_trades_replay_certified':False,
      '2022_2023_hourly_tape_authority_certified':False,
      'pit_c2_historical_certified':False,
      'cost_1x_2x_certified':False,
      'permission_to_execute_economic_tests':False,
      'status':'TARGETED_EVIDENCE_COLLECTED_AWAITING_MANUAL_CAUSAL_AUTHORITY_REVIEW',
      'next':'Inspect selected evidence and bind exact canonical authorities before event census.'
    }
    report={
      'version':VERSION,'timestamp_utc':utcnow(),'repo':str(repo),'downloads':str(downloads),
      'repo_identity':identity,'repo_files':repo_checks,'safe_directories':directory_findings,
      'archives':archives,'standalone_download_metadata':standalone,
      'coverage':coverage,'authority_gate':gate,'warnings':events,
      '2024_market_rows_read':0,'market_rows_read':0,'trade_rows_read':0,'economic_backtests_run':0,
      'repo_mutations':0,'production_changes':0,'live_trading':False,
      'evidence_file_count':len(evidence),'evidence_total_bytes':total_ev_bytes,
    }
    (report_dir/'R54_P0R1_TARGETED_AUTHORITY_REPORT.json').write_bytes(dump(report))
    (report_dir/'R54_P0R1_GATE.json').write_bytes(dump(gate))
    (report_dir/'R54_P0R1_EVIDENCE_INDEX.json').write_bytes(dump([{'path':k,'bytes':len(v),'sha256':digest(v)} for k,v in sorted(evidence.items())]))
    txt=[f'# {VERSION}',f'- Status: {gate["status"]}',f'- HEAD: {identity.get("head")}',f'- Branch: {identity.get("branch")}',f'- Repo paths directly checked: {len(repo_checks)}',f'- Download ZIPs examined: {len(archives)}',f'- Retrieved bounded source/evidence files: {len(evidence)}',f'- No 2024 market rows or 2024-named archive member accessed; no market/trade rows; no backtests; no repo/production mutation.',f'- No historical authority or economic claim has been certified yet.', '', '## Authority blockers', '\n'.join('- '+k for k,v in gate.items() if k.endswith('_certified') and v is False)]
    (report_dir/'README_RESULTS.md').write_text('\n'.join(txt)+'\n',encoding='utf-8')
    output=downloads/('UPLOAD_THIS_AKAH_R54_P0R1_AUTHORITY_PACKET_'+stamp+'.zip')
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for f in report_dir.iterdir():z.write(f,arcname=f.name)
        for name,buf in sorted(evidence.items()):z.writestr(name,buf)
    print('R54_P0R1_STATUS='+gate['status'])
    print('R54_P0R1_REPO_HEAD='+str(identity.get('head')))
    print('R54_P0R1_ARCHIVES_SCANNED='+str(len(archives)))
    print('R54_P0R1_EVIDENCE_FILES='+str(len(evidence)))
    print('R54_P0R1_MARKET_ROWS_READ=0')
    print('R54_P0R1_2024_MARKET_ROWS_READ=0')
    print('R54_P0R1_REPO_MUTATION=NO')
    print('R54_P0R1_ECONOMIC_GATE=BLOCKED_PENDING_CERTIFICATION')
    print('R54_P0R1_UPLOAD='+str(output))
    return output

def selftest():
    assert forbidden('market/2024/BTC.csv')
    assert forbidden('all_2022_2024.csv')
    assert not forbidden('2022/2023/BTC.csv')
    assert not safe_entry('2024/BTC.csv',300)
    assert not safe_entry('dataset/raw_market_data_2022.csv',300)
    assert not safe_entry('trades/raw_trade_ledger.csv',300)
    assert safe_entry('baseline/R50_ABSOLUTE_LONG_PERMISSION_12_FROZEN_ECONOMIC_CELLS.csv',2000)
    assert safe_entry('evidence/R42_2023_8759_CANONICAL_TAPE_WITNESS.json',9000)
    assert not safe_entry('../R50_FROZEN.json',200)
    assert not candidate_safe('.akah_bot/v15_runtime_spill/bars-r50.bin')
    print('R54_P0R1_SELFTEST=PASS_10')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo',default=r'C:\SIRAJ\Repositories\spot-speculation-bot')
    ap.add_argument('--downloads',default=str(Path.home()/'Downloads'))
    ap.add_argument('--selftest-only',action='store_true')
    args=ap.parse_args()
    selftest()
    if args.selftest_only:return 0
    repo,downloads=Path(args.repo),Path(args.downloads)
    if not repo.is_dir():print('R54_P0R1_ERROR=REPO_NOT_FOUND',str(repo));return 2
    if not downloads.is_dir():print('R54_P0R1_ERROR=DOWNLOADS_NOT_FOUND',str(downloads));return 3
    stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    try:run(repo,downloads,stamp)
    except Exception:
        print('R54_P0R1_ERROR=UNEXPECTED')
        traceback.print_exc()
        return 4
    return 0
if __name__=='__main__':sys.exit(main())
