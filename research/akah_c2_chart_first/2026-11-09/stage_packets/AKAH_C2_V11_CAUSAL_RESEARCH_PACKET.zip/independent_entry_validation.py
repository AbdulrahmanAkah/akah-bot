import json,io,zipfile
import pandas as pd,numpy as np
from lightgbm import LGBMClassifier
p='/mnt/data/AKAH_C2_V11_CAUSAL_RESEARCH/'
x=pd.read_pickle('/mnt/data/AKAH_C2_V9/all_events.pkl').sort_values(['pair','signal_ms']).reset_index(drop=True)
z=zipfile.ZipFile('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_0001.zip');b=pd.read_csv(io.BytesIO(z.read('hourly/KUCOIN_BTC-USDT.csv.gz')),compression='gzip',usecols=['unix_ms','close']).sort_values('unix_ms').drop_duplicates('unix_ms')
for h in [24,168,720,4800]:b['btc_'+str(h)]=100*(b.close/b.close.shift(h)-1).where(b.unix_ms-b.unix_ms.shift(h)==h*3600000)
b=b.rename(columns={'unix_ms':'signal_ms','btc_4800':'btc_200d'})[['signal_ms','btc_24','btc_168','btc_720','btc_200d']]
x=pd.merge_asof(x.sort_values('signal_ms'),b,on='signal_ms',direction='backward',tolerance=3600000)
x['relative_strength_168']=x.past168_pct-x.btc_168
x['log_base_volume']=np.log1p(x.base_volume.clip(lower=0));x['vboost']=np.log1p(x.relative_base_volume_168h.clip(lower=0,upper=50))
f=json.load(open('/mnt/data/AKAH_C2_V9/model_meta.json'))['features']
# strict as-of data availability, NOT future outcome completeness for test signal selection
q=x.past168_pct.notna()&x.btc_168.notna()&x.zero_range_share_168h.le(.10)&x.liquidity_band_proxy.eq('LIQ_HIGH_1M_24H_PROXY')
x=x.loc[q].copy();x=x.sort_values(['pair','signal_ms']);
# deterministic decluster of signal hours for statistical independence; no future labels in selection
idx=[];last={}
for i,(pair,t) in enumerate(zip(x.pair.to_numpy(),x.signal_ms.to_numpy())):
 if t-last.get(pair,-10**16)>=168*3600000:idx.append(i);last[pair]=t
x=x.iloc[idx].copy()
train=x[x.year.between(2018,2020)&x.ret72_pct.notna()].copy();v=x[(x.year==2021)&x.ret72_pct.notna()].copy();test=x[x.year.isin([2022,2023])].copy()
for y,name in [(train,'train'),(v,'validation'),(test,'test')]:print(name,len(y),flush=True)
# Binary success: a week of future forecast is not a signal; target label ONLY in supervised historical training.
train['target']=train.ret72_pct>4;v['target']=v.ret72_pct>4
m=LGBMClassifier(n_estimators=120,num_leaves=9,max_depth=4,min_child_samples=70,reg_lambda=20,learning_rate=.05,verbosity=-1,n_jobs=4,random_state=11)
m.fit(train[f],train.target)
v['score']=m.predict_proba(v[f])[:,1];thr=float(v.score.quantile(.90))
# Freeze model+threshold in 2021, retrain on <=2021 only. Never use 2022/2023 labels to select policy.
full=x[x.year.between(2018,2021)&x.ret72_pct.notna()].copy();full['target']=full.ret72_pct>4
m2=LGBMClassifier(n_estimators=120,num_leaves=9,max_depth=4,min_child_samples=70,reg_lambda=20,learning_rate=.05,verbosity=-1,n_jobs=4,random_state=11)
m2.fit(full[f],full.target)
test['score']=m2.predict_proba(test[f])[:,1]
rows=[]
for y in [2021,2022,2023]:
 data=v if y==2021 else test[test.year==y]
 for group,part in [('all',data),('top_decile_frozen2021',data[data.score>=thr])]:
  oo=part[part.ret72_pct.notna()].copy()
  if not len(oo):continue
  rows.append({'year':y,'selection':group,'n_signals':len(part),'n_with_complete_outcome':len(oo),'win72_gt_4pct':float((oo.ret72_pct>4).mean()),'mean72_gross_pct':float(oo.ret72_pct.mean()),'median72_net_0p6pct':float(oo.ret72_pct.median()-.6),'mean168_gross_pct':float(oo.ret168_pct.mean()),'median168_net_0p6pct':float(oo.ret168_pct.median()-.6)})
pd.DataFrame(rows).to_csv(p+'V11_PRE2022_WAVE_QUALITY_VALIDATION.csv',index=False)
print('RESULTS',json.dumps(rows,indent=2),flush=True)
print('FROZEN_THR_2021',thr,flush=True)
