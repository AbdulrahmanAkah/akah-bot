#!/usr/bin/env python3
"""V11: Independent, chronological, ex-ante signal execution audit, research only.
Scores are frozen V9 model trained prior to 2022; 2022/23 labels excluded from selection.
Spot only, no real orders, 2024 sealed. Rallies and tops are *not* entry predicates.
"""
from __future__ import annotations
import io,glob,json,zipfile,collections,sys,math
from pathlib import Path
import pandas as pd
import numpy as np
import lightgbm as lgb
R=Path('/mnt/data/AKAH_C2_V11_CAUSAL_RESEARCH')
RAW='/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip'
BEGIN=1640995200000;END=1704067200000;H=3600000
P=Path('/mnt/data/AKAH_C2_V9')
FEATURES=json.load(open(P/'model_meta.json'))['features']
THRESHOLDS=json.load(open(P/'model_meta.json'))['thresholds_2021_validation']

def get_raw(names=None,btc_only=False):
    out={};errs=[]
    for fn in sorted(glob.glob(RAW)):
        with zipfile.ZipFile(fn) as z:
            for name in z.namelist():
                if not name.startswith('hourly/') or not name.endswith('.csv.gz'): continue
                key=name[7:-7]
                if btc_only and key!='KUCOIN_BTC-USDT': continue
                if names is not None and key not in names: continue
                try:
                    frame=pd.read_csv(io.BytesIO(z.read(name)),compression='gzip',usecols=['unix_ms','open','high','low','close','base_volume'])
                    frame=frame[(frame.unix_ms>=BEGIN-(6000 if btc_only else 40*24)*H)&(frame.unix_ms<END)]
                    frame=frame.dropna(subset=['unix_ms','open','high','low','close']).sort_values('unix_ms').drop_duplicates('unix_ms')
                    frame=frame[(frame.open>0)&(frame.close>0)&(frame.high>=frame.low)&(frame.high>=frame.open)&(frame.low<=frame.open)]
                    if len(frame)<50:continue
                    t=frame.unix_ms.to_numpy(np.int64);o=frame.open.to_numpy(float);hi=frame.high.to_numpy(float);lo=frame.low.to_numpy(float);c=frame.close.to_numpy(float);vol=frame.base_volume.to_numpy(float)
                    qval=pd.Series(np.maximum(vol,0)*c).rolling(24,min_periods=24).sum().to_numpy()
                    cont=np.zeros(len(t),bool);cont[23:]=(t[23:]-t[:-23]==23*H);qval[~cont]=np.nan
                    ma48=pd.Series(c).rolling(48,min_periods=48).mean().to_numpy();ma48[t-np.roll(t,47)!=47*H]=np.nan;ma48[:47]=np.nan
                    pc=np.r_[c[0],c[:-1]];tr=np.maximum(hi-lo,np.maximum(abs(hi-pc),abs(lo-pc)))
                    atr=pd.Series(tr).rolling(48,min_periods=48).median().to_numpy();atr[~(t-np.roll(t,47)==47*H)]=np.nan;atr[:47]=np.nan
                    out[key]=dict(t=t,o=o,h=hi,l=lo,c=c,q=qval,ma48=ma48,atr=atr)
                except Exception as e: errs.append((key,str(e)))
    return out,errs

print('STAGE A read BTC',flush=True)
btcraw,err=get_raw(btc_only=True)
assert 'KUCOIN_BTC-USDT' in btcraw
b=btcraw['KUCOIN_BTC-USDT'];btc=pd.DataFrame({'signal_ms':b['t'],'close':b['c']})
for hr,name in [(24,'btc_24'),(168,'btc_168'),(720,'btc_720'),(4800,'btc_200d')]:
    v=100*(btc.close/btc.close.shift(hr)-1)
    gap=btc.signal_ms-btc.signal_ms.shift(hr)!=hr*H
    btc[name]=v.where(~gap)
btc=btc[['signal_ms','btc_24','btc_168','btc_720','btc_200d']]

print('STAGE B scoring all 2022/23 as-of events, without outcome-availability mask',flush=True)
x=pd.read_pickle(P/'all_events.pkl');x=x.loc[x.year.isin([2022,2023])].copy()
x=pd.merge_asof(x.sort_values('signal_ms'),btc.sort_values('signal_ms'),on='signal_ms',direction='backward',tolerance=H)
x['relative_strength_168']=x.past168_pct-x.btc_168
x['log_base_volume']=np.log1p(x.base_volume.clip(lower=0))
x['vboost']=np.log1p(x.relative_base_volume_168h.clip(lower=0,upper=50))
x['high_liq']=x.liquidity_band_proxy.eq('LIQ_HIGH_1M_24H_PROXY')
booster=lgb.Booster(model_file=str(P/'AKAH_C2_PRE2022_IMPULSE_SCORER.txt'))
x['score']=booster.predict(x[FEATURES],num_threads=4)
raw_count=len(x)
quality=(x.high_liq)&(x.zero_range_share_168h.fillna(1)<=0.10)&x.past168_pct.notna()&x.btc_168.notna()
x=x.loc[quality].copy()
# signal score threshold was calibrated in 2021, BEFORE 2022/23
x=x.loc[x.score>=THRESHOLDS['0.9']].copy()
print('All events:',raw_count,'quality + score:',len(x),flush=True)
x['key']=x.venue+'_'+x.pair;x['entry_ms']=x.signal_ms+H
keys=set(x.key)
print('STAGE C load hourly strips for',len(keys),'candidate keys',flush=True)
raw,rawerr=get_raw(names=keys)
print('usable raw',len(raw),'errors',len(rawerr),flush=True)
key_reasons=collections.Counter();cands=[]
for r in x.itertuples(index=False):
    d=raw.get(r.key)
    if d is None:key_reasons['NO_RAW']+=1;continue
    j=int(np.searchsorted(d['t'],r.entry_ms))
    if j>=len(d['t']) or d['t'][j]!=r.entry_ms or j==0 or d['t'][j-1]!=r.signal_ms:
        key_reasons['MISSING_NEXT_OPEN']+=1;continue
    liq=d['q'][j-1]
    if not np.isfinite(liq):key_reasons['UNKNOWN_LIQ_AT_SIGNAL']+=1;continue
    if liq<5e6:key_reasons['LIQ_LT_5M']+=1;continue
    if r.signal_ms<BEGIN or r.entry_ms>=END:continue
    cands.append((int(r.entry_ms),r.key,float(r.score),float(liq),float(r.relative_strength_168),float(r.btc_720),float(r.btc_200d),j))
print('ex ante liquid candidates',len(cands),'rejected',dict(key_reasons),flush=True)
with open(R/'candidate_funnel.json','w') as f: json.dump({'all_events_2022_23':raw_count,'asof_quality_score':len(x),'ex_ante_liquid_next_open':len(cands),'errors':rawerr,'rejected':dict(key_reasons),'V9_source_model_pre2022':True,'V9_source_training_censor_was_not_retrained':True},f,indent=2)
# every candidate selected using its own AS-OF features only. No trade candidate requires exits or complete future hours.
# family policies frozen for this audit, not selected based on returns.
policy_names=['FROZEN_120H','TREND_RUNNER_336H','PROFIT_LOCK_336H','DEFENSIVE_72H']

def exec_one(policy='FROZEN_120H',fee_side=.003,exclude=None,delay=0,participation=.001,btc_guard=True):
    events={};
    for t,key,sc,liq,rs,btc720,btc200,j in cands:
        if exclude and key.split('_',1)[1] in exclude:continue
        if btc_guard and not (btc720>0 and btc200>0 and rs>0):continue
        if delay:
            d=raw[key]
            k=j+delay
            if k>=len(d['t']) or d['t'][k] != t+delay*H: continue
            t=int(d['t'][k]);j=k
        events.setdefault(t,[]).append((key,sc,liq,j))
    for a in events.values():a.sort(key=lambda k:(-k[1],k[0]))
    cash=100000.;positions={};last_sell={};fills=[];days=[];peak=100000.;maxdd=0.;yearnav=None;yeartrades=collections.Counter();lost_gaps=0;hourly_ends={};opened=0
    for now in range(BEGIN,END,H):
        # At open, process mature positions first: past bars can set stop but this bar cannot change its stop before it executes.
        for key,pos in list(positions.items()):
            d=raw[key];i=np.searchsorted(d['t'],now)
            have=i<len(d['t']) and d['t'][i]==now
            missing=not have
            if not have:
                k=i-1;px=float(d['c'][k])*.98 if k>=0 else pos['price']*.90
                # if data gap, exit conservatively and record censor (not tradability certified)
                flag='MISSING_BAR_FORCE';lost_gaps+=1
                liquidate=True
            else:
                openp=float(d['o'][i]);low=float(d['l'][i]);high=float(d['h'][i]);close=float(d['c'][i]);age=(now-pos['entry_ms'])//H
                stop=pos['stop']
                horizon=120 if policy=='FROZEN_120H' else 72 if policy=='DEFENSIVE_72H' else 336
                if policy!='FROZEN_120H' and low<=stop:
                    liquidate=True;px=min(openp,stop);flag='STOP_PRECOMMITTED'
                elif age>=horizon:
                    liquidate=True;px=openp;flag='MAX_HOLD'
                elif policy=='TREND_RUNNER_336H' and age>=24 and pos['trend_break_pending']:
                    liquidate=True;px=openp;flag='STRUCTURE_BREAK_PREVIOUS_CLOSE'
                else: liquidate=False
            if liquidate:
                proceeds=pos['units']*px*(1-fee_side);cash+=proceeds
                pnl=proceeds-pos['spent']
                fills.append(dict(pair=key.split('_',1)[1],key=key,entry_ms=pos['entry_ms'],exit_ms=now,entry=pos['price'],exit=px,reason=flag,spend=pos['spent'],proceeds=proceeds,net_usd=pnl,return_pct=100*pnl/pos['spent'],score=pos['score'],mode=policy,year=pd.Timestamp(pos['entry_ms'],unit='ms',tz='UTC').year))
                last_sell[key]=(now,pnl);del positions[key]
        # Entry at hourly open from signal finalized at previous hour, before high/low of this hour.
        entered_this_bar=[]
        for key,sc,liq,j in events.get(now,[]):
            if len(positions)>=3 or key in positions:continue
            prev=last_sell.get(key)
            if prev is not None and now < prev[0]+ (24 if prev[1]<0 else 12)*H:continue
            d=raw[key];price=float(d['o'][j]);
            if not np.isfinite(price) or price<=0:continue
            # mark current positions at available open; ex ante cash/position cap
            nav=cash
            for a,p in positions.items():
                q=raw[a];k=np.searchsorted(q['t'],now);v=q['o'][k] if k<len(q['t']) and q['t'][k]==now else p['price'];nav+=p['units']*float(v)
            notional=min(nav*.15,liq*participation,cash/(1+fee_side))
            if notional<100:continue
            units=notional/price;spent=notional*(1+fee_side);cash-=spent
            stop=0.0 if policy=='FROZEN_120H' else price*.86
            positions[key]=dict(units=units,spent=spent,price=price,entry_ms=now,stop=stop,peak=price,trend_break_pending=False,score=sc)
            opened+=1
            entered_this_bar.append(key)
        # Enforce a precommitted protective stop during the entry hour too; if crossed, fill adversarially.
        # This is possible only for policies with a defined stop at entry.
        for key in entered_this_bar:
            if key not in positions:continue
            pos=positions[key]
            if pos['stop']<=0:continue
            d=raw[key];j=int(np.searchsorted(d['t'],now))
            if j<len(d['t']) and d['t'][j]==now and d['l'][j]<=pos['stop']:
                px=min(float(d['o'][j]),float(pos['stop']))
                proceeds=pos['units']*px*(1-fee_side);cash+=proceeds;pnl=proceeds-pos['spent']
                fills.append(dict(pair=key.split('_',1)[1],key=key,entry_ms=pos['entry_ms'],exit_ms=now,entry=pos['price'],exit=px,reason='STOP_DURING_ENTRY_HOUR',spend=pos['spent'],proceeds=proceeds,net_usd=pnl,return_pct=100*pnl/pos['spent'],score=pos['score'],mode=policy,year=pd.Timestamp(pos['entry_ms'],unit='ms',tz='UTC').year))
                last_sell[key]=(now,pnl);del positions[key]
        # At bar close: update mark and next-hour stop signals; never apply stop raised by current high retroactively.
        nav=cash
        for key,pos in positions.items():
            d=raw[key];idx=int(np.searchsorted(d['t'],now))
            if idx<len(d['t']) and d['t'][idx]==now:
                pos['peak']=max(pos['peak'],float(d['h'][idx]))
                cl=float(d['c'][idx]);ma=float(d['ma48'][idx]);atr=float(d['atr'][idx]);
                if policy=='TREND_RUNNER_336H':
                    if pos['peak']>=pos['price']*1.06:
                        # trailing width anchored to recent measured volatility; clamp to prevent numerical artifacts
                        pct=np.clip(3.0*atr/cl if np.isfinite(atr) and atr>0 else .12,.06,.18)
                        pos['stop']=max(pos['stop'],pos['peak']*(1-pct))
                    pos['trend_break_pending']= bool(cl<ma and pos['peak']>=pos['price']*1.04) if np.isfinite(ma) else False
                elif policy=='PROFIT_LOCK_336H':
                    if pos['peak']>=pos['price']*1.08:
                        pos['stop']=max(pos['stop'],pos['price']*1.015,pos['peak']*.83)
                px=cl
            else:
                k=idx-1;px=float(d['c'][k]) if k>=0 else pos['price']
            nav+=pos['units']*px
        peak=max(peak,nav);maxdd=min(maxdd,nav/peak-1.)
        if now==1672531200000:yearnav=nav
        if now%(24*H)==23*H:days.append((now,nav,len(positions)))
    # force settle at last actual close by 2023 end, with exit fee; never read 2024
    for key,pos in list(positions.items()):
        d=raw[key];idx=int(np.searchsorted(d['t'],END))-1;px=float(d['c'][idx]) if idx>=0 else pos['price']*.9
        proceeds=pos['units']*px*(1-fee_side);cash+=proceeds;pnl=proceeds-pos['spent']
        fills.append(dict(pair=key.split('_',1)[1],key=key,entry_ms=pos['entry_ms'],exit_ms=END,entry=pos['price'],exit=px,reason='SEALED_END_2023',spend=pos['spent'],proceeds=proceeds,net_usd=pnl,return_pct=100*pnl/pos['spent'],score=pos['score'],mode=policy,year=pd.Timestamp(pos['entry_ms'],unit='ms',tz='UTC').year))
    fills=pd.DataFrame(fills)
    top=fills.groupby('pair').net_usd.sum().sort_values(ascending=False) if len(fills) else pd.Series(dtype=float)
    end22=yearnav if yearnav else 100000.
    return {'policy':policy,'fee_per_side':fee_side,'participation':participation,'exclude':','.join(sorted(exclude or [])),'delay_h':delay,'btc_guard':btc_guard,'trades':len(fills),'pairs':fills.pair.nunique() if len(fills) else 0,'first_year_return_pct':100*(end22/1e5-1),'second_year_return_pct':100*(cash/end22-1),'total_return_pct':100*(cash/1e5-1),'max_drawdown_close_pct':100*maxdd,'final_usdt':cash,'top_pair':top.index[0] if len(top) else '', 'top_pair_net_usd':float(top.iloc[0]) if len(top) else 0.,'gap_forced_exits':lost_gaps,'opened':opened},fills,pd.DataFrame(days,columns=['unix_ms','nav','active'])

print('STAGE D strictly chronological portfolio tests',flush=True)
results={};ledgers={}
for pol in policy_names:
    res,trades,nav=exec_one(pol)
    results[pol]=res;ledgers[pol]=trades
    trades.to_csv(R/(pol+'_TRADES.csv'),index=False)
    nav.to_csv(R/(pol+'_DAILY_NAV.csv'),index=False)
    print('BASE',pol,res,flush=True)
# stress the *fixed two opposing architectures*, not search for best after reading outcomes
allstress=[]
for pol in policy_names:
    s=results[pol];leaders=list(ledgers[pol].groupby('pair').net_usd.sum().sort_values(ascending=False).head(3).index) if len(ledgers[pol]) else []
    for label,opts in [('double_fee',dict(fee_side=.006)),('exclude_top_3',dict(exclude=leaders)),('double_fee_exclude_top_3',dict(fee_side=.006,exclude=leaders)),('entry_delay_3h',dict(delay=3)),('one_tenth_participation',dict(participation=.0001))]:
        out,_,_=exec_one(pol,**opts);out['stress']=label;allstress.append(out);print('STRESS',pol,label,out['total_return_pct'],out['first_year_return_pct'],out['second_year_return_pct'],flush=True)
pd.DataFrame(list(results.values())).to_csv(R/'V11_POLICY_RESULTS.csv',index=False)
pd.DataFrame(allstress).to_csv(R/'V11_POLICY_STRESS.csv',index=False)
status={'status':'RESEARCH_NOT_APPROVED','raw_pairs':len(raw),'candidate_keys':len(keys),'total_raw_events_2022_2023':raw_count,'candidates_asof_liquid':len(cands),'V9_training_data_leakage_remaining':'V9 model selection/label completeness during prior pre2022 training; 2022/23 signal filtering removed','historical_universe_PIT':'NOT_CERTIFIED','execution_liquidity':'proxy 24h quote; not actual spread/orderbook','never_open_2024':True,'no_live':True,'assumptions':'stop fills at min(hour open, stop); feed gaps force exit with 2% haircut; close MTM, 0.3% fee per side basic, independent policy replays','policy_results':results}
(R/'V11_AUDIT.json').write_text(json.dumps(status,indent=2,ensure_ascii=False))
print('DONE',flush=True)
