import csv, gzip, json, os, pathlib, shutil, tempfile, zipfile, subprocess,sys,datetime as dt
from importlib.util import spec_from_file_location,module_from_spec
sys.path.insert(0,'/mnt/data/c2_fix')
import akah_c2_recovery_v3 as m
orig=pathlib.Path('/mnt/data/c2_fix/akah_c2_mega_v2.py')
with tempfile.TemporaryDirectory() as td:
 base=pathlib.Path(td);dl=base/'Downloads';dl.mkdir();work=dl/'AKAH_C2_MARKET_VAULT_V2';(work/'tools').mkdir(parents=True)
 shutil.copy2(orig,work/'tools'/'akah_c2_mega_v2.py')
 repo=base/'repo';mem=repo/'data/research/rd18_p3x_a3_inputs/c2-operational-membership.csv';mem.parent.mkdir(parents=True)
 mem.write_text('pair,universe\nBTC-USDT,C2\nETH-USDT,C2\nDOGE-USDT,D2\n',encoding='utf-8')
 raw=work/'raw'
 for sym in ('BTCUSDT','ETHUSDT'):
  for mo in ('2022-01','2023-01'):
   f=raw/'binance/spot/klines'/sym/'1d'/(sym+'-1d-'+mo+'.zip');f.parent.mkdir(parents=True,exist_ok=True)
   with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED) as z:
    rows=[];year=int(mo[:4]);month=int(mo[5:]);n=31
    for day in range(1,32):
     t=int(dt.datetime(year,month,day,tzinfo=dt.timezone.utc).timestamp()*1000)
     p=(100 if sym=='BTCUSDT' else 200)+day
     rows.append([t,p,p+4,p-2,p+1,1000,t+86399999,100000,100,500,50000,0])
    z.writestr(sym+'-1d-'+mo+'.csv','\n'.join(','.join(map(str,row)) for row in rows)+'\n')
 # duplicate 2024 archive should NOT appear in recovered raw packages nor factor analytics
 f=raw/'binance/spot/klines/BTCUSDT/1d/BTCUSDT-1d-2024-01.zip'
 with zipfile.ZipFile(f,'w') as z:z.writestr('BTCUSDT-1d-2024-01.csv','1704067200000,100,110,90,105,1,1704153599999,1000\n')
 (work/'RETRIEVAL_JOURNAL.jsonl').write_text('{"key":"a","status":"DOWNLOADED"}\n{"key":"b","status":"NOT_PUBLISHED_404"}\n',encoding='utf-8')
 r=subprocess.run([sys.executable,str(pathlib.Path(m.__file__)),'--repo',str(repo),'--downloads',str(dl),'--raw-mode','core'],capture_output=True,text=True)
 print('TEST_RUN_RETURN_CODE=',r.returncode);print('TEST_RUN_STDOUT=',r.stdout[-1500:]);print('TEST_RUN_STDERR=',r.stderr[-1000:])
 assert r.returncode==0,r.stderr+r.stdout
 out=dl/'AKAH_C2_MARKET_VAULT_UPLOAD_PACKETS_RECOVERY_V3';z=out/'UPLOAD_THIS_AKAH_C2_RECOVERED_ANALYSIS_AND_COVERAGE_V3.zip'
 assert z.exists()
 with zipfile.ZipFile(z) as a:
  assert 'v2_original_metadata/RETRIEVAL_JOURNAL.jsonl' in a.namelist()
  assert not any('2024' in t for t in a.namelist())
  cov=json.loads(a.read('RECOVERY_COVERAGE.json'));assert cov['C2_membership_pairs']==2
  assert cov['price_analysis']['pairs_with_daily_bars']==2
  assert 'analysis_recovered_v3/C2_DAILY_YEARLY_REAL_MARKET_SUMMARY.csv' in a.namelist()
  print('SUMMARY_ENTRIES=',len(a.namelist()))
 for part in out.glob('UPLOAD_THIS_AKAH_C2_RECOVERED_CORE_RAW_PART_*.zip'):
  with zipfile.ZipFile(part) as z:
   assert z.testzip() is None
   assert not any('2024-' in name for name in z.namelist())
   assert not any('DOGEUSDT' in name for name in z.namelist())
 print('RAW_CORE_PARTS=',len(list(out.glob('UPLOAD_THIS_AKAH_C2_RECOVERED_CORE_RAW_PART_*.zip'))))
 # idempotence: no second run output errors, and cache remains byte-identical
 orig_hashes={str(p):m.sha(p) for p in raw.rglob('*') if p.is_file()}
 r2=subprocess.run([sys.executable,str(pathlib.Path(m.__file__)),'--repo',str(repo),'--downloads',str(dl),'--raw-mode','none'],capture_output=True,text=True)
 assert r2.returncode==0,(r2.stdout,r2.stderr)
 assert orig_hashes=={str(p):m.sha(p) for p in raw.rglob('*') if p.is_file()}
 print('PASS_OFFLINE_RECOVERY_NO_NETWORK_NO_2024_AND_PRESERVED_CACHE')
