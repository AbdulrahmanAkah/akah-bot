#!/usr/bin/env python3
"""AKAH C2 offline recovery: preserve V2 raw market cache and export actual evidence.
Zero network activity by default. Only optional --resume-aggtrades permits network.
Does NOT claim point-in-time certification or economic trading edge.
"""
from __future__ import annotations
import argparse, csv, datetime as dt, hashlib, importlib.util, json, pathlib, re, shutil, sys, zipfile, io, math
from collections import Counter,defaultdict
from typing import Optional

ORIGINAL_SHA='71b317867d3131827110f4ac01dd13ccfb7a616c189b7498ff62992fff9107fa'
CUTOFF=dt.datetime(2024,1,1,tzinfo=dt.timezone.utc)
MONTH=re.compile(r'-(\d{4})-(\d{2})\.zip$',re.I)

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def js(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_name(path.name+'.tmp')
 with tmp.open('w',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,default=str)
 tmp.replace(path)

def load_original(work):
 p=work/'tools'/'akah_c2_mega_v2.py'
 if not p.is_file():raise RuntimeError('ORIGINAL_V2_PY_NOT_FOUND: '+str(p))
 s=sha(p)
 if s.lower()!=ORIGINAL_SHA.lower():raise RuntimeError('ORIGINAL_V2_HASH_UNEXPECTED: '+s+'; STOP to avoid unreviewed code')
 spec=importlib.util.spec_from_file_location('akah_c2_orig_source',p)
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 return mod,p

def install_sealed_market_reader(mod):
 """Replace V2's unfiltered *.zip reader: NEVER open a 2024+ named archive."""
 def sealed_binance_daily(root,symbol,interval='1d',kind='spot'):
  b=symbol.replace('-','');sub='spot' if kind=='spot' else 'futures_um'
  folder=root/'binance'/sub/'klines'/b/interval
  out={};invalid=0;files=0
  if not folder.exists():return [],{'files':0,'invalid_rows':0}
  for fp in sorted(folder.glob('*.zip')):
   month=MONTH.search(fp.name)
   if not month or int(month.group(1))>=2024:continue
   try:
    with zipfile.ZipFile(fp) as z:
     names=[n for n in z.namelist() if n.lower().endswith('.csv')]
     if len(names)!=1:invalid+=1;continue
     with z.open(names[0]) as raw:
      reader=csv.reader(io.TextIOWrapper(raw,encoding='utf-8-sig',errors='replace',newline=''))
      for v in reader:
       if len(v)<8:continue
       try:
        t=int(v[0]);t=t//1000 if t>=10**14 else t
        if not 1_483_228_800_000<=t<mod.CUT_MS:continue
        op,hi,lo,cl,vol,q=[float(v[k]) for k in (1,2,3,4,5,7)]
        if not all(math.isfinite(x) for x in (op,hi,lo,cl,vol,q)) or min(op,hi,lo,cl)<=0 or lo>min(op,cl) or hi<max(op,cl):invalid+=1;continue
        out[t]={'unix_ms':t,'open':op,'high':hi,'low':lo,'close':cl,'base_volume':vol,'quote_volume':q,
          'trade_count':float(v[8]) if len(v)>8 and str(v[8]).isdigit() else None,
          'taker_buy_quote_volume':float(v[10]) if len(v)>10 and v[10] else None}
       except (ValueError,IndexError,OverflowError):invalid+=1
    files+=1
   except (OSError,zipfile.BadZipFile):invalid+=1
  return [out[t] for t in sorted(out)],{'files':files,'invalid_rows':invalid,
     'first':mod.iso(min(out)//1000) if out else None,'last':mod.iso(max(out)//1000) if out else None}
 mod.read_binance_daily=sealed_binance_daily

def cached_coverage(raw, members, journal):
 allowed=set(members); rows=defaultdict(lambda:dict(files=0,bytes=0,earliest=None,latest=None))
 files_total=0;bytes_total=0;quarantine=0
 for p in raw.rglob('*') if raw.exists() else ():
  if not p.is_file() or p.name.endswith('.part'):continue
  rel=p.relative_to(raw).parts;pair=None;cat=None
  if len(rel)>=6 and rel[0]=='binance' and rel[1] in ('spot','futures_um') and rel[2]=='klines':
   pair=rel[3][:-4]+'-USDT' if rel[3].endswith('USDT') else None
   cat=rel[1]+'_'+rel[4]
  elif len(rel)>=5 and rel[:3]==('binance','spot','aggTrades'):
   pair=rel[3][:-4]+'-USDT' if rel[3].endswith('USDT') else None;cat='spot_aggTrades'
  elif len(rel)>=3 and rel[:2]==('kucoin','spot'):
   pair=rel[2];cat='kucoin_'+(rel[3] if len(rel)>3 else 'unknown')
  elif len(rel)>=3 and rel[:3]==('binance','futures_um','fundingRate'):
   pair=p.stem.split('.')[0][:-4]+'-USDT' if p.name.endswith('USDT.csv.gz') else None;cat='fundingRate'
  elif rel and rel[0]=='market_context':cat='market_context';pair='EXTERNAL'
  elif rel and rel[0]=='local_canonical_tape':cat='local_canonical_tape';pair=p.name.split('_')[0]
  if cat is None:cat='other'
  if pair is not None and pair not in allowed and pair!='EXTERNAL':quarantine+=1;continue
  k=(pair or 'UNKNOWN',cat);row=rows[k];row['files']+=1;row['bytes']+=p.stat().st_size;files_total+=1;bytes_total+=p.stat().st_size
  m=MONTH.search(p.name)
  if m:
   stamp=m.group(1)+'-'+m.group(2)
   if row['earliest'] is None or stamp<row['earliest']:row['earliest']=stamp
   if row['latest'] is None or stamp>row['latest']:row['latest']=stamp
 status=Counter(x.get('status','UNKNOWN') for x in journal.records.values())
 return {'cached_files':files_total,'cached_bytes':bytes_total,'quarantined_files_not_C2':quarantine,
         'journal_status_latest':dict(status),
         'coverage_by_pair_and_category':[{'pair':p,'category':c,**v} for (p,c),v in sorted(rows.items())]}

def raw_core_subset(root, members, mode='core'):
 """Only bounded, pre-2024 user-authorized research subsets; keep minute/tick raw on disk."""
 allow=set(members)
 for p in sorted(root.rglob('*')) if root.exists() else ():
  if not p.is_file() or p.name.endswith('.part'):continue
  rel=p.relative_to(root).parts
  if len(rel)>=6 and rel[0]=='binance' and rel[2]=='klines' and rel[1] in ('spot','futures_um'):
   b=rel[3]
   if not b.endswith('USDT') or b[:-4]+'-USDT' not in allow:continue
   tf=rel[4];mo=MONTH.search(p.name)
   if not mo:continue
   year=int(mo.group(1));month=int(mo.group(2))
   if year>2023 or not 1<=month<=12:continue
   if rel[1]=='spot' and tf=='1d':yield p
   elif mode=='core' and rel[1]=='spot' and tf=='1h' and year in (2022,2023):yield p
   elif mode=='core' and rel[1]=='futures_um' and tf=='1d' and year in (2022,2023):yield p
  elif mode=='core' and len(rel)>=4 and rel[:3]==('binance','futures_um','fundingRate') and p.name.endswith('.gz'):
   if p.name[:-7].endswith('USDT') and p.name[:-7][:-4]+'-USDT' in allow:yield p
  elif mode=='core' and len(rel)>=4 and rel[:2]==('kucoin','spot'):
   if rel[2] in allow and p.name.endswith('.csv.gz'):yield p
  elif mode=='core' and len(rel)>=2 and rel[0]=='market_context':
   if p.name.endswith('.csv.gz'):yield p

def package(root,work,dl,rep,coverage,members,packet_mb=85,raw_mode='core'):
 output=dl/'AKAH_C2_MARKET_VAULT_UPLOAD_PACKETS_RECOVERY_V3';output.mkdir(exist_ok=True,parents=True)
 summary=output/'UPLOAD_THIS_AKAH_C2_RECOVERED_ANALYSIS_AND_COVERAGE_V3.zip'
 report_files=list(rep.rglob('*')) if rep.exists() else []
 with zipfile.ZipFile(summary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
  for f in sorted(report_files):
   if f.is_file():z.write(f,('analysis_recovered_v3/'+f.relative_to(rep).as_posix()))
  for name in ('C2_MEMBERSHIP_AUTHORITY_V2.json','C2_FULL_VAULT_RUN_STATUS.json','RETRIEVAL_JOURNAL.jsonl'):
   f=work/name
   if f.is_file():z.write(f,('v2_original_metadata/'+name))
  z.writestr('RECOVERY_COVERAGE.json',json.dumps(coverage,ensure_ascii=False,indent=2,default=str))
  z.writestr('RECOVERY_READ_FIRST.txt',
   'OFFLINE RECOVERY FROM CACHED V2 MARKET DATA. NO NETWORK BY DEFAULT.\n'
   'C2 operational candidate is NOT certified historical PIT membership.\n'
   '2024+ out of scope. Raw 1m and aggTrades remain locally cached but not uploaded here.\n'
   'NO TRADING SIGNAL OR PROFITABILITY CERTIFICATION.\n')
 print('SUMMARY_PACKET_READY='+str(summary),flush=True)
 packet_manifest={'summary':summary.name,'sha256':sha(summary),'raw_mode':raw_mode,'parts':[],
                  'raw_selection':'spot 1d all available pre-2024; spot 1h 2022-2023; futures 1d 2022-2023; funding and KuCoin files only if available',
                  'excluded_from_upload':'spot 1m, spot aggTrades, and other oversized/high-volume raw files remain unchanged locally',
                  'no_2024':True,'no_live_orders':True}
 if raw_mode=='none':
  js(output/'UPLOAD_PACKET_MANIFEST_V3.json',packet_manifest);return packet_manifest
 maxbytes=packet_mb*(1024**2)
 group=[];size=0;idx=0;excluded=[]
 def flush():
  nonlocal group,size,idx
  if not group:return
  idx+=1;target=output/f'UPLOAD_THIS_AKAH_C2_RECOVERED_CORE_RAW_PART_{idx:04d}.zip'
  with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
   for f in group:z.write(f,('raw/'+f.relative_to(root).as_posix()))
  packet_manifest['parts'].append({'name':target.name,'files':len(group),'bytes':target.stat().st_size,'sha256':sha(target)})
  group=[];size=0
 for p in raw_core_subset(root,members,raw_mode):
  sz=p.stat().st_size
  if sz>maxbytes:excluded.append({'path':str(p.relative_to(root)),'bytes':sz,'reason':'INDIVIDUAL_ARCHIVE_EXCEEDS_PACKET_LIMIT'});continue
  if group and size+sz>maxbytes:flush()
  group.append(p);size+=sz
 flush()
 packet_manifest['oversize_skipped']=excluded
 js(output/'UPLOAD_PACKET_MANIFEST_V3.json',packet_manifest)
 return packet_manifest

def resume_agg(mod,raw,journal,pairs,limit):
 count=Counter();attempted=0;start=mod.ARCHIVE_BEGIN
 for pair in pairs:
  symbol=pair.replace('-','')
  for mo in mod.months(start=start,end=mod.CUTOFF):
   dest=raw/'binance'/'spot'/'aggTrades'/symbol/(symbol+'-aggTrades-'+mo+'.zip')
   key=f'archive/aggTrades/{symbol}/na/{mo}'
   prev=journal.records.get(key,{})
   if dest.exists() and zipfile.is_zipfile(dest):count['CACHED']+=1;continue
   if prev.get('status')=='NOT_PUBLISHED_404':count['NOT_PUBLISHED_404']+=1;continue
   if attempted>=limit:return {'statuses':dict(count),'new_attempts':attempted,'stopped':'BATCH_LIMIT'}
   attempted+=1
   url=f'https://data.binance.vision/data/spot/monthly/aggTrades/{symbol}/{symbol}-aggTrades-{mo}.zip'
   res=mod.download_archive(journal,url,dest,key);count[res]+=1
   if res in ('NETWORK_OR_VALIDATION_ERROR','NETWORK_CIRCUIT_BREAKER_CHECK_CONNECTIVITY_THEN_RESUME','DISK_OR_ARCHIVE_BUDGET_EXHAUSTED'):
    return {'statuses':dict(count),'new_attempts':attempted,'stopped':res}
 return {'statuses':dict(count),'new_attempts':attempted,'stopped':'ALL_ELIGIBLE_MONTHS_VISITED'}

def run(args):
 dl=pathlib.Path(args.downloads).resolve();work=dl/'AKAH_C2_MARKET_VAULT_V2';raw=work/'raw'
 repo=pathlib.Path(args.repo).resolve();work.mkdir(parents=True,exist_ok=True)
 mod,source=load_original(work)
 install_sealed_market_reader(mod)
 auth=mod.source_authority(repo,work,dl);pairs=auth['members']
 if not pairs:raise RuntimeError('C2_PRIMARY_SOURCE_EMPTY_OR_MISSING, STOP')
 # Compare with frozen V2 membership if available: never silently switch 29 pairs.
 frozen=work/'C2_MEMBERSHIP_AUTHORITY_V2.json'
 if frozen.exists():
  old=json.loads(frozen.read_text(encoding='utf-8'))
  if set(old.get('members',[]))!=set(pairs):raise RuntimeError('C2_MEMBERSHIP_CHANGED_SINCE_V2. STOP TO AVOID MIXED_DATASET')
 journal=mod.Journal(work,args.archive_budget_gb)
 resume=None
 if args.resume_aggtrades:
  print('OPTIONAL_NETWORK_RESUME_AGGTRADES_STARTED',flush=True)
  resume=resume_agg(mod,raw,journal,pairs,args.max_new_archives)
  print('OPTIONAL_NETWORK_RESUME_AGGTRADES='+json.dumps(resume),flush=True)
 print('OFFLINE_ANALYSIS_FROM_LOCAL_CACHED_ARCHIVES',flush=True)
 reports=work/'analysis_recovered_v3'
 analysis=mod.analyse_all(raw,reports,pairs)
 coverage=cached_coverage(raw,pairs,journal)
 coverage.update({'recovery_version':'V3','C2_membership_pairs':len(pairs),'C2_authority_status':auth['status'],
  'original_script_sha256':sha(source),'price_analysis':analysis,'mode':'OFFLINE_EXCEPT_OPTIONAL_AGGTRADES_RESUME',
  'resume_aggtrades':resume,'raw_files_never_deleted':True,'recovered_from':str(work),
  'unavailable_not_fabricated':['global BTC.D','TOTAL/TOTAL2/TOTAL3','historical full order book','assets prior to first available venue listing']})
 js(reports/'RECOVERY_COVERAGE.json',coverage)
 manifest=package(raw,work,dl,reports,coverage,pairs,packet_mb=args.packet_mb,raw_mode=args.raw_mode)
 summary=dl/'AKAH_C2_MARKET_VAULT_UPLOAD_PACKETS_RECOVERY_V3'/'UPLOAD_THIS_AKAH_C2_RECOVERED_ANALYSIS_AND_COVERAGE_V3.zip'
 if not zipfile.is_zipfile(summary):raise RuntimeError('INVALID_SUMMARY_ZIP')
 with zipfile.ZipFile(summary) as z:
  if z.testzip() is not None:raise RuntimeError('SUMMARY_CRC_ERROR')
 print('C2_RECOVERY_STATUS=PASS_OFFLINE_FROM_EXISTING_CACHE',flush=True)
 print('C2_PAIRS='+str(len(pairs)),flush=True)
 print('C2_ANALYSED_PAIRS='+str(analysis['pairs_with_daily_bars']),flush=True)
 print('CACHED_RAW_FILES='+str(coverage['cached_files']),flush=True)
 print('SUMMARY_PACKET='+str(summary),flush=True)
 print('RAW_CORE_UPLOAD_PARTS='+str(len(manifest['parts'])),flush=True)
 print('DO_NOT_DELETE='+str(work),flush=True)
 return 0

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--repo',required=True);p.add_argument('--downloads',required=True)
 p.add_argument('--archive-budget-gb',type=float,default=30)
 p.add_argument('--packet-mb',type=int,default=85)
 p.add_argument('--raw-mode',choices=['core','daily','none'],default='core')
 p.add_argument('--resume-aggtrades',action='store_true',default=False)
 p.add_argument('--max-new-archives',type=int,default=30)
 args=p.parse_args()
 if args.packet_mb<5 or args.packet_mb>90:raise ValueError('packet_mb must be 5..90')
 if args.max_new_archives<0 or args.max_new_archives>200:raise ValueError('max-new-archives must be 0..200')
 try:sys.exit(run(args))
 except Exception as e:
  print('C2_RECOVERY_FAILED='+repr(e),flush=True)
  sys.exit(2)

if __name__=='__main__':main()
