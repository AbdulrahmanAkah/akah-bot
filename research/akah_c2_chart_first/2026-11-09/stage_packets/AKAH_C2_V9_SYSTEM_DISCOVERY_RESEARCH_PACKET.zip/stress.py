import pandas as pd,json
from portfolio import calc
P='/mnt/data/AKAH_C2_V9/';rows=[]
baseargs=dict(regime='GUARD200',threshold=2.234,mode='FIX72',fee_side=.003)
base,ledger,nav=calc(**baseargs)
leaders=ledger.groupby('pair').realized_usd.sum().sort_values(ascending=False)
print('TOP',leaders.head(15).to_dict(),flush=True)
for excluded in [[],list(leaders.head(1).index),list(leaders.head(3).index),list(leaders.head(5).index),list(leaders.head(10).index)]:
 for fee in [.003,.006]:
  r,_,_=calc(**{**baseargs,'fee_side':fee},exclude=excluded);r['stress']='exclude_top_'+str(len(excluded))+'_fee_'+str(fee);rows.append(r);print('STRESS',r['stress'],round(r['total_return_pct'],2),round(r['max_dd_pct'],2),r['trades'],flush=True)
for cap in [.0005,.001,.0025,.005,.01]:
 for liq in [1e6,5e6,1e7]:
  r,_,_=calc(**baseargs,min_liq=liq,participation=cap);r['stress']='participation_'+str(cap)+'_liq_'+str(liq);rows.append(r);print('STRESS',r['stress'],round(r['total_return_pct'],2),round(r['max_dd_pct'],2),r['trades'],flush=True)
for delay in [1,3,6]:
 r,_,_=calc(**baseargs,delay_h=delay);r['stress']='delay_'+str(delay);rows.append(r);print('STRESS',r['stress'],round(r['total_return_pct'],2),round(r['max_dd_pct'],2),r['trades'],flush=True)
for sz in [.05,.10,.20]:
 r,_,_=calc(**baseargs,sz=sz);r['stress']='nav_fraction_'+str(sz);rows.append(r);print('STRESS',r['stress'],round(r['total_return_pct'],2),round(r['max_dd_pct'],2),r['trades'],flush=True)
pd.DataFrame([{**r,'annual_2022_pct':r['annual_pct'][2022],'annual_2023_pct':r['annual_pct'][2023]} for r in rows]).drop(columns='annual_pct').to_csv(P+'stress_ledger.csv',index=False)
# independent annual/top/year audits
ledger.to_csv(P+'best_candidate_trades.csv',index=False);nav.to_csv(P+'best_candidate_daily_nav.csv',index=False)
print('BASELINE',base,flush=True)
