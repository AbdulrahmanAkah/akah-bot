import pandas as pd
from portfolio import calc
P='/mnt/data/AKAH_C2_V9';rows=[]
for h in [12,24,48,72,96,120,168,240,336]:
 mode=f'FIX{h}'
 args=dict(regime='GUARD200',threshold=2.234,mode=mode,participation=.001,min_liq=5e6)
 r,ledger,nav=calc(**args,fee_side=.003)
 top3=ledger.groupby('pair').realized_usd.sum().nlargest(3).index.tolist() if len(ledger) else []
 for fee in [.003,.006]:
  for ex in [[],top3]:
   rr,_,_=calc(**args,fee_side=fee,exclude=ex)
   rows.append({**rr,'top3_excluded':bool(ex),'top3':';'.join(top3),'y2022':rr['annual_pct'][2022],'y2023':rr['annual_pct'][2023]})
 print('RESULT',h,round(r['total_return_pct'],2),r['trades'],'top3',top3,flush=True)
pd.DataFrame(rows).drop(columns=['annual_pct']).to_csv(P+'/horizon_comparison.csv',index=False)
