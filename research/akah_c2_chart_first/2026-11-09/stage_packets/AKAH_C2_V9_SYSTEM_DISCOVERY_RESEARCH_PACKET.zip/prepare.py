import zipfile,io,gzip,glob,os,time
import pandas as pd,numpy as np
root='/mnt/data/AKAH_C2_V9';z=zipfile.ZipFile('/mnt/data/AKAH_C2_V8_ALL_1PCT_CANDLES.zip')
cols=['pair','venue','signal_ms','year','signal_up_pct','past24_pct','past168_pct','close_location','ret24_pct','ret72_pct','ret168_pct','base_volume','relative_base_volume_168h','zero_range_share_168h','btc_past_168h_pct','liquidity_band_proxy']
arr=[]
for i,n in enumerate(z.namelist()):
 try:
  df=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=lambda c:c in cols)
  for c in cols:
   if c not in df:df[c]=np.nan
  arr.append(df[cols]);
 except Exception as e:print('ERR',n,str(e)[:120])
 if i%80==0:print('read',i,'/',len(z.namelist()),flush=True)
df=pd.concat(arr,ignore_index=True);del arr
print('original',df.shape)
# one price sequence per trading pair: KuCoin priority if both available, Binance for KuCoin gap only but no same signal time duplication
# keep just pair+signal timestamp, KuCoin first
v=df.venue.eq('KUCOIN');df['venue_preference']=v.astype('int8');df=df.sort_values(['pair','signal_ms','venue_preference'],ascending=[True,True,False]).drop_duplicates(['pair','signal_ms'],keep='first');df=df.drop(columns='venue_preference')
for c in ['signal_up_pct','past24_pct','past168_pct','close_location','base_volume','relative_base_volume_168h','zero_range_share_168h','btc_past_168h_pct','ret24_pct','ret72_pct','ret168_pct']:
 df[c]=pd.to_numeric(df[c],errors='coerce').astype('float32')
# preserve exact signal time, no future-return feature in model
print('dedup',df.shape,'years',df.year.value_counts().sort_index().to_dict())
df.to_pickle(root+'/all_events.pkl');print('saved',os.path.getsize(root+'/all_events.pkl'),flush=True)
