from portfolio import calc
import pandas as pd
P='/mnt/data/AKAH_C2_V9/';rows=[]
for filterlevel in [0,5,10,20,30]:
 for mode in ['FIX72','FIX120','FIX168','FIX240']:
  args=dict(regime='GUARD200',threshold=2.234,mode=mode,min_liq=5e6,participation=.001,btc200_min=filterlevel)
  bas,ledger,_=calc(**args,fee_side=.003)
  top3=ledger.groupby('pair').realized_usd.sum().nlargest(3).index.tolist() if len(ledger) else []
  for fee,ex in [(.003,[]),(.006,[]),(.006,top3)]:
   r,_,_=calc(**args,fee_side=fee,exclude=ex)
   rows.append({**r,'top3_removed':len(ex),'top3_source':';'.join(top3),'y2022':r['annual_pct'][2022],'y2023':r['annual_pct'][2023]})
  print('DONE',filterlevel,mode,'baseline',round(bas['total_return_pct'],2),bas['trades'],flush=True)
pd.DataFrame(rows).drop(columns='annual_pct').to_csv(P+'regime_sensitivity.csv',index=False)
