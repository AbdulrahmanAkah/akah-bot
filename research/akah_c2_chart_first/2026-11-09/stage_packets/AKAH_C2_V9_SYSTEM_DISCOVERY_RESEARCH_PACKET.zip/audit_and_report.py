import os,pandas as pd,numpy as np,glob,zipfile,hashlib,json,math
P='/mnt/data/AKAH_C2_V9';x=pd.read_csv(P+'/best_candidate_trades.csv');nav=pd.read_csv(P+'/best_candidate_daily_nav.csv')
# Independent accounting audit
calc_pnl=np.sum(x.realized_usd);ref_final=100000+calc_pnl
implied=x.realized_usd/(x.ret_pct/100)
capital_diff=np.abs(implied*(1+x.ret_pct/100)- (implied+x.realized_usd)).max()
checks={
 'trade_count':int(len(x)),'distinct_pairs':int(x.pair.nunique()),'net_pnl_usd':float(calc_pnl),'final_nav_by_ledger':float(ref_final),
 'all_before_2024':bool(x.entry_ms.max()<1704067200000 and x.exit_ms.max()<=1704067200000),
 'same_entry_exit_timestamp_absent':bool((x.exit_ms>x.entry_ms).all()),
 'fixed72_exit_hours':bool((x.hours==72).all()),
 'capital_identity_max_residual_usd':float(capital_diff),
 'max_concurrent_positions_from_ledger':0,
 'duplicate_instrument_overlap':False,
 'yearly_trades':x.year.value_counts().sort_index().to_dict(),
 'trade_win_pct':float(100*(x.ret_pct>0).mean()),'trade_median_net_pct':float(x.ret_pct.median()),
 'top_three_pnl_fraction_of_net':float(x.groupby('pair').realized_usd.sum().nlargest(3).sum()/calc_pnl),
 '2023_weeks_active':int(pd.to_datetime(x[x.year==2023].entry_ms,unit='ms',utc=True).dt.to_period('W').nunique()),
 'source_limitations':['Not PIT-certified historical instrument membership','Quote turnover often computed base_volume*price','No verified historical order book, spreads, queue or exchange rejects','2022 and 2023 already exposed to research; model training used only 2018-2021 but project selection did not','Drawdown measured at hourly opens, excludes intrabar adverse extremes','No actual order execution / real-time paper-trading']
}
points=[]
for r in x.itertuples(index=False):points.extend([(int(r.entry_ms),1,r.pair),(int(r.exit_ms),-1,r.pair)])
points.sort(key=lambda a:(a[0],a[1]))
active=set();maxact=0;duplicate=False
for t,d,pair in points:
 if d==-1:active.discard(pair)
 else:
  if pair in active:duplicate=True
  active.add(pair)
 maxact=max(maxact,len(active))
checks['max_concurrent_positions_from_ledger']=maxact;checks['duplicate_instrument_overlap']=duplicate
checks['all_trade_open_exits_within_72_hours']=bool(((x.exit_ms-x.entry_ms)==72*3600000).all())
checks['best_year_profit_breakdown']=x.groupby('year').realized_usd.sum().to_dict()
# Monthly/trading profile
x['entry_date']=pd.to_datetime(x.entry_ms,unit='ms',utc=True)
x['entry_month']=x.entry_date.dt.strftime('%Y-%m')
x.groupby('entry_month').agg(trades=('pair','size'),pairs=('pair','nunique'),net_pnl_usd=('realized_usd','sum'),mean_net_trade_pct=('ret_pct','mean'),median_net_trade_pct=('ret_pct','median')).to_csv(P+'/monthly_ledger_summary.csv')
# model validation decile from existing log
for path in [P+'/stress_ledger.csv',P+'/extra_stress.csv',P+'/horizon_comparison.csv',P+'/regime_sensitivity.csv']:
 assert os.path.isfile(path)
# checksum of all outputs written afterward
with open(P+'/independent_accounting_audit.json','w') as f:json.dump(checks,f,indent=2,ensure_ascii=False,default=str)
# equity plots
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
nav['date']=pd.to_datetime(nav.unix_ms,unit='ms',utc=True)
fig,ax=plt.subplots(figsize=(10,4.3))
ax.plot(nav.date,nav.nav/1000,linewidth=1.2)
ax.set_title('C2 V9 diagnostic portfolio NAV: 2022-2023 (not certified)')
ax.set_ylabel('Portfolio value, thousands of USD')
ax.grid(True,alpha=.2)
fig.tight_layout();fig.savefig(P+'/diagnostic_equity_curve.png',dpi=160);plt.close(fig)
# More conservative 5m, 0.1% turnover variant and top3 stress plotted in report only
csv=pd.read_csv(P+'/horizon_comparison.csv');b=csv[(csv.fee_side==.003)&(~csv.top3_excluded)].sort_values('mode')
fig,ax=plt.subplots(figsize=(10,4.5));ax.bar(b['mode'].tolist(),b.total_return_pct.tolist());ax.set_ylabel('Total return, %');ax.set_title('Holding horizon sensitivity, 5M minimum, 0.1% turnover cap');ax.grid(True,axis='y',alpha=.2);fig.tight_layout();fig.savefig(P+'/holding_horizon_sensitivity.png',dpi=160);plt.close(fig)
print(json.dumps(checks,indent=2,ensure_ascii=False,default=str))
