from portfolio import calc
import pandas as pd
P='/mnt/data/AKAH_C2_V9/';rows=[]
for minliq,part in [(1e6,.0025),(5e6,.001),(5e6,.0025),(5e6,.005),(1e7,.001),(1e7,.0025)]:
 for mode in ['FIX72','FIX72_STOP20','FIX72_STOP25','ADAPT72_168']:
  args=dict(regime='GUARD200',threshold=2.234,mode=mode,min_liq=minliq,participation=part)
  first,ledger,nav=calc(**args,fee_side=.003)
  tops=ledger.groupby('pair').realized_usd.sum().nlargest(3).index.tolist() if len(ledger) else []
  for fees in [.003,.006]:
   r,_,_=calc(**args,fee_side=fees);r['removed_top_3']=False;rows.append(r)
   rr,_,_=calc(**args,fee_side=fees,exclude=tops);rr['removed_top_3']=True;rows.append(rr)
  print('DONE',minliq,part,mode,'orig',round(first['total_return_pct'],2),'top3',tops,flush=True)
pd.DataFrame([{**r,'annual_2022_pct':r['annual_pct'][2022],'annual_2023_pct':r['annual_pct'][2023]} for r in rows]).drop(columns='annual_pct').to_csv(P+'extra_stress.csv',index=False)
