import pandas as pd,numpy as np,zipfile,io,json,os
from lightgbm import LGBMRegressor,LGBMClassifier
p='/mnt/data/AKAH_C2_V9';x=pd.read_pickle(p+'/all_events.pkl')
z=zipfile.ZipFile('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_0001.zip');n=[n for n in z.namelist() if n=='hourly/KUCOIN_BTC-USDT.csv.gz'][0]
btc=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=['unix_ms','close']);btc=btc[(btc.unix_ms>0)&(btc.unix_ms<1704067200000)].drop_duplicates('unix_ms').sort_values('unix_ms')
btc['btc_24']=100*(btc.close/btc.close.shift(24)-1);btc['btc_168']=100*(btc.close/btc.close.shift(168)-1);btc['btc_720']=100*(btc.close/btc.close.shift(720)-1)
btc['btc_200d']=100*(btc.close/btc.close.shift(4800)-1)
btc=btc.rename(columns={'unix_ms':'signal_ms'})[['signal_ms','btc_24','btc_168','btc_720','btc_200d']]
x=pd.merge_asof(x.sort_values('signal_ms'),btc, on='signal_ms',direction='backward',tolerance=3600000)
x['relative_strength_168']=x.past168_pct-x.btc_168
x['low_liq']=x.liquidity_band_proxy.eq('LIQ_LOW_LT_100K_24H_PROXY').astype('float32')
x['high_liq']=x.liquidity_band_proxy.eq('LIQ_HIGH_1M_24H_PROXY').astype('float32')
x['log_base_volume']=np.log1p(x.base_volume.clip(lower=0))
x['vboost']=np.log1p(x.relative_base_volume_168h.clip(lower=0,upper=50))
# Evaluable quality signals, held price data from next open, no use of future prices or outcomes to select trades
mask=(x.high_liq==1) & (x.zero_range_share_168h.fillna(1)<=.10) &(x.past168_pct.notna())&(x.btc_168.notna())&(x.ret72_pct.notna())&(x.ret168_pct.notna())
x=x.loc[mask].copy().sort_values(['pair','signal_ms'])
# some events of duplicate venues of same pair removed; no future eligibility used in live logic; label completeness checked for model training/evaluation only
features=['signal_up_pct','past24_pct','past168_pct','close_location','relative_base_volume_168h','zero_range_share_168h','btc_24','btc_168','btc_720','btc_200d','relative_strength_168','log_base_volume','vboost']
for c in features:x[c]=x[c].astype('float32').replace([np.inf,-np.inf],np.nan)
# non-overlapping observational training sample: ignore events within 72h of an earlier event of same pair, independent of outcomes
x['prev_signal_ms']=x.groupby('pair').signal_ms.shift(1)
# robust event time declustering with a deterministic 72h cutoff from last accepted signal (not last raw one)
keep=np.zeros(len(x),bool)
last={}
for i,(pa,t) in enumerate(zip(x.pair.values,x.signal_ms.values)):
 if t-last.get(pa,0)>=72*3600000:
  keep[i]=True;last[pa]=t
train=x.loc[keep&(x.year.between(2018,2020))&x.ret72_pct.notna()].copy()
val=x.loc[keep&(x.year==2021)&x.ret72_pct.notna()&x.ret168_pct.notna()].copy()
print('EVENTS quality',x.year.value_counts().sort_index().to_dict(),'train',len(train),'val',len(val),flush=True)
# train 2018-20, choose static thresholds calibrated on 2021 cross-sectional ranking. No 2022/2023 labels used to fit nor select thresholds.
# predict 72-hour economic outcome, clip very rare moonshots so scores do not concentrate solely on tail
model=LGBMRegressor(n_estimators=165,num_leaves=9,max_depth=5,learning_rate=.055,min_child_samples=180,reg_lambda=15,verbosity=-1,random_state=17,n_jobs=4)
model.fit(train[features],train.ret72_pct.clip(-20,30));val['score']=model.predict(val[features]);
print('2021 val score decile means')
val['decile']=pd.qcut(val.score.rank(method='first'),10,labels=False)
print(val.groupby('decile').agg(n=('pair','size'),avg72=('ret72_pct','mean'),med72=('ret72_pct','median'),avg168=('ret168_pct','mean')).to_string(),flush=True)
q=[.80,.9,.95,.98];thresholds={str(qi):float(val.score.quantile(qi)) for qi in q};print('thresholds',thresholds)
# refit full data prior to 2022
train2=x.loc[keep&(x.year.between(2018,2021))&x.ret72_pct.notna()].copy()
model2=LGBMRegressor(n_estimators=165,num_leaves=9,max_depth=5,learning_rate=.055,min_child_samples=180,reg_lambda=15,verbosity=-1,random_state=17,n_jobs=4)
model2.fit(train2[features],train2.ret72_pct.clip(-20,30));model2.booster_.save_model(p+'/AKAH_C2_PRE2022_IMPULSE_SCORER.txt');test=x.loc[x.year.isin([2022,2023])].copy();test['score']=model2.predict(test[features]);
# to avoid threshold distribution shifting, compare rank-within hour candidates and quantiles calibrated on 2021 retraining 2018-2020; 2021 thresholds can be applied
for year,g in test.groupby('year'):
 print('YEAR',year,'n',len(g),'prediction mean',g.score.mean())
 for qi,t in thresholds.items():
  d=g[g.score>=t]
  if len(d):print('q',qi,'n',len(d),'pairs',d.pair.nunique(),'gross72mean',round(d.ret72_pct.mean(),2),'net72median',round(d.ret72_pct.median()-.6,2),'gross168mean',round(d.ret168_pct.mean(),2),'net168median',round(d.ret168_pct.median()-.6,2))
# save all asof event data / predictions
out=test[['pair','venue','signal_ms','year','score','signal_up_pct','past24_pct','past168_pct','btc_24','btc_168','btc_720','btc_200d','relative_strength_168','relative_base_volume_168h','zero_range_share_168h','ret24_pct','ret72_pct','ret168_pct']].copy();out.to_pickle(p+'/predicted_2022_2023.pkl');
json.dump({'features':features,'thresholds_2021_validation':thresholds,'train_events':len(train),'val_events':len(val),'test_events':len(test)},open(p+'/model_meta.json','w'),indent=2)
