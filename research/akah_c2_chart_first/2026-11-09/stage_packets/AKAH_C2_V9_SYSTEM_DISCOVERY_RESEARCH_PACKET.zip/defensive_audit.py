from portfolio import calc
import pandas as pd,json
P='/mnt/data/AKAH_C2_V9/';args=dict(regime='GUARD200',threshold=2.234,mode='FIX120',min_liq=5e6,participation=.001)
r,ledger,nav=calc(**args,fee_side=.003)
ledger.to_csv(P+'defensive_120h_trades.csv',index=False);nav.to_csv(P+'defensive_120h_daily_nav.csv',index=False)
print('DEFENSIVE',r)
print('TOP',ledger.groupby('pair').realized_usd.sum().nlargest(12).to_dict())
print('YEAR',ledger.groupby('year').agg(trades=('pair','size'),pnl=('realized_usd','sum'),win_pct=('ret_pct',lambda x:100*(x>0).mean()),median_pct=('ret_pct','median')).to_string())
print('weeks with entries',ledger.groupby('year').apply(lambda g:pd.to_datetime(g.entry_ms,unit='ms',utc=True).dt.to_period('W').nunique(),include_groups=False).to_dict())
print('max abs loss',ledger.ret_pct.min(),'max gain',ledger.ret_pct.max())
rr,_,_=calc(**args,fee_side=.006);print('COST2X',rr)
top3=ledger.groupby('pair').realized_usd.sum().nlargest(3).index.tolist()
print('EXCLUDE_TOP3',top3)
rr,_,_=calc(**args,fee_side=.006,exclude=top3);print('COST2X_REMOVE_TOP3',rr)
