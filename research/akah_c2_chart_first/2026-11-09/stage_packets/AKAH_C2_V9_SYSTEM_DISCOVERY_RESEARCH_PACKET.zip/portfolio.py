import pandas as pd,numpy as np,zipfile,io,json,glob,collections,os,sys
P='/mnt/data/AKAH_C2_V9';HOUR=3600000;END=1704067200000;BEGIN=1640995200000
x=pd.read_pickle(P+'/predicted_2022_2023.pkl')
# score from training ending 2021; all features asof bar close. No future outcomes as signal criterion.
x=x[(x.score>=2.2)&(x.relative_strength_168>0)&(x.btc_168>0)].copy()
x['entry_ms']=x.signal_ms+HOUR
x=x[(x.entry_ms>=BEGIN)&(x.entry_ms<END)].copy()
print('eligible score / relative strength / BTC168',len(x),x.pair.nunique(),flush=True)
keys=set(x.venue+'_'+x.pair)
raw={}
for file in sorted(glob.glob('/mnt/data/UPLOAD_THIS_AKAH_C2_364_RAW_PART_*.zip')):
 z=zipfile.ZipFile(file)
 for n in z.namelist():
  if not n.startswith('hourly/'):continue
  k=n[len('hourly/'):-len('.csv.gz')]
  if k not in keys:continue
  a=pd.read_csv(io.BytesIO(z.read(n)),compression='gzip',usecols=['unix_ms','open','high','low','close','base_volume']);a=a[(a.unix_ms>=BEGIN-35*86400000)&(a.unix_ms<END)].dropna(subset=['unix_ms','open','high','low','close']).sort_values('unix_ms').drop_duplicates('unix_ms',keep='last')
  if len(a)<50:continue
  t=a.unix_ms.to_numpy(np.int64); o=a.open.to_numpy(float);h=a.high.to_numpy(float);l=a.low.to_numpy(float);c=a.close.to_numpy(float);v=a.base_volume.to_numpy(float)
  # lagged notional is a *proxy* if quote volume unavailable. compute full trailing 24 bars but count continuity in 24h to avoid invalid liquidity
  q=pd.Series(np.maximum(v,0)*c).rolling(24,min_periods=24).sum().to_numpy()
  cont=(t-np.roll(t,23)==23*HOUR);cont[:23]=False;q[~cont]=np.nan
  raw[k]=(t,o,h,l,c,q)
print('raw loaded',len(raw),flush=True)
x['key']=x.venue+'_'+x.pair
x=x[x.key.isin(raw)].copy()
# precompute trade paths without requiring complete futures as condition of entry.
# exits: FIX72, FIX168, TRAIL6_336, TRAIL9_336, PARTIAL6_336; all exits apply stop at levels determined before bar opens.
def path(key,idx,mode):
 t,o,h,l,c,q=raw[key];p=o[idx]
 if not np.isfinite(p) or p<=0:return None
 high_water=p;stop=p*.92;horizon={'FIX12':12,'FIX24':24,'FIX48':48,'FIX96':96,'FIX120':120,'FIX240':240,'FIX336':336,'FIX72':72,'FIX168':168,'TRAIL6_336':336,'TRAIL9_336':336,'PARTIAL6_336':336,'FIX72_STOP12':72,'FIX72_STOP20':72,'FIX72_STOP25':72,'ADAPT72_168':168}[mode]
 orig_t=t[idx];partial=False;part_px=0
 for j in range(idx,min(len(t),idx+horizon+1)):
  age=j-idx
  if t[j]!=orig_t+age*HOUR:
   # gap: price executable at first available next bar with adverse fill haircut
   if age>0:return (int(t[j]),o[j]*.98,'GAP_FORCED',age,partial,part_px)
   return None
  if age==horizon:return (int(t[j]),o[j],'TIME',age,partial,part_px)
  if age and mode.startswith('FIX72_STOP') and l[j]<=p*(1-float(mode.replace('FIX72_STOP',''))/100):
   stop0=p*(1-float(mode.replace('FIX72_STOP',''))/100)
   return(int(t[j]),min(o[j],stop0),'HARD_STOP',age,partial,part_px)
  if mode=='ADAPT72_168' and age==72 and (c[j-1]/p<1.06 or c[j-1]<=c[j-25]):
   return(int(t[j]),o[j],'WEAK_AT_72_EXIT',age,partial,part_px)
  if mode=='ADAPT72_168' and age>72 and l[j]<=high_water*.88:
   return(int(t[j]),min(o[j],high_water*.88),'EXTENDED_STOP',age,partial,part_px)
  if age and mode in ('TRAIL6_336','TRAIL9_336','PARTIAL6_336'):
   if l[j]<=stop:return(int(t[j]),min(o[j],stop),'STOP',age,partial,part_px)
  # partial profit at intrabar high: conservative assume if initial stop hit, stop checks earlier. partial only after price has appreciated >=6% and stop not hit
  if mode=='PARTIAL6_336' and not partial and h[j]>=p*1.06:
   partial=True;part_px=p*1.06
  high_water=max(high_water,h[j]);
  if mode=='TRAIL6_336' or mode=='PARTIAL6_336':
   stop=max(stop,high_water*.94) if high_water>=p*1.04 else stop
   if high_water>=p*1.06:stop=max(stop,p*1.001)
  elif mode=='TRAIL9_336':
   stop=max(stop,high_water*.91) if high_water>=p*1.06 else stop
 if len(t):return (int(t[-1]+HOUR),c[-1],'DATA_END_MARK',len(t)-idx,partial,part_px)
 return None
# prepare features all candidates once, 5 policies
modes=['FIX12','FIX24','FIX48','FIX72','FIX96','FIX120','FIX168','FIX240','FIX336','TRAIL6_336','TRAIL9_336','FIX72_STOP12','FIX72_STOP20','FIX72_STOP25','ADAPT72_168']
trades=[];bad=collections.Counter()
for r in x.itertuples(index=False):
 t,o,h,l,c,q=raw[r.key];j=np.searchsorted(t,r.entry_ms)
 if j>=len(t) or t[j]!=r.entry_ms or j==0 or t[j]-t[j-1]!=HOUR:bad['MISSING_NEXT_OPEN']+=1;continue
 # ex-ante liquidity may be unavailable; no filler
 if not np.isfinite(q[j-1]):bad['UNKNOWN_T24_LIQUIDITY']+=1;continue
 # use 1% max 24h *quote estimate*, size cap at time of signal. entry can exceed cap if large gap but not known
 volume=float(q[j-1]);
 if volume<1_000_000:bad['LIQUIDITY_LT_1M']+=1;continue
 rs=float(r.relative_strength_168);btc200=float(r.btc_200d);btc720=float(r.btc_720)
 data={'key':r.key,'pair':r.pair,'entry_ms':int(r.entry_ms),'score':float(r.score),'liquidity':volume,'entry_price':float(o[j]),'btc200':btc200,'btc720':btc720,'rs168':rs,'year':int(r.year)}
 for mode in modes:data[mode]=path(r.key,j,mode)
 trades.append(data)
print('candidates with executable next open',len(trades),'bad',bad,flush=True)
from collections import defaultdict

def calc(regime='GUARD200',threshold=3.066,mode='TRAIL6_336',fee_side=.003,exclude=None,sz=.15,min_liq=1000000.,participation=.01,delay_h=0,btc200_min=0):
 cand=[d for d in trades if d['score']>=threshold and (regime!='GUARD200' or d['btc200']>btc200_min and d['btc720']>0) and (regime!='GUARD30' or d['btc720']>0) and (exclude is None or d['pair'] not in ([exclude] if isinstance(exclude,str) else exclude)) and d[mode] is not None and d['liquidity']>=min_liq]
 if delay_h:
  delay=[]
  for d in cand:
   tt,oo,*_=raw[d['key']];jj=np.searchsorted(tt,d['entry_ms']);kk=jj+delay_h
   if kk>=len(tt) or tt[kk]!=d['entry_ms']+delay_h*HOUR:continue
   ex=path(d['key'],kk,mode)
   if ex is not None:delay.append({**d,'entry_ms':int(tt[kk]),'entry_price':float(oo[kk]),mode:ex})
  cand=delay
 cand.sort(key=lambda d:(d['entry_ms'],-d['score'],d['pair']))
 # zero data after year end? path can stop before END and uses no future data; csv pre2024 only
 cash=100000.;openp={};closed=[];daily=[];peak=100000.;dd=0.;maxactive=0;cooldown={};idx=0;year22nav=None
 # map all required timestamps hourly for full mark-to-market; price available from provided raw only
 for t0 in range(BEGIN,END,HOUR):
  # position exits at earliest of scheduled time or 2023 end, and mark at open of hour
  for key,pos in list(openp.items()):
   ex_t,ex_px,why,held,partial,part_px=pos['out']
   if ex_t>t0:continue
   # separate 50% at target, but physical partial may be earlier; cash booking at exit time creates timing inaccuracy for interim NAV; see below flag
   frac=.5 if (mode=='PARTIAL6_336' and partial) else 0
   units=pos['units']; proceeds=units*((1-frac)*ex_px+frac*part_px)*(1-fee_side)
   cash+=proceeds
   gross=(proceeds-pos['spend'])/pos['spend']
   closed.append(dict(pair=pos['pair'],entry_ms=pos['entry_ms'],exit_ms=ex_t,score=pos['score'],year=pd.Timestamp(pos['entry_ms'],unit='ms',tz='UTC').year,ret_pct=gross*100,realized_usd=proceeds-pos['spend'],hours=held,reason=why,liq=pos['liquidity'],regime=regime,mode=mode,cost=fee_side*2,entry=pos['entry_price'],exit=ex_px))
   cooldown[key]=ex_t+12*HOUR
   del openp[key]
  # conservative cash before marking active positions at each hourly open
  nv=cash
  for key,pos in openp.items():
   arr=raw[key]; tt=arr[0]; k=np.searchsorted(tt,t0,side='right')-1
   px=arr[1][k] if k>=0 and tt[k]==t0 else (arr[4][k] if k>=0 else pos['entry_price'])
   nv+=pos['units']*px
  peak=max(peak,nv);dd=min(dd,nv/peak-1)
  if t0==1672531200000:year22nav=nv
  if t0%(24*HOUR)==0:daily.append((t0,nv,len(openp)))
  # true asynchronous event arrival; score and btc features as of last hour already saved, no future dependent at entry
  at=[]
  while idx<len(cand) and cand[idx]['entry_ms']<=t0:
   if cand[idx]['entry_ms']==t0:at.append(cand[idx])
   idx+=1
  for d in sorted(at,key=lambda d:(-d['score'],d['pair'])):
   key=d['key']
   if len(openp)>=3 or key in openp or t0<cooldown.get(key,0):continue
   # use observable NAV after exits, before new positions
   nav=cash+sum(p['units']*p['entry_price'] for p in openp.values())
   notional=min(nav*sz,d['liquidity']*participation,cash/(1+fee_side))
   if notional<100:continue
   units=notional/d['entry_price'];spend=notional*(1+fee_side);cash-=spend
   openp[key]={**d,'units':units,'spend':spend,'out':d[mode]};maxactive=max(maxactive,len(openp))
 # final at 2023 end if still open, last observed close; annual group cash effects real
 for key,pos in openp.items():
  arr=raw[key];tt=arr[0];i=np.searchsorted(tt,END,side='left')-1;px=arr[4][i] if i>=0 else 0
  proceeds=pos['units']*px*(1-fee_side);cash+=proceeds
  closed.append(dict(pair=pos['pair'],entry_ms=pos['entry_ms'],exit_ms=END,score=pos['score'],year=pd.Timestamp(pos['entry_ms'],unit='ms',tz='UTC').year,ret_pct=100*(proceeds-pos['spend'])/pos['spend'],realized_usd=proceeds-pos['spend'],hours=(END-pos['entry_ms'])//HOUR,reason='END_OF_2023',liq=pos['liquidity'],regime=regime,mode=mode,cost=fee_side*2,entry=pos['entry_price'],exit=px))
 nv=cash
 df=pd.DataFrame(closed)
 ddf=pd.DataFrame(daily,columns=['unix_ms','nav','open_positions'])
 yearnav={2022:float(year22nav) if year22nav is not None else 100000.,2023:float(cash)}
 annual={2022:100*(yearnav[2022]/100000-1),2023:100*(yearnav[2023]/yearnav[2022]-1)}
 top=df.groupby('pair').realized_usd.sum().sort_values(ascending=False) if len(df) else pd.Series(dtype=float)
 return dict(regime=regime,threshold=threshold,mode=mode,fee_side=fee_side,exclude=exclude,min_liq=min_liq,participation=participation,delay_h=delay_h,btc200_min=btc200_min,trades=len(df),pairs=df.pair.nunique() if len(df) else 0,final_nav=float(nv),total_return_pct=100*(nv/100000-1),annual_pct=annual,max_dd_pct=100*dd,top_pair=top.index[0] if len(top) else '',top_pair_profit=float(top.iloc[0]) if len(top) else 0.,maxactive=maxactive),df,ddf

if __name__ == "__main__":
 results=[]
 for regime in ['GUARD200','GUARD30']:
  for thr in [2.234,3.066,3.862]:
   for mode in modes:
    if mode=='PARTIAL6_336':continue
    r,_,_=calc(regime,thr,mode,.003);results.append(r);print('RESULT',r,flush=True)
 pd.DataFrame([{**r,'annual_2022_pct':r['annual_pct'][2022],'annual_2023_pct':r['annual_pct'][2023]} for r in results]).drop(columns='annual_pct').to_csv(P+'/research_comparisons.csv',index=False)
 # exact order and per-year for three preselected representative policies, no claims of independent holdout
 for name,settings in [('strict',('GUARD200',3.862,'TRAIL6_336')),('balanced',('GUARD200',3.066,'TRAIL6_336')),('broad',('GUARD200',2.234,'FIX72'))]:
  regime,thr,mode=settings
  for f in [.003,.006]:
   r,ledger,nav=calc(regime,thr,mode,f)
   if f==.003:
    ledger.to_csv(P+f'/{name}_ledger.csv',index=False);nav.to_csv(P+f'/{name}_daily_nav.csv',index=False)
   print('DETAIL',name,f,r,flush=True)
   # asset exclusion with strategy rebuilt, not just subtract contributions
   if r['top_pair']:
    rr,_,_=calc(regime,thr,mode,f,r['top_pair']);print('EXCLUDE',name,f,rr,flush=True)
