#!/usr/bin/env python3
"""AKAH R54-P0/1 -- bounded, read-only source authority discovery.

Never reads market rows, trade rows, or datasets from 2024; only reads
metadata, safe governance documents, ZIP central directories, and qualifying
2022/2023 CSV headers. No repo writes, no external services, no tuning.
"""
from __future__ import annotations
import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback
import zipfile

VERSION = "R54_P0_V1_SOURCE_AUTHORITY_ONLY"
FOLDER_SKIP = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".tox", ".idea", ".vscode", "dist", "build", "site-packages", "$recycle.bin"}
ALLOWED_READ_TEXT = {".csv"}
YEAR_2024_RE = re.compile(r"(?<!\d)2024(?!\d)")
LARGE_HASH_MAX_BYTES = 64 * 1024 * 1024
MAX_ZIP_ENTRIES = 20000
MAX_REPO_FILES = 120000
MAX_CANDIDATES = 1500


def is_2024(name: str) -> bool:
    return bool(YEAR_2024_RE.search(name.replace("\\", "/")))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def classify(path_str: str) -> tuple[int, list[str]]:
    s = path_str.lower().replace("\\", "/")
    rules = (
        ("rd33", r"rd[_-]?33|first[_-]?retest|retest[_-]?reclaim", 35),
        ("r50", r"(?<!\d)r50(?!\d)|revision[_-]?50|frozen[_-]?r50", 35),
        ("r53r1", r"r53r1|r53[_-]?r1|recovered[_-]?architecture", 45),
        ("r53", r"(?<!\d)r53(?!\d)|architecture[_-]?results", 30),
        ("governance", r"governance|system[_-]?charter|authority|protocol[_-]?freeze", 12),
        ("pit_universe", r"membership|point[_-]?in[_-]?time|dynamic[_-]?universe|pit[_-]?universe|historical[_-]?universe|delist", 28),
        ("execution_cost", r"slippage|fee[_-]?model|execution[_-]?cost|execution[_-]?simulator|fill[_-]?model", 23),
        ("trade_replay", r"trade[_-]?replay|canonical[_-]?replay|hourly[_-]?mtm|real[_-]?tape|entry[_-]?exit", 20),
        ("c2", r"(?<!\w)c2(?!\w)|frozen[_-]?20pair", 9),
        ("market_data", r"ohlcv|candles|klines|market[_-]?data|1h[_-]?usdt|_2022|_2023", 10),
    )
    labels = []
    score = 0
    for label, pattern, points in rules:
        if re.search(pattern, s):
            labels.append(label)
            score += points
    if s.endswith((".zip", ".json.gz", ".json", ".parquet", ".csv", ".log")):
        score += 2
    if "/governance/" in s:
        score += 5
    return score, labels


def safe_stat(path: Path) -> dict:
    try:
        st = path.stat()
        return {"path": str(path), "size_bytes": st.st_size, "mtime_utc": dt.datetime.fromtimestamp(st.st_mtime, dt.timezone.utc).isoformat()}
    except OSError as e:
        return {"path": str(path), "stat_error": str(e)}


def list_repo(root: Path, errors: list) -> tuple[list[dict], dict]:
    candidates = []
    info = {"total_file_names_examined": 0, "2024_named_paths_excluded": 0, "folders_examined": 0, "files_from_2024_read": 0, "market_rows_read": 0, "limit_reached": False}
    for directory, dirs, files in os.walk(root, topdown=True, followlinks=False):
        info["folders_examined"] += 1
        filtered = []
        for d in dirs:
            if d.lower() in FOLDER_SKIP:
                continue
            if is_2024(d) or is_2024(str(Path(directory) / d)):
                info["2024_named_paths_excluded"] += 1
                continue
            filtered.append(d)
        dirs[:] = filtered
        if info["folders_examined"] > 40000:
            info["limit_reached"] = True
            errors.append("directory_limit_40000_reached")
            break
        for file in files:
            info["total_file_names_examined"] += 1
            if info["total_file_names_examined"] > MAX_REPO_FILES:
                info["limit_reached"] = True
                errors.append("file_limit_120000_reached")
                break
            full = Path(directory) / file
            if is_2024(str(full)):
                info["2024_named_paths_excluded"] += 1
                continue
            relative = full.relative_to(root).as_posix()
            score, labels = classify(relative)
            if score >= 12:
                item = safe_stat(full)
                item.update({"relative_path": relative, "score": score, "roles": labels, "origin": "repo", "file_content_read": False})
                candidates.append(item)
        if info["limit_reached"]:
            break
    candidates.sort(key=lambda x: (-x["score"], x["relative_path"]))
    info["candidate_files_ranked"] = len(candidates)
    info["candidate_files_emitted"] = min(len(candidates), MAX_CANDIDATES)
    return candidates[:MAX_CANDIDATES], info


def list_downloads(downloads: Path, errors: list) -> list[dict]:
    if not downloads.is_dir():
        errors.append("downloads_directory_missing")
        return []
    candidates = []
    try:
        for f in downloads.iterdir():
            if is_2024(f.name) or not f.is_file():
                continue
            score, labels = classify(f.name)
            if score < 12 and "AKAH" not in f.name.upper():
                continue
            obj = safe_stat(f)
            obj.update({"relative_path": f.name, "score": score + 5, "roles": labels, "origin": "downloads", "file_content_read": False})
            candidates.append(obj)
    except OSError as e:
        errors.append("downloads_scan_error: " + str(e))
    return sorted(candidates, key=lambda x: (-x["score"], x["relative_path"]))[:350]


def audit_archives(candidates: list[dict], errors: list) -> list[dict]:
    archives = []
    selected = [x for x in candidates if x["origin"] == "downloads" and x["path"].lower().endswith(".zip")]
    for x in selected[:18]:
        path = Path(x["path"])
        rec = {"path": str(path), "read_mode": "ZIP_CENTRAL_DIRECTORY_NAMES_ONLY", "contents_extracted": False, "market_rows_read": 0}
        try:
            with zipfile.ZipFile(path, "r") as z:
                listing = z.infolist()
                rec["entry_count"] = len(listing)
                rec["has_2024_named_member"] = any(is_2024(m.filename) for m in listing)
                rec["member_count_limit_exceeded"] = len(listing) > MAX_ZIP_ENTRIES
                if not rec["has_2024_named_member"] and not rec["member_count_limit_exceeded"]:
                    rec["candidate_members"] = [
                        {"name": m.filename, "size_bytes": m.file_size} for m in listing
                        if not m.is_dir() and classify(m.filename)[0] >= 12
                    ][:75]
                else:
                    rec["candidate_members"] = []
                rec["status"] = "SKIP_ARCHIVE_WITH_2024_OR_UNBOUNDED_LIST" if rec["has_2024_named_member"] or rec["member_count_limit_exceeded"] else "METADATA_ONLY"
        except (OSError, zipfile.BadZipFile, RuntimeError) as e:
            rec["status"] = "ARCHIVE_UNREADABLE"
            rec["error"] = str(e)
            errors.append("bad_archive: " + path.name)
        archives.append(rec)
    return archives


def audit_governance(repo: Path, errors: list) -> dict:
    path = repo / "governance" / "AKAH_BOT_SYSTEM_CHARTER.json"
    rec = {"path": str(path), "status": "NOT_FOUND", "market_data_accessed": False}
    if not path.is_file():
        return rec
    try:
        if path.stat().st_size > 20 * 1024 * 1024:
            rec["status"] = "FILE_TOO_LARGE"
            return rec
        rec["sha256"] = sha256_file(path)
        d = json.loads(path.read_text(encoding="utf-8-sig"))
        rec["status"] = "READ_ONLY_PARSED"
        rec["top_level_keys"] = list(d)[:60] if isinstance(d, dict) else []
        for field in ("version", "revision", "last_updated", "schema_version"):
            if isinstance(d, dict) and isinstance(d.get(field), (str, int, float, bool)):
                rec[field] = d[field]
    except Exception as e:
        rec["status"] = "PARSE_ERROR"
        rec["error"] = str(e)
        errors.append("governance_parse_error: " + str(e))
    return rec


def git_identity(repo: Path) -> dict:
    rec = {}
    for key, cmd in (("head", ["git", "-C", str(repo), "rev-parse", "HEAD"]),
                     ("branch", ["git", "-C", str(repo), "branch", "--show-current"])):
        try:
            run = subprocess.run(cmd, capture_output=True, text=True, timeout=15, check=False)
            rec[key] = run.stdout.strip() if run.returncode == 0 else None
            if run.returncode != 0:
                rec[key + "_error"] = run.stderr.strip()[:250]
        except (OSError, subprocess.TimeoutExpired) as e:
            rec[key] = None
            rec[key + "_error"] = str(e)
    return rec


def csv_header_probe(candidates: list[dict]) -> list[dict]:
    out = []
    for x in candidates:
        if len(out) >= 30:
            break
        relative = x.get("relative_path", "").lower()
        if x["origin"] != "repo" or not relative.endswith(".csv"):
            continue
        # Only explicit 2022/2023 partitions, never generic mixed-year files.
        if not (re.search(r"(?<!\d)2022(?!\d)", relative) or re.search(r"(?<!\d)2023(?!\d)", relative)):
            continue
        if is_2024(relative):
            continue
        fp = Path(x["path"])
        rec = {"path": str(fp), "mode": "FIRST_CSV_HEADER_ONLY", "market_rows_read": 0}
        try:
            with fp.open("rb") as f:
                line = f.readline(4096).rstrip(b"\r\n")
            rec["header"] = next(csv.reader([line.decode("utf-8-sig", errors="replace")]))[:48] if line else []
            rec["bytes_read_at_most"] = 4096
        except (OSError, csv.Error) as e:
            rec["error"] = str(e)
        out.append(rec)
    return out


def strict_closed_candle_sweep_reclaim(candles: list[dict], horizon_hours: int) -> bool:
    """Synthetic diagnostic primitive only; NOT a strategy entry signal.
    An event on last CLOSED hourly candle relative to preceding N CLOSED candles.
    """
    if horizon_hours <= 0 or len(candles) < horizon_hours + 1:
        return False
    prior_lows = [float(c["low"]) for c in candles[-(horizon_hours + 1):-1]]
    prev_floor = min(prior_lows)
    now = candles[-1]
    return float(now["low"]) < prev_floor and float(now["close"]) > prev_floor


def selftests() -> list[str]:
    rows = [{"low": 100.0, "close": 104.0} for _ in range(720)]
    event = {"low": 97.0, "close": 101.0}
    assert strict_closed_candle_sweep_reclaim(rows + [event], 24)
    assert strict_closed_candle_sweep_reclaim(rows + [event], 168)
    assert strict_closed_candle_sweep_reclaim(rows + [event], 720)
    assert not strict_closed_candle_sweep_reclaim(rows[:23] + [event], 24)
    assert not strict_closed_candle_sweep_reclaim(rows + [{"low": 100.0, "close": 101.0}], 24)
    a = strict_closed_candle_sweep_reclaim(rows + [event], 24)
    b = strict_closed_candle_sweep_reclaim(rows + [event] + [{"low": 20.0, "close": 25.0}], 24)
    assert a and not b  # No retroactive recount: at t+1 the decision belongs to t+1.
    assert not is_2024("tape/2022/BTC.csv")
    assert is_2024("tape/2024/BTC.csv")
    assert is_2024("tape/all_2022_2024.csv")
    return ["PASS_RECLAIM_24H", "PASS_RECLAIM_168H", "PASS_RECLAIM_720H", "PASS_NO_INCOMPLETE_HISTORY", "PASS_STRICT_SWEEP", "PASS_ASOF_DECISION", "PASS_YEAR_PATH_GUARD"]


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--repo", required=True)
    p.add_argument("--downloads", required=True)
    p.add_argument("--out", required=True)
    args = p.parse_args()
    repo = Path(args.repo).resolve()
    out = Path(args.out).resolve()
    downloads = Path(args.downloads).resolve()
    if not repo.is_dir():
        print("R54_P0_FAIL=REPOSITORY_DIRECTORY_NOT_FOUND", flush=True)
        return 2
    # Output must not reside inside repo.
    if out == repo or repo in out.parents:
        print("R54_P0_FAIL=OUTPUT_INSIDE_REPOSITORY_FORBIDDEN", flush=True)
        return 3
    out.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    passes = selftests()
    repo_candidates, stats = list_repo(repo, errors)
    download_candidates = list_downloads(downloads, errors)
    candidates = repo_candidates + download_candidates
    archive_manifest = audit_archives(download_candidates, errors)
    headers = csv_header_probe(repo_candidates)
    governance = audit_governance(repo, errors)
    identity = git_identity(repo)
    roles = collections.Counter(role for item in candidates for role in item.get("roles", []))
    report = {
        "version": VERSION,
        "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "repo_path": str(repo),
        "repo_identity": identity,
        "downloads_path": str(downloads),
        "phase": "P0_SOURCE_AUTHORITY_DISCOVERY_ONLY",
        "status": "PASS_DISCOVERY_AUTHORITY_BINDING_PENDING" if not stats["limit_reached"] else "INCOMPLETE_DISCOVERY_LIMIT_REACHED",
        "2024_market_rows_read": 0,
        "all_market_rows_read": 0,
        "trade_rows_read": 0,
        "economic_backtests_run": 0,
        "production_files_modified": 0,
        "repo_files_modified": 0,
        "live_trading_enabled": False,
        "pit_c2_historical_certification": "NOT_ESTABLISHED",
        "data_schema_verified": False,
        "rd33_original_authority_verified": False,
        "r50_frozen_authority_verified": False,
        "r53r1_recovered_authority_verified": False,
        "selftests": passes,
        "inventory": stats,
        "role_counts": dict(roles),
        "governance": governance,
        "archives_inspected": len(archive_manifest),
        "csv_headers_read": len(headers),
        "errors": errors[:100],
        "stop_reason": "Need source-to-authority mapping, strict per-year tape/coverage and PIT proof before event or PnL computation."
    }
    write_json(out / "R54_P0_RUN_REPORT.json", report)
    write_json(out / "R54_P0_SOURCE_CANDIDATES.json", candidates)
    write_json(out / "R54_P0_ARCHIVE_MANIFESTS.json", archive_manifest)
    write_json(out / "R54_P0_SAFE_2022_2023_CSV_HEADERS.json", headers)
    decisions = {
        "rd33_original": "NOT_PINNED",
        "r50_frozen_12_cells": "NOT_PINNED",
        "r53r1_recovered": "NOT_PINNED",
        "pit_membership_2022_2023": "NOT_CERTIFIED",
        "2022_2023_tape": "NOT_PINNED",
        "execution_cost_1x_2x": "NOT_PINNED",
        "capital_continuity_exit_rules": "NOT_PINNED",
        "unapproved_inference_from_filename": "FORBIDDEN",
        "next_gate": "P0_AUTHORITY_BINDING_AND_PIT_CERTIFICATION",
        "2024": "SEALED_NO_DATA_ACCESS"
    }
    write_json(out / "R54_P0_EVIDENCE_GATE.json", decisions)
    lines = ["# R54-P0 read-only evidence discovery", "", "This is source discovery, not a profitable backtest or a research certification.", "", f"- Status: {report['status']}", f"- Repo: {repo}", f"- HEAD: {identity.get('head')}", f"- Branch: {identity.get('branch')}", f"- Repo filenames examined: {stats['total_file_names_examined']}", f"- Candidate paths emitted: {len(candidates)}", f"- ZIP central directories inspected: {len(archive_manifest)}", f"- CSV header probes (explicit 2022/2023 only): {len(headers)}", "- Market rows inspected: ZERO", "- All 2024 market data: UNREAD", "- Backtests: NONE", "- Live/production changes: NONE", "", "## Authority sources", "", "The script deliberately does NOT claim filenames prove canonical source authority.", "Next stage must pin original RD33, frozen R50 12-cell baseline, R53R1 recovery, PIT historic membership, coverage, executable OHLCV and exact cost/portfolio definitions.", "", "## Ranked examples"]
    for item in candidates[:35]:
        lines.append(f"- {item['origin']} | {item['score']} | {item['relative_path']}")
    lines.extend(["", "## Guardrails", "", "No 2024 source file has been opened; no market or trade rows have been read; no parameters chosen. Synthetic event selftests do not claim an economic edge."])
    (out / "README_RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("R54_P0_VERSION=" + VERSION)
    print("R54_P0_STATUS=" + report["status"])
    print("R54_REPO_HEAD=" + str(identity.get("head")))
    print("R54_SELFTEST=" + "|".join(passes))
    print("R54_MARKET_ROWS_READ=0")
    print("R54_2024_MARKET_ROWS_READ=0")
    print("R54_REPO_MUTATIONS=0")
    print("R54_ECONOMIC_RESULTS=NOT_YET_MEASURED")
    print("R54_SOURCE_AUTHORITY=NOT_YET_CERTIFIED")
    print("R54_CANDIDATES=" + str(len(candidates)))
    print("R54_REPORT_DIR=" + str(out))
    return 0 if not stats["limit_reached"] else 4

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(1)
