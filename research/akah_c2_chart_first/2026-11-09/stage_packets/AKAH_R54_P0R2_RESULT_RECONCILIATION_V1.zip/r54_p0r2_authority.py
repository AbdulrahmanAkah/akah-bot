#!/usr/bin/env python3
"""AKAH R54 P0R2: bounded offline source reconciliation. No market access, no execution."""
from __future__ import annotations
import argparse,csv,datetime,hashlib,io,json,os,re,sys,zipfile
from pathlib import Path

VER='R54_P0R2_FROZEN_AUTHORITY_AND_RESULT_RECOVERY_V1'
PIN_R50='B01D8EFBD61434A156A76B1D1D3432292F6750F18B71C9F0D046B7C24A719F9F'
PIN_P0R1='DE7147CB8D8899A2D27F9E59A3831ED9835D7BBABB8A47D0CE3380F05684A0F1'
P0R1_R50='evidence/archives/AKAH_R53_ARCHITECTURE_TOURNAMENT_ONEPASS.zip/baseline/R50_ABSOLUTE_LONG_PERMISSION_12_FROZEN_ECONOMIC_CELLS.csv'
P0R1_R53_MANIFEST='evidence/archives/AKAH_R53_ARCHITECTURE_TOURNAMENT_ONEPASS.zip/R53_SHA256_MANIFEST.json'
R53_RESULT_FILES=['R53_REPLAY_AUDIT.json','R53R1_RECOVERY_AUDIT.json','R53_48_PORTFOLIO_YEAR_RESULTS.csv','R53_36_PAIRED_ARCHITECTURE_COMPARISONS.csv','R53_12_EXACT_R50_REFERENCE_PARITY.csv','R53_FINAL_AUDIT.json','R53_RESULT_AUTHORITY.json']
RD33_FILES=['rd33-p1-temporal-mb-architecture-report-v1.json','portfolio-run-metrics.csv','portfolio-period-metrics.csv','hard-gate-evaluation.csv','causality-mapping-audit.json','control-parity-vs-rd32.json','selected-temporal-mb-policy-freeze.json','output-manifest.json']
MAX_ZIP_SIZE=500_000_000; MAX_MEMBER_SIZE=12_000_000; MAX_EXPORT_BYTES=24_000_000
Y24=re.compile(r'(?<!\d)2024(?!\d)')
SENSITIVE=re.compile(r'password|secret|private[_-]?key|credential|wallet|\.env|token',re.I)

def digest(b):return hashlib.sha256(b).hexdigest().upper()
def jload(b):return json.loads(b.decode('utf-8-sig'))
def rows(b):return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig',errors='strict'))))
def unique_rows(items, keys):return len({tuple(x[k] for k in keys) for x in items})==len(items)
def safe_named(n):
 s=n.replace('\\','/')
 return (not Y24.search(s)) and (not SENSITIVE.search(s)) and '..' not in s.split('/') and not s.startswith('/') and ':' not in s

def guarded_member(z, member):
 if not safe_named(member):return None
 try:i=z.getinfo(member)
 except KeyError:return None
 if i.is_dir() or i.file_size>MAX_MEMBER_SIZE:return None
 b=z.read(i)
 if len(b)!=i.file_size:return None
 return b

def find_members(z,names):
 result={}
 for item in z.infolist():
  if not safe_named(item.filename):continue
  n=item.filename.replace('\\','/').split('/')[-1]
  if n in names and n not in result and item.file_size<=MAX_MEMBER_SIZE:
   result[n]=item.filename
 return result

def target_inventory(downloads,repo):
 wanted=re.compile(r'(?i)(?:^UPLOAD_THIS_AKAH_R53.*(?:RESULTS|RECOVERED).*\.zip$|^UPLOAD_THIS_AKAH_R50.*RESULTS\.zip$|^UPLOAD_THIS_AKAH_RD33.*\.zip$|^AKAH_R53.*RESULTS.*\.zip$)')
 paths=[]; count=0; truncated=False
 # Do not walk repository; only selected project-generated archives in Downloads.
 for base,dirs,files in os.walk(downloads,topdown=True,followlinks=False):
  cur=Path(base)
  depth=len(cur.relative_to(downloads).parts)
  dirs[:]=[d for d in sorted(dirs) if depth<4 and not Y24.search(d) and not d.startswith('.') and not d.lower() in {'node_modules','venv','.venv','assets','media','cache','temp','tmp','sources','images','photos','videos','screenshots'}]
  count+=len(dirs)+len(files)
  for f in files:
   if wanted.match(f) and not Y24.search(str(cur/f)):
    p=cur/f
    try: sz=p.stat().st_size
    except OSError:continue
    if sz<=MAX_ZIP_SIZE:paths.append(p)
  if count>35000: truncated=True;break
 return sorted(set(paths),key=lambda p:('R53R1' not in p.name.upper(),len(p.parts),str(p).lower())), {'entries_examined':count,'inventory_truncated':truncated,'archive_candidate_count':len(paths)}

def extract_zip_results(path,allowed, evidence, inventory):
 entry={'name':path.name,'path':str(path),'size_bytes':path.stat().st_size,'sha256':None,'status':'UNKNOWN','files':[]}
 if path.stat().st_size>MAX_ZIP_SIZE:entry['status']='SKIPPED_OVERSIZED';return entry
 try:
  with zipfile.ZipFile(path,'r') as z:
   targets=find_members(z,allowed)
   entry['members_total']=len(z.infolist());entry['matched_members']=list(targets)
   for key,orig in targets.items():
    data=guarded_member(z,orig)
    if data is None:continue
    label='results/'+re.sub(r'[^A-Za-z0-9_.-]+','_',path.stem)[:90]+'/'+key
    if label in evidence:continue
    if sum(map(len,evidence.values()))+len(data)>MAX_EXPORT_BYTES:entry['status']='PARTIAL_SIZE_LIMIT';break
    evidence[label]=data
    entry['files'].append({'name':key,'source_member':orig,'sha256':digest(data),'rows':len(rows(data)) if key.endswith('.csv') else None,'evidence_path':label})
   entry['status']='EXTRACTED' if entry['status']=='UNKNOWN' else entry['status']
 except (OSError,ValueError,zipfile.BadZipFile,RuntimeError,UnicodeError) as e:entry['status']='ERROR_'+type(e).__name__
 return entry

def try_rd33(repo,evidence):
 target_rel=[Path('data/research/rd33_p1_runtime'),Path('.akah_bot/transition_p38_export_v1/historical_source/data/research/rd33_p1_runtime'),Path('governance/rd33_p1'),Path('reports/rd33_p1')]
 attempts=[];found=[]
 for rel in target_rel:
  p=repo/rel
  attempts.append({'path':str(p),'exists':p.is_dir()})
  if not p.is_dir():continue
  for name in RD33_FILES:
   f=p/name
   if not f.is_file() or not safe_named(str(rel/name)) or f.stat().st_size>MAX_MEMBER_SIZE:continue
   data=f.read_bytes(); label='rd33_source/'+str(rel).replace('/','_').replace('\\','_')+'/'+name
   evidence[label]=data;found.append({'path':str(f),'sha256':digest(data),'bytes':len(data),'rows':len(rows(data)) if name.endswith('.csv') else None,'evidence_path':label})
 return {'directories_checked':attempts,'files_found':found,'rd33_trade_rows_read':0}

def tests():
 fake=[{'group':str(i),'year':'2023','gate':'a','fee_total':'0.005','policy':'p'} for i in range(12)]
 assert unique_rows(fake,['group','year','gate','fee_total','policy'])
 assert not unique_rows(fake+fake[:1],['group','year','gate','fee_total','policy'])
 assert not safe_named('data/2024/BTC-USDT.csv')
 assert not safe_named('reports/funds_private_key.txt')
 assert safe_named('R53_48_PORTFOLIO_YEAR_RESULTS.csv')
 assert len(rows(b'a,b\n1,2\n3,4\n'))==2
 assert jload(b'\xef\xbb\xbf{"test":true}')['test']
 with io.BytesIO() as buff:
  with zipfile.ZipFile(buff,'w') as z:
   z.writestr('folder/R53_REPLAY_AUDIT.json','{}')
   z.writestr('2024_market.csv','secret')
  buff.seek(0)
  with zipfile.ZipFile(buff) as z:
   ff=find_members(z,R53_RESULT_FILES)
   assert list(ff)==['R53_REPLAY_AUDIT.json']
 return 8

def run(args):
 t=tests()
 snap=Path(args.snapshot); repo=Path(args.repo);downloads=Path(args.downloads)
 if not snap.is_file():raise RuntimeError('MISSING_PINNED_P0R1_SOURCE_ARCHIVE')
 if not repo.is_dir():raise RuntimeError('REPO_NOT_FOUND')
 if not downloads.is_dir():raise RuntimeError('DOWNLOADS_NOT_FOUND')
 if digest(snap.read_bytes())!=PIN_P0R1:raise RuntimeError('PINNED_R54_P0R1_ZIP_SHA256_MISMATCH')
 report={'version':VER,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':digest(snap.read_bytes()),'git':{},'selftests_passed':t,'market_rows_read':0,'trade_rows_read':0,'year_2024_market_rows_read':0,'repo_mutations':0,'live_orders':0,'backtests':0,'economic_certification':'NOT_CERTIFIED','PIT_certification':'NOT_CERTIFIED'}
 evidence={}
 # The canonical 12-cell R50 reference is present and signed inside the P0R1 evidence packet.
 with zipfile.ZipFile(snap,'r') as z:
  b=guarded_member(z,P0R1_R50); manifest=guarded_member(z,P0R1_R53_MANIFEST)
  if b is None or manifest is None:raise RuntimeError('MISSING_R50_FROZEN_BASELINE_OR_SIGNATURE')
  m=jload(manifest)
  cells=rows(b)
  valid=digest(b)==PIN_R50==m.get('baseline_r50_existing_file') and len(cells)==12 and unique_rows(cells,['group','year','gate','fee_total','policy'])
  report['r50']={'frozen_12_member_sha256':digest(b),'signed_manifest_sha256':m.get('baseline_r50_existing_file'),'signature_match':valid,'cells':len(cells),'group_counts':{},'research_reference_only':True}
  if not valid:raise RuntimeError('R50_FROZEN_12_SIGNATURE_OR_CARDINALITY_MISMATCH')
  for row in cells:report['r50']['group_counts'][row['group']]=report['r50']['group_counts'].get(row['group'],0)+1
  evidence['references/R50_12_FROZEN_ECONOMIC_CELLS.csv']=b
  evidence['references/R53_SHA256_MANIFEST.json']=manifest
  for name in ['evidence/archives/AKAH_R53_ARCHITECTURE_TOURNAMENT_ONEPASS.zip/R53_SCOPE_AND_GATES.json','evidence/archives/AKAH_R53_ARCHITECTURE_TOURNAMENT_ONEPASS.zip/baseline/R44R1_HISTORICAL_UNIVERSE_AUTHORITY_GATE.json','evidence/archives/AKAH_R53_ARCHITECTURE_TOURNAMENT_ONEPASS.zip/evidence/R42_2023_8759_CANONICAL_TAPE_WITNESS.json']:
   bb=guarded_member(z,name)
   if bb is not None:
    evidence['references/'+name.split('/')[-1]]=bb
  tape=jload(evidence['references/R42_2023_8759_CANONICAL_TAPE_WITNESS.json'])
  report['tape']={'hourly_sha_witness_count':len(tape),'rd53_cohort_count':196,'universe_PIT_certified':False,'raw_tape_SHA_reverified_now':False}
  if len(tape)!=20:raise RuntimeError('EXPECTED_20_PAIR_R42_SHA_WITNESS_CHANGED')
  # rd33 scripts metadata unchanged; original published output not necessarily present.
  rd33src=[q for q in z.namelist() if q.endswith(('run_rd33_temporal_mb_architecture.py','rd33_temporal_mb_architecture.py','rd33_temporal_mb_replay.py')) and q.startswith('evidence/repo/')]
  report['rd33_sources']=[{'name':x,'sha256':digest(z.read(x))} for x in rd33src]
  if len(rd33src)!=3:raise RuntimeError('RD33_SOURCE_ARCHIVE_MISSING')
  evidence['references/R54_P0R1_GATE.json']=z.read('R54_P0R1_GATE.json')
  if len(evidence)>20:raise RuntimeError('UNEXPECTED_EVIDENCE')
 # Search only the Download tree, bounded and all aliases of R53 results, and strict RD33 source dirs.
 results, scan=target_inventory(downloads,repo)
 report['download_inventory']=scan
 report['download_matches']=[]
 for p in results[:30]:
  report['download_matches'].append(extract_zip_results(p,R53_RESULT_FILES+RD33_FILES,evidence,scan))
 report['rd33_runtime']=try_rd33(repo,evidence)
 # Analyze claimed runtime results if present, never infer success from a filename.
 def data_by_basename(name):
  return [(k,v) for k,v in evidence.items() if k.split('/')[-1]==name and k.startswith('results/')]
 portfolios=data_by_basename('R53_48_PORTFOLIO_YEAR_RESULTS.csv')
 pairs=data_by_basename('R53_36_PAIRED_ARCHITECTURE_COMPARISONS.csv')
 parity=data_by_basename('R53_12_EXACT_R50_REFERENCE_PARITY.csv')
 recovery=data_by_basename('R53R1_RECOVERY_AUDIT.json')
 report['r53_results']={'portfolio_tables':len(portfolios),'paired_tables':len(pairs),'parity_tables':len(parity),'recovery_audits':len(recovery),'portfolio_counts':[len(rows(v)) for _,v in portfolios],'paired_counts':[len(rows(v)) for _,v in pairs],'parity_counts':[len(rows(v)) for _,v in parity]}
 report['r53_results']['cardinalities_48_36_12_present']=any(len(rows(v))==48 for _,v in portfolios) and any(len(rows(v))==36 for _,v in pairs) and any(len(rows(v))==12 for _,v in parity)
 report['r53_results']['audits_textual_outlines']=[{'evidence_path':k,'top_level_keys':list(jload(v).keys()),'audit_status':str(jload(v).get('status',jload(v).get('result',jload(v).get('decision','UNSPECIFIED'))))} for k,v in recovery]
 rd33path=[x['path'] for x in report['rd33_runtime']['files_found']]
 rd33_complete=any(x.endswith('portfolio-run-metrics.csv') for x in rd33path) and any(x.endswith('rd33-p1-temporal-mb-architecture-report-v1.json') for x in rd33path)
 report['decision']={
    'r50_12_reference_fingerprint':'CONFIRMED_ARCHIVE_INTERNAL_NOT_REPLAY',
    'r53_48_36_12_results':'CANDIDATE_TABLES_PRESENT_PENDING_FULL_CAUSAL_REPLAY_CHECK' if report['r53_results']['cardinalities_48_36_12_present'] else 'NOT_PRESENT_OR_INCOMPLETE',
    'rd33_economic_result':'SUMMARY_FOUND_AWAITING_CERTIFICATION' if rd33_complete else 'NOT_RECOVERED',
    'pit_listing_membership':'MISSING_NOT_CERTIFIED',
    '196_cohort':'R27_FROZEN_COVERAGE_ONLY_NOT_HISTORICAL_PIT',
    'event_census':'CONDITIONALLY_ALLOWED_AS_DESCRIPTIVE_ONLY_AFTER_TAPE_AND_TIME_CHECKS',
    'new_strategy_economic_test':'BLOCKED',
    'read_only':True,'next':'Find RD33 source output and R53R1 recovery proof; obtain independently valid listing/coverage authority before economic claims'
 }
 # No files from P0R2 worker may mutate the repository. Results written only to Downloads.
 out=downloads/('UPLOAD_THIS_AKAH_R54_P0R2_RESULT_RECONCILIATION_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
 outline=[f'# {VER}',f'- Frozen R50 12-cell signature: PASS ({PIN_R50})',f'- R53 recovered table cardinalities 48/36/12: {report["r53_results"]["cardinalities_48_36_12_present"]}',f'- RD33 economic summary: {report["decision"]["rd33_economic_result"]}',f'- Year 2022–2023 20-pair tape witness present, but 196-pair tape raw re-verification NOT performed.',f'- PIT listing/delisting authority: NOT CERTIFIED. No 2024 data, no market/trade data, no production modifications, no backtests.',f'- Candidate ZIP paths checked: {scan["archive_candidate_count"]}; bounded directory entries: {scan["entries_examined"]}.','', '## Missing inputs', '- Exact original R53R1 recovery results ZIP, if it was not found in Downloads.', '- RD33 P1 output report and portfolio-run-metrics CSV.', '- Independently verified 2022–2023 historical listing and eligible-universe timeline.', '- Strict 1X/2X fill cost/slippage contract and tape certificates for selected research cohort.','']
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
  z.writestr('R54_P0R2_REPORT.json',json.dumps(report,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
  z.writestr('README_RESULTS.md','\n'.join(outline))
  z.writestr('R54_P0R2_EVIDENCE_MANIFEST.json',json.dumps([{'path':name,'sha256':digest(b),'bytes':len(b)} for name,b in sorted(evidence.items())],indent=2)+'\n')
  for name,b in sorted(evidence.items()):z.writestr('evidence/'+name,b)
 print('R54_P0R2_SELFTESTS_PASS='+str(t));print('R54_P0R2_FROZEN_R50_12=SHA256_PASS');print('R54_P0R2_R53_TABLE_CARDINALITIES='+str(report['r53_results']['cardinalities_48_36_12_present']).upper());print('R54_P0R2_RD33='+report['decision']['rd33_economic_result']);print('R54_P0R2_PIT_CERTIFIED=NO');print('R54_P0R2_2024_MARKET_ROWS_READ=0');print('R54_P0R2_REPO_MUTATION=NO');print('R54_P0R2_UPLOAD='+str(out))
 return 0

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--snapshot');ap.add_argument('--repo');ap.add_argument('--downloads');ap.add_argument('--selftest-only',action='store_true');a=ap.parse_args()
 if a.selftest_only:print('R54_P0R2_SELFTEST_PASS='+str(tests()));return 0
 if not all([a.snapshot,a.repo,a.downloads]):ap.error('missing args')
 try:return run(a)
 except Exception as e:print('R54_P0R2_FAIL_CLOSED='+type(e).__name__+':'+str(e),file=sys.stderr);return 3
if __name__=='__main__':sys.exit(main())
