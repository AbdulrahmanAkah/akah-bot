"""Small end-to-end synthetic proof: pinned offsets, 92-byte rows, P0R5 counts, 2024 tail ignored."""
import sys,tempfile,struct,datetime as dt,hashlib,pathlib,collections
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import r54_p0r6_mega_portfolio as m
import r54_p0r5_reclaim_census as r5
REC=struct.Struct('<11dI')
assert REC.size==92
class Mod:
    REC=REC
    START=dt.datetime(2022,1,1,tzinfo=dt.timezone.utc)
    H=dt.timedelta(hours=1)
    @staticmethod
    def validate_row(data,index):return REC.unpack(data)

def proof():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td);repo=root/'repo';down=root/'downloads';work=root/'work';work.mkdir()
        pairs_dir=repo/'.akah_bot'/'v2r2_common_causal_tape_v1'/'pairs';pairs_dir.mkdir(parents=True)
        refs={};pinned={};ct=collections.Counter()
        for k,pair in enumerate(('BTC-USDT','ETH-USDT')):
            lows=[];closes=[];h22=hashlib.sha256();h23=hashlib.sha256()
            with (pairs_dir/(pair+'.1H.bars.bin')).open('wb') as f:
                f.write(b'P'*92*3)
                for t in range(m.TOTAL):
                    lo=99 if t%107==0 else 100
                    cl=101
                    row=REC.pack(101,103,lo,cl,200000,0,0,0,0,0,0,0)
                    f.write(row)
                    (h22 if t<m.YEAREND else h23).update(row)
                    lows.append(lo);closes.append(cl)
                f.write(b'2024_LEAK_TRIGGER'*100)  # never read
            refs[pair]={'2022_sha256':h22.hexdigest(),'2023_8759_sha256':h23.hexdigest()}
            pinned[pair]={'pair':pair,'r27_offset':3}
            for idx,flags in r5.detect_events(zip(lows,closes)):
                y='2022' if idx<m.YEAREND else '2023'
                ct[y+'_unique']+=1
                for h in flags:ct[y+'_'+str(h)]+=1
        old_refs,old_counts,oldmod,oldplan=r5.REF_WITNESS,m.EXPECTED_COUNTS,r5.get_vendor,r5.load_plan
        try:
            r5.REF_WITNESS=refs;m.EXPECTED_COUNTS=dict(ct)
            r5.get_vendor=lambda d,w:(Mod,{'r43_source_sha256':'TEST_SOURCE','record_size':92})
            r5.load_plan=lambda d:({'eligible':{'BTC-USDT':3,'ETH-USDT':3}},root/'synthetic_plan.json')
            tape,report=m.read_tapes(repo,down,work,{'proofs':list(pinned.values())})
            assert report['read_market_rows']==2*m.TOTAL
            assert report['2024_rows_read']==0
            assert report['event_counts']==dict(ct)
            assert len(tape)==2
            r=m.sim(tape,m.POLICIES[0],m.SCENARIOS[1])
            assert r['final_equity']>0
            print('INTEGRATED_SOURCE_GATE_PASS_PINNED_SHA_OFFSET_2024_TAIL_IGNORED')
        finally:
            r5.REF_WITNESS=old_refs;m.EXPECTED_COUNTS=old_counts
            r5.get_vendor=oldmod;r5.load_plan=oldplan
if __name__=='__main__':proof()
