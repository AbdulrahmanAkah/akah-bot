from __future__ import annotations
import tempfile,pathlib,sys,datetime as dt,math
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import r54_p0r6_mega_portfolio as m

def fake_tape(pairs=3):
    data={}
    for n in range(pairs):
        N=m.TOTAL
        op=[100.0+2*n+i*0.001 + 2*math.sin(i/220.) for i in range(N)]
        cl=[v*(1+0.0004*math.sin(i/4.)) for i,v in enumerate(op)]
        lo=[min(a,b)*.995 for a,b in zip(op,cl)]
        high=[max(a,b)*1.005 for a,b in zip(op,cl)]
        ev=[0]*N
        for i in range(780+n*7,N-720,60): ev[i]=1 if i%3 else 3
        for i in range(880+n*7,N-720,180):ev[i]|=2
        for i in range(980+n*7,N-720,360):ev[i]|=4
        q=[100000000.]*N
        prefix=[0.];closeprefix=[0.];positive=[0]
        for v,c in zip(q,cl):
            prefix.append(prefix[-1]+v)
            closeprefix.append(closeprefix[-1]+c)
            positive.append(positive[-1]+int(v>0))
        data[('BTC-USDT','ETH-USDT','SYNTH2-USDT')[n]]={'open':op,'high':high,'low':lo,'close':cl,'events':ev,'quote_volume':q,
            'vol_prefix':prefix,'positive_vol_prefix':positive,'close_prefix':closeprefix}
    return data

def test_all():
    assert m.selftest()==22
    b=fake_tape(3)
    for pol in m.POLICIES:
        res=m.sim(b,pol,m.SCENARIOS[1],diagnostics=True)
        assert abs(res['cash_end']-res['final_equity'])<0.01
        assert abs(res['2022_pnl']+res['2023_pnl']-res['total_pnl'])<0.01
        assert res['positive_weeks']+res['negative_weeks']+res['flat_weeks'] >= 104
        assert all(t['entry_i']>=t['entry_event_bar']+1+pol.shift for t in res['_trades'])
        assert all(t['exit_i']>t['entry_i'] for t in res['_trades'])
        assert all(t['exit_i']<=m.CLOSE_OUT_BAR for t in res['_trades'])
        print('SIM_PASS',pol.name, 'trades',res['trades'],'annual',res['2022_pnl'],res['2023_pnl'],'DD',res['max_drawdown_pct'])
    with tempfile.TemporaryDirectory() as td:
        meta=m.simulate_all(b,pathlib.Path(td))
        assert meta['total_backtests']>=24
        assert pathlib.Path(td,'R54_MEGA_ALL_POLICY_SCENARIOS.csv').exists()
        assert all(not z['deployment_permitted'] for z in meta['research_gates'])
    # Price change AFTER a prefix cannot affect trades fully completed within that prefix.
    x=m.sim(b,m.POLICIES[0],m.SCENARIOS[1],diagnostics=True)
    prefix_time=9000
    assert any(t['exit_i']<prefix_time for t in x['_trades'])
    altered=fake_tape(3)
    altered['BTC-USDT']['open'][prefix_time+1:]=[q*0.3 for q in altered['BTC-USDT']['open'][prefix_time+1:]]
    altered['BTC-USDT']['close'][prefix_time+1:]=[q*0.3 for q in altered['BTC-USDT']['close'][prefix_time+1:]]
    altered['BTC-USDT']['close_prefix']=[0.]
    for q in altered['BTC-USDT']['close']:altered['BTC-USDT']['close_prefix'].append(altered['BTC-USDT']['close_prefix'][-1]+q)
    y=m.sim(altered,m.POLICIES[0],m.SCENARIOS[1],diagnostics=True)
    assert [(t['pair'],t['entry_i'],t['exit_i'],t['net_pnl']) for t in x['_trades'] if t['exit_i']<prefix_time]==[(t['pair'],t['entry_i'],t['exit_i'],t['net_pnl']) for t in y['_trades'] if t['exit_i']<prefix_time]
    print('PREFIX_CAUSAL_INVARIANCE_PASS')
if __name__=='__main__':test_all()
