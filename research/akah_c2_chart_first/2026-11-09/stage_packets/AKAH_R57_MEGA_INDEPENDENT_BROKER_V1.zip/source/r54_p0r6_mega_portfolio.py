#!/usr/bin/env python3
"""AKAH R54 Mega: 20-pair historical research & dry-run simulator, 2022–2023 only.

This is deliberately NOT a live trader; 20-pair cohort not PIT exchange-certified;
fees, slippage and liquidity are model assumptions (not venue-calibrated).
All signals are from closed bars; executions are at subsequent candle opens.
"""
from __future__ import annotations
import argparse,csv,datetime as dt,hashlib,json,math,pathlib,statistics,sys,traceback,zipfile
from dataclasses import dataclass
from collections import Counter,defaultdict
import r54_p0r5_reclaim_census as r5

VERSION='AKAH_R54_MEGA_P0R6_V1'
YEAREND=8760
TOTAL=r5.TOTAL
START=dt.datetime(2022,1,1,tzinfo=dt.timezone.utc)
CLOSE_OUT_BAR=TOTAL-1
EXPECTED_COUNTS={'2022_unique':7948,'2023_unique':5882,'2022_24':7691,'2023_24':5634,
 '2022_168':2657,'2023_168':1264,'2022_720':1131,'2023_720':508}
RESEARCH_ONLY='RETROSPECTIVE_20PAIR_NOT_PIT_CERTIFIED'

@dataclass(frozen=True)
class Policy:
    name:str
    horizon:int
    hold:int
    stop:float
    mode:str='fixed'
    shift:int=0

POLICIES=(
 Policy('D24_TACTICAL',24,48,0.08),
 Policy('W168_SWING',168,168,0.12),
 Policy('M720_REVERSAL',720,336,0.18),
 Policy('CONFLUENCE_24_168',168,240,0.12,'confluence'),
 Policy('RECLAIM_TO_TREND',24,72,0.08,'promote'),
 Policy('D24_DELAY_48H_CONTROL',24,48,0.08,'fixed',48),
)

SCENARIOS=(
 {'name':'MODEL_1X','fee_bps':10,'slip_bps':5,'latency_hours':1},
 {'name':'MODEL_2X','fee_bps':20,'slip_bps':10,'latency_hours':1},
 {'name':'MODEL_2X_DELAY3H','fee_bps':20,'slip_bps':10,'latency_hours':3},
 {'name':'MODEL_2X_EXTRA_SLIP','fee_bps':20,'slip_bps':20,'latency_hours':1},
)
CAP={'initial_cash':100000.0,'per_position_equity':0.20,'portfolio_equity_cap':0.60,
     'max_open_positions':3,'min_order_usdt':100.0,
     'max_fraction_prior_24h_quote_volume':0.001,
     'max_fraction_prior_1h_quote_volume':0.01,
     'cooldown_hours_after_exit':24}

class Gate(Exception): pass

def check(condition, message):
    if not condition: raise Gate(message)

def putjson(p,obj):
    p.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False,default=str)+'\n',encoding='utf-8')

def putcsv(p,rows,columns):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore',lineterminator='\n')
        w.writeheader();w.writerows(rows)

def load_pin(local):
    d=json.loads(local.read_text(encoding='utf-8'))
    check(d.get('event_rows')==13830 and d.get('counts')==EXPECTED_COUNTS,'CENSUS_PIN_REPORT_MISMATCH')
    check(len(d['proofs'])==20 and d['2024_market_rows_read']==0,'PIN_REPORT_SCOPE_MISMATCH')
    return d


def causal_floor_events(low,close):
    out=[0]*len(low)
    for idx,flags in r5.detect_events(zip(low,close)):
        bit=0
        for h in flags:
            bit |= {24:1,168:2,720:4}[h]
        out[idx]=bit
    return out


def read_tapes(repo,downloads,work,pin):
    plan,plan_path=r5.load_plan(downloads)
    mod,vendor=r5.get_vendor(downloads,work)
    check(mod.REC.size==92,'R43_RECORD_SIZE_MISMATCH')
    check(set(r5.REF_WITNESS)==set(x['pair'] for x in pin['proofs']),'PIN_PAIR_LIST_MISMATCH')
    tape={}; proofs=[];counts=Counter()
    refs={x['pair']:x for x in pin['proofs']}
    for pair in sorted(r5.REF_WITNESS):
        offset=plan['eligible'].get(pair)
        check(isinstance(offset,int) and offset>=0,'FROZEN_R27_OFFSET_MISSING:'+pair)
        path=repo/'.akah_bot'/'v2r2_common_causal_tape_v1'/'pairs'/(pair+'.1H.bars.bin')
        check(path.is_file(),'TAPE_MISSING:'+pair)
        check(path.stat().st_size >= (offset+TOTAL)*mod.REC.size,'TAPE_SHORT:'+pair)
        arr={'open':[],'high':[],'low':[],'close':[],'quote_volume':[]}
        h22=hashlib.sha256();h23=hashlib.sha256()
        with path.open('rb') as f:
            f.seek(offset*mod.REC.size)
            for i in range(TOTAL):
                blob=f.read(mod.REC.size)
                check(len(blob)==mod.REC.size,'SHORT_READ:'+pair)
                v=mod.validate_row(blob,i)
                op,hi,lo,cl,vol=[float(v[j]) for j in range(5)]
                check(all(math.isfinite(x) for x in (op,hi,lo,cl,vol)),'NONFINITE_MARKET_ROW:'+pair)
                check(min(op,hi,lo,cl)>0 and lo<=min(op,cl) and hi>=max(op,cl) and hi>=lo and vol>=0,'BAD_BAR:'+pair)
                for k,x in (('open',op),('high',hi),('low',lo),('close',cl)):arr[k].append(x)
                arr['quote_volume'].append(vol*cl) # proxy; NOT certified exchange dollar-volume
                (h22 if i<YEAREND else h23).update(blob)
        w=r5.REF_WITNESS[pair]
        check(h22.hexdigest().upper()==w['2022_sha256'].upper(),'SHA_DRIFT_2022:'+pair)
        check(h23.hexdigest().upper()==w['2023_8759_sha256'].upper(),'SHA_DRIFT_2023:'+pair)
        check(refs[pair]['r27_offset']==offset,'OFFSET_DRIFT:'+pair)
        ev=causal_floor_events(arr['low'],arr['close'])
        for i,bit in enumerate(ev):
            if bit:
                year='2022' if i<YEAREND else '2023'
                counts[year+'_unique']+=1
                for h,b in ((24,1),(168,2),(720,4)):
                    if bit&b: counts[year+'_'+str(h)]+=1
        arr['events']=ev
        # Available using only prior completed bars, excluding current bar.
        prefix=[0.0];nonzero=[0]; close_prefix=[0.0]
        for volume,price in zip(arr['quote_volume'],arr['close']):
            prefix.append(prefix[-1]+volume);nonzero.append(nonzero[-1]+int(volume>0));close_prefix.append(close_prefix[-1]+price)
        arr['vol_prefix']=prefix;arr['positive_vol_prefix']=nonzero;arr['close_prefix']=close_prefix
        tape[pair]=arr
        proofs.append({'pair':pair,'2022_sha':h22.hexdigest().upper(),'2023_sha':h23.hexdigest().upper(),'offset':offset,'events':sum(bool(x) for x in ev)})
        print('PINNED='+pair+' EVENTS='+str(proofs[-1]['events']),flush=True)
    check(dict(counts)==EXPECTED_COUNTS,'RECALCULATED_CENSUS_NOT_EQUAL_FROZEN_P0R5')
    return tape,{'pairs':len(tape),'record_size':mod.REC.size,'r27_path':str(plan_path),'vendor':vendor,
                 'event_counts':dict(counts),'sources':proofs,'read_market_rows':len(tape)*TOTAL,
                 '2024_rows_read':0,'PIT_membership_certified':False}

def has_signal(bit,pol):
    if pol.mode=='confluence':return (bit&3)==3
    return bool(bit&{24:1,168:2,720:4}[pol.horizon])

def liquidity_max_usd(bars,t):
    if t<25:return 0.0
    # t is entry candle opening; [t-24,t) and t-1 are already completed.
    v24=bars['vol_prefix'][t]-bars['vol_prefix'][t-24]
    v1=bars['quote_volume'][t-1]
    enough=(bars['positive_vol_prefix'][t]-bars['positive_vol_prefix'][t-24])>=23
    return min(CAP['max_fraction_prior_24h_quote_volume']*v24,
               CAP['max_fraction_prior_1h_quote_volume']*v1) if enough and v1>0 else 0.0

def eligible_entry_score(bars,j):
    # Only source event-bar OHLCV; large candle recovery moves first, deterministic tie-break.
    return (bars['close'][j]/bars['low'][j]-1.0)

def sim(tape,policy,scenario,exclude=None,diagnostics=False):
    pairs=[p for p in sorted(tape) if p!=exclude]
    check(pairs,'NO_ASSETS')
    fee=scenario['fee_bps']/10000.0
    slip=scenario['slip_bps']/10000.0
    lag=scenario['latency_hours']+policy.shift
    cash=CAP['initial_cash'];pos={};last_exit={}; trades=[]; daily=[];weekly=[]
    max_equity=cash;max_dd=0;yearend_equity=None
    count=Counter();total_abs_exposure=0.;n_exposure_samples=0
    prev_annual_week=None
    for t in range(TOTAL):
        # Only bar t OPEN is executable; all decisions derive from <= t-1 CLOSE.
        if pos:
            for pair in sorted(list(pos)):
                entry=pos[pair];b=tape[pair];age=t-entry['i']
                prev_close=b['close'][t-1] if t>0 else b['open'][t]
                if t>entry['i']:
                    entry['peak']=max(entry['peak'],prev_close)
                if policy.mode=='promote' and not entry['promoted'] and age>=48 and t>168:
                    avg=(b['close_prefix'][t]-b['close_prefix'][t-168])/168.0
                    if prev_close>=entry['fill']*1.05 and prev_close>avg:
                        entry['promoted']=True
                        entry['hold']=336
                stop=entry['fill']*(1-policy.stop)
                if entry['promoted']:
                    stop=max(stop,entry['peak']*0.88)
                reason=None
                if t==CLOSE_OUT_BAR: reason='CONTRACT_LAST_KNOWN_OPEN'
                elif age>=entry['hold']: reason='MAX_HOLD'
                elif prev_close<=stop:reason='CLOSE_CONFIRMED_STOP_NEXT_OPEN'
                if reason:
                    proceeds=entry['qty']*b['open'][t]*(1-slip)*(1-fee)
                    pnl=proceeds-entry['cash_spent']
                    cash+=proceeds
                    trades.append({'policy':policy.name,'scenario':scenario['name'],'pair':pair,
                        'entry_i':entry['i'],'exit_i':t,
                        'entry_utc':(START+dt.timedelta(hours=entry['i'])).isoformat(),
                        'exit_utc':(START+dt.timedelta(hours=t)).isoformat(),
                        'entry_fill':entry['fill'],'exit_open':b['open'][t],
                        'entry_cash':round(entry['cash_spent'],4),'exit_cash':round(proceeds,4),
                        'net_pnl':round(pnl,4),'net_return_pct':round(100*pnl/entry['cash_spent'],5),
                        'holding_hours':age,'entry_event_bar':entry['signal_i'],
                        'promoted':entry['promoted'],'exit_reason':reason})
                    last_exit[pair]=t;del pos[pair];count['exits']+=1
        # Eligibility is at OPEN, using the prior completed event candle(s) only.
        # Limit new entries to leave at least one next-known-open for exits.
        if t < CLOSE_OUT_BAR and t>=lag and len(pos)<CAP['max_open_positions']:
            equity_open=cash+sum(item['qty']*tape[p]['open'][t] for p,item in pos.items())
            open_exposure=sum(item['qty']*tape[p]['open'][t] for p,item in pos.items())
            headroom=max(0.,CAP['portfolio_equity_cap']*equity_open-open_exposure)
            j=t-lag
            candidates=[]
            for p in pairs:
                if p in pos or t-last_exit.get(p,-10000)<CAP['cooldown_hours_after_exit']:continue
                b=tape[p]
                if not has_signal(b['events'][j],policy):continue
                max_liq=liquidity_max_usd(b,t)
                if max_liq<CAP['min_order_usdt']:
                    count['liquidity_rejected']+=1;continue
                candidates.append((-eligible_entry_score(b,j),p,max_liq,j))
            for _,p,liquid_cap,j in sorted(candidates):
                if len(pos)>=CAP['max_open_positions'] or headroom<CAP['min_order_usdt']:break
                amount=min(cash, CAP['per_position_equity']*equity_open,headroom,liquid_cap)
                if amount<CAP['min_order_usdt']:continue
                op=tape[p]['open'][t]
                fill=op*(1+slip)
                qty=amount/(fill*(1+fee))
                check(qty>0 and math.isfinite(qty),'NONPOSITIVE_QTY')
                cash-=amount;headroom-=amount
                pos[p]={'i':t,'signal_i':j,'fill':fill,'qty':qty,'cash_spent':amount,
                        'hold':policy.hold,'promoted':False,'peak':fill}
                count['entries']+=1
        # NAV includes liquidation friction on outstanding positions.
        nav=cash+sum(entry['qty']*tape[p]['close'][t]*(1-slip)*(1-fee) for p,entry in pos.items())
        check(math.isfinite(nav) and nav>0,'BANKRUPT_OR_NONFINITE_EQUITY')
        max_equity=max(nav,max_equity);max_dd=max(max_dd,1-nav/max_equity)
        if (t+1)%24==0 or t==TOTAL-1 or t==YEAREND-1:
            when=START+dt.timedelta(hours=t+1)
            daily.append({'bar_index':t,'asof_closed_utc':when.isoformat(),
                          'value_usdt':round(nav,6),'open_positions':len(pos)})
            total_abs_exposure+=sum(x['qty']*tape[p]['close'][t] for p,x in pos.items())/nav
            n_exposure_samples+=1
        if t==YEAREND-1:yearend_equity=nav
    check(not pos,'NONFLAT_AT_CONTRACT_END')
    check(yearend_equity is not None,'NO_YEAR_END_NAV')
    capital=CAP['initial_cash'];endval=cash
    # Weeks ending Sunday at 23:59 UTC; calculate from daily NAV. Separate years.
    week_last={}
    for day in daily:
        timestamp=dt.datetime.fromisoformat(day['asof_closed_utc'])
        # bar last belongs to its open date, important at year boundary
        effective=START+dt.timedelta(hours=day['bar_index'])
        year_week=effective.isocalendar()[:2]
        week_last[year_week]=(effective,day['value_usdt'])
    prev=capital
    for (year,week), (at,value) in sorted(week_last.items(),key=lambda k:k[1][0]):
        # ISO calendar can include prior year, use actual close timestamp label
        weekly.append({'week_year':year,'iso_week':week,'ending_open_utc':at.isoformat(),
                       'net_change_usdt':round(value-prev,4),
                       'ending_equity_usdt':round(value,4)})
        prev=value
    win=sum(t['net_pnl']>0 for t in trades)
    losses=-sum(t['net_pnl'] for t in trades if t['net_pnl']<0)
    gains=sum(t['net_pnl'] for t in trades if t['net_pnl']>0)
    by_pair=defaultdict(float)
    for t in trades:by_pair[t['pair']]+=t['net_pnl']
    positive_by_pair=sorted((v,p) for p,v in by_pair.items() if v>0)
    return {
        'policy':policy.name,'scenario':scenario['name'],'excluded_pair':exclude,
        'initial_cash':round(capital,3),'final_equity':round(endval,3),
        'total_pnl':round(endval-capital,3),'return_pct':round(100*(endval/capital-1),5),
        '2022_pnl':round(yearend_equity-capital,3),'2023_pnl':round(endval-yearend_equity,3),
        'max_drawdown_pct':round(max_dd*100,5), 'trades':len(trades),'winning_trades':win,
        'win_rate_pct':round(win/max(1,len(trades))*100,3),
        'profit_factor':round(gains/losses,4) if losses else None,
        'positive_weeks':sum(v['net_change_usdt']>0.001 for v in weekly),
        'negative_weeks':sum(v['net_change_usdt']<-.001 for v in weekly),
        'flat_weeks':sum(abs(v['net_change_usdt'])<=.001 for v in weekly),
        'top_profitable_pair':positive_by_pair[-1][1] if positive_by_pair else '',
        'top_profitable_pair_pnl':round(positive_by_pair[-1][0],3) if positive_by_pair else 0,
        'top_3_profitable_pair_pnl':round(sum(v for v,_ in positive_by_pair[-3:]),3),
        'avg_daily_exposure_pct':round(100*total_abs_exposure/max(1,n_exposure_samples),3),
        'liquidity_rejections':count['liquidity_rejected'],
        'cash_end':round(cash,3),
        '_trades':trades if diagnostics else [],'_daily':daily if diagnostics else [],'_weekly':weekly if diagnostics else [],
        '_pair_pnl':{p:round(v,4) for p,v in sorted(by_pair.items())} if diagnostics else {}
    }

def strip_private(x):return {k:v for k,v in x.items() if not k.startswith('_')}

def bench_buy_hold(tape,pair,scenario):
    b=tape[pair];fee=scenario['fee_bps']/10000.;slip=scenario['slip_bps']/10000.
    qty=CAP['initial_cash']/(b['open'][0]*(1+slip)*(1+fee))
    navend=qty*b['open'][CLOSE_OUT_BAR]*(1-slip)*(1-fee)
    nav22=qty*b['close'][YEAREND-1]*(1-slip)*(1-fee)
    return {'name':'B&H_'+pair,'final_equity':round(navend,3),'2022_pnl':round(nav22-100000,3),
            '2023_pnl':round(navend-nav22,3),'research_benchmark_only':True}

def verdict(m):
    return {'positive_both_years':m['2022_pnl']>0 and m['2023_pnl']>0,
            'positive_2x_total':m['total_pnl']>0,
            'max_drawdown_25pct_bound':m['max_drawdown_pct']<=25,
            'minimum_52_trades_2yrs':m['trades']>=52,
            'max_pair_dominance_less_80pct': (m['top_profitable_pair_pnl']<0.8*m['total_pnl']) if m['total_pnl']>0 else False}

def simulate_all(tape,out):
    allrows=[]; base={}
    for pol in POLICIES:
        for sc in SCENARIOS:
            result=sim(tape,pol,sc,diagnostics=sc['name']=='MODEL_2X')
            print('ECON_POLICY='+pol.name+' SCENARIO='+sc['name']+' FINAL='+str(result['final_equity'])+' 2022='+str(result['2022_pnl'])+' 2023='+str(result['2023_pnl']),flush=True)
            allrows.append(strip_private(result))
            if sc['name']=='MODEL_2X':
                base[pol.name]=result
                tag=pol.name
                putcsv(out/(tag+'_TRADES_2X.csv'),result['_trades'],
                      ['policy','scenario','pair','entry_i','exit_i','entry_utc','exit_utc','entry_fill','exit_open','entry_cash','exit_cash','net_pnl','net_return_pct','holding_hours','entry_event_bar','promoted','exit_reason'])
                putcsv(out/(tag+'_WEEKLY_2X.csv'),result['_weekly'],
                       ['week_year','iso_week','ending_open_utc','net_change_usdt','ending_equity_usdt'])
                putcsv(out/(tag+'_DAILY_2X.csv'),result['_daily'],
                       ['bar_index','asof_closed_utc','value_usdt','open_positions'])
    stress=[]
    for pol in POLICIES:
        x=base[pol.name];target=x['top_profitable_pair']
        if not target:continue
        z=sim(tape,pol,SCENARIOS[1],exclude=target)
        stress.append({'policy':pol.name,'excluded_pair':target,'final_equity':z['final_equity'],
                       '2022_pnl':z['2022_pnl'],'2023_pnl':z['2023_pnl'],'total_pnl':z['total_pnl'],
                       'max_drawdown_pct':z['max_drawdown_pct'],'trades':z['trades']})
    putcsv(out/'R54_MEGA_ALL_POLICY_SCENARIOS.csv',allrows,list(allrows[0]))
    putcsv(out/'R54_MEGA_TOP_PAIR_EXCLUSION_2X.csv',stress,
          ['policy','excluded_pair','final_equity','2022_pnl','2023_pnl','total_pnl','max_drawdown_pct','trades'])
    bench=[bench_buy_hold(tape,p,SCENARIOS[1]) for p in ('BTC-USDT','ETH-USDT')]
    ratings=[]
    for pol in POLICIES:
        row=base[pol.name];g=verdict(row)
        stressrow=next((z for z in stress if z['policy']==pol.name),None)
        oneok=bool(stressrow and stressrow['2022_pnl']>0 and stressrow['2023_pnl']>0)
        ratings.append({'policy':pol.name,'predefined_gates':g,'leave_top_pair_out_both_years_positive':oneok,
                        'research_gate_all':all(g.values()) and oneok,
                        'deployment_permitted':False,
                        'reason':'20-pair retrospective cohort not venue PIT certified; costs model-dependent; 2022–2023 repeatedly exposed'})
    # No automatic best strategy chosen from repeatedly used 2022-2023.
    return {'policies':len(POLICIES),'scenarios':len(SCENARIOS),'total_backtests':len(allrows)+len(stress),
            'results_model_2x':[strip_private(base[p.name]) for p in POLICIES],
            'benchmarks_2x':bench,'top_pair_exclusions':stress,'research_gates':ratings,
            'selected_for_live':None,'selected_for_paper_deployment':None,
            'model_cost_warning':'Assumed 1X fee 10bps + slip 5bps each side; 2X fee20bps + slip10bps; NOT canonical RD33/R50 execution model.'}

def selftest():
    check(r5.verify_detector()==13,'R5_CAUSAL_SELFTEST_FAILURE')
    p=next(q for q in POLICIES if q.name=='D24_TACTICAL')
    check(has_signal(1,p) and not has_signal(2,p),'MASK_CLASSIFICATION')
    check(has_signal(3,POLICIES[3]) and not has_signal(2,POLICIES[3]),'CONFLUENCE_MASK')
    b={'vol_prefix':[0.,100.,300.,600.,1000.], 'positive_vol_prefix':[0,1,2,3,4],
       'quote_volume':[100,200,300,400]}
    check(liquidity_max_usd(b,3)==0,'PAST_24H_REQUIREMENT')
    # No close-bar signal may fill on itself.
    check(SCENARIOS[0]['latency_hours']>=1,'SAME_CANDLE_FILL')
    check(TOTAL==17519 and CLOSE_OUT_BAR==17518,'2023_HARD_BOUNDARY')
    check(START+dt.timedelta(hours=CLOSE_OUT_BAR)==dt.datetime(2023,12,31,22,tzinfo=dt.timezone.utc),'LAST_OPEN_BOUNDARY')
    check(all(sc['fee_bps']>=0 and sc['slip_bps']>=0 for sc in SCENARIOS),'NONNEGATIVE_COSTS')
    check(all(0<pol.stop<1 and pol.hold<=720 for pol in POLICIES),'POLICY_PROTOCOL_BOUNDS')
    check(all(pol.shift>=0 for pol in POLICIES),'INVALID_SHIFT')
    return 13+9

def main(args):
    out=args.out;out.mkdir(parents=True,exist_ok=True)
    meta={'version':VERSION,'status':'RUNNING','start_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
      'years':[2022,2023],'2024_market_rows_read':0,'live_orders':0,'production_mutations':0,
      'historical_PIT_membership_certified':False,'execution_costs_calibrated':False,
      'selection_is_exploratory':True,'cohort':RESEARCH_ONLY}
    try:
        meta['selftest_count']=selftest()
        pin=load_pin(args.pin)
        tape,authority=read_tapes(args.repo,args.downloads,args.work,pin)
        meta['authority']=authority
        meta['economic']=simulate_all(tape,out)
        meta['status']='PASS_MEGA_EXPLORATORY_ECONOMIC_REPLAY_NOT_CERTIFIED'
        # No leakage by reading 2024: each tape read exactly 17,519 complete bars.
        write_readme(out,meta)
    except Exception as e:
        meta['status']='BLOCKED_MEGA_SOURCE_OR_ECONOMIC'
        meta['blocker']=type(e).__name__+': '+str(e)
        meta['traceback_tail']=traceback.format_exc()[-3500:]
    meta['end_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
    putjson(out/'R54_MEGA_REPORT.json',meta)
    print('R54_MEGA_STATUS='+meta['status'],flush=True)
    if 'blocker'in meta: print('R54_MEGA_BLOCKER='+meta['blocker'],flush=True)
    return meta['status'].startswith('PASS')

def write_readme(out,report):
    rec=report['economic'];rows=rec['results_model_2x']
    lines=['# AKAH R54 — One-pass exploratory report','',
       'NO STRATEGY APPROVED FOR LIVE OR PAPER DEPLOYMENT. Retrospective 20-asset cohort is not PIT certified.',
       'Costs and liquidity are models; no historical exchange spread/depth or order rules certified.','',
       '## 2X modeled economics, $100k initial, continuous 2022–2023','',
       '|Policy|Final equity|2022 PnL|2023 PnL|Max DD|Trades|Weeks +/-/0|','|---|---:|---:|---:|---:|---:|---|']
    for x in rows:
       lines.append(f"|{x['policy']}|${x['final_equity']:,.0f}|${x['2022_pnl']:,.0f}|${x['2023_pnl']:,.0f}|{x['max_drawdown_pct']:.2f}%|{x['trades']}|{x['positive_weeks']}/{x['negative_weeks']}/{x['flat_weeks']}|")
    lines+=['','Reference RD33/R50 values are NOT directly comparable: original cohort and costs differ.',
      'All signals are computed from completed 1H bars and earliest fills occur at future 1H opens.',
      '2024 is SEALED; never route test signal to real orders.',
      'The shifted-control is a DELAY control, not a truly random placebo.',
      'No automatic policy promotion: comparisons after many historical trials require fresh independent evidence.',
      'See R54_MEGA_ALL_POLICY_SCENARIOS.csv and *_TRADES_2X.csv and *_DAILY_2X.csv.','']
    (out/'READ_FIRST.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for name in ('repo','downloads','work','out','pin'):
        parser.add_argument('--'+name,type=pathlib.Path,required=True)
    args=parser.parse_args()
    sys.exit(0 if main(args) else 2)
