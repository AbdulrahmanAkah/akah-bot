#!/usr/bin/env python3
# AKAH R57: independent EVENT-DRIVEN historical broker, research only 2022-2023.
# The broker independently generates chronological orders from signal masks and raw taped opens.
# It does NOT receive completed R56 trades as instructions. Archived R56 results are used ONLY for parity.
# Dependencies: standard-library Python and the pinned source loaders/signals from R54/R55.
from __future__ import annotations
import csv,zipfile,json,io,hashlib,os,pathlib,argparse,datetime as dt,math,traceback,sys,copy
from collections import defaultdict
import r54_p0r6_mega_portfolio as base
import r55_mega_engine as r55

VERSION='AKAH_R57_INDEPENDENT_EVENT_BROKER_MEGA_V1'
FROZEN=('BASE_W168','W168_BTC30_RISE','W168_ASSET30_RISE','XS_28D_WEEKLY_TOP3')
PINNED_R56_SHA='FAF1A93587762CAA14978835AC025C581E2C9298FEB46908785F92FBC8F6D53C'


def require(predicate, message):
    if not predicate:raise RuntimeError(message)


def write_json(path,object_):
    pathlib.Path(path).write_text(json.dumps(object_,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')


def write_csv(path,records):
    if not records:return
    with pathlib.Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)


def read_frozen_evidence(path):
    require(hashlib.sha256(path.read_bytes()).hexdigest().upper()==PINNED_R56_SHA,'R56_FROZEN_EVIDENCE_SHA_MISMATCH')
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        require('R56_REPORT.json'in names and 'R56_16_COST_SCENARIOS.csv'in names,'R56_REPORT_MISSING')
        rep=json.loads(z.read('R56_REPORT.json'))
        require(rep['status']=='PASS_OFFLINE_FUNCTIONAL_LAB_ONLY_NOT_TRADING_APPROVAL','R56_AUTHORITY_BAD')
        require(rep['scope']=='FROZEN_20PAIR_2022_2023_ONLY','R56_SCOPE_DRIFT')
        require(rep['2024_market_rows_read']==0 and rep['real_orders_sent']==0,'R56_SAFETY_DRIFT')
        expected={(row['policy'],row['scenario']):row for row in csv.DictReader(io.StringIO(z.read('R56_16_COST_SCENARIOS.csv').decode('utf-8-sig')))}
        require(len(expected)==16,'R56_EXPECTED_16_SCENARIOS_NOT_FOUND')
        archived={}
        for name in FROZEN:
            fn=name+'_HISTORICAL_TRADES.csv'
            require(fn in names,'R56_TRADE_ARCHIVE_MISSING:'+name)
            archived[name]=list(csv.DictReader(io.StringIO(z.read(fn).decode('utf-8-sig'))))
        return rep,expected,archived


def calc_liquidity(bar,t):
    if t<25:return 0.0
    previous24=bar['vol_prefix'][t]-bar['vol_prefix'][t-24]
    previous1=bar['quote_volume'][t-1]
    enough=bar['positive_vol_prefix'][t]-bar['positive_vol_prefix'][t-24]>=23
    if not enough or previous1<=0:return 0.0
    return min(previous24*.001, previous1*.01)


def submit_order(journal,bar_i,kind,pair,price,quantity,fees,slippage,notional,cash,positions,reason,signal_bar):
    require(len(positions)<=3,'BROKER_CAPACITY_VIOLATION')
    require(cash>=-1e-7,'BROKER_NEGATIVE_CASH')
    journal.append({'bar_i':bar_i,'utc':(base.START+dt.timedelta(hours=bar_i)).isoformat(),
        'kind':kind,'pair':pair,'order_quantity':round(quantity,12),
        'exchange_open':round(price,12),'fee_rate':fees,'slippage_rate':slippage,
        'cash_delta':round(notional,7),'cash_balance':round(cash,7),
        'open_positions':len(positions),'reason':reason,'source_signal_bar':signal_bar,
        'real_order':False})


def run_broker(tape,policy,scenario,excluded_pair=None,until=None):
    """Truly chronological broker execution. Does not look at an R56 trade ledger.

    Shared signal masks from R55 remain a common dependency (and require separate causal audit).
    """
    limit=base.TOTAL if until is None else min(int(until),base.TOTAL)
    require(0<limit<=base.TOTAL,'BROKER_INVALID_TIME_RANGE')
    pairs=sorted(p for p in tape if p!=excluded_pair)
    fee=scenario['fee_bps']/10000.
    slip=scenario['slip_bps']/10000.
    lag=scenario['latency_hours']+policy.shift
    cash=100000.;open_positions={};last_closed={};orders=[];trades=[];daily=[];nav_peak=100000.;drawdown=0.;yearend=None
    for hour in range(limit):
        for symbol in sorted(tuple(open_positions)):
            trade=open_positions[symbol];bars=tape[symbol]
            age=hour-trade['entry_hour']
            prior=bars['close'][hour-1] if hour else bars['open'][hour]
            if hour>trade['entry_hour']:
                trade['peak']=max(trade['peak'],prior)
            if policy.mode=='promote' and (not trade['promoted']) and age>=48 and hour>168:
                avg=(bars['close_prefix'][hour]-bars['close_prefix'][hour-168])/168.
                if prior>=trade['fill']*1.05 and prior>avg:
                    trade['promoted']=True;trade['hold']=336
            floor=trade['fill']*(1-policy.stop)
            if trade['promoted']:floor=max(floor,trade['peak']*.88)
            reason= ('CONTRACT_LAST_KNOWN_OPEN' if hour==base.CLOSE_OUT_BAR else
                    'MAX_HOLD' if age>=trade['hold'] else
                    'CLOSE_CONFIRMED_STOP_NEXT_OPEN' if prior<=floor else None)
            if reason:
                op=bars['open'][hour]
                returned=trade['qty']*op*(1.-slip)*(1.-fee)
                cash+=returned
                pnl=returned-trade['spent']
                trades.append({'pair':symbol,'entry_i':trade['entry_hour'],'exit_i':hour,
                    'entry_event_bar':trade['signal_bar'],'entry_cash':trade['spent'],
                    'exit_cash':returned,'net_pnl':pnl,'exit_reason':reason,
                    'entry_fill':trade['fill'],'exit_open':op,'holding_hours':age})
                del open_positions[symbol]
                last_closed[symbol]=hour
                submit_order(orders,hour,'EXIT',symbol,op,trade['qty'],fee,slip,returned,cash,open_positions,reason,trade['signal_bar'])
        if hour<base.CLOSE_OUT_BAR and hour>=lag and len(open_positions)<3:
            open_equity=cash+sum(pos['qty']*tape[p]['open'][hour] for p,pos in open_positions.items())
            exposure=sum(pos['qty']*tape[p]['open'][hour] for p,pos in open_positions.items())
            remaining=max(0.0, .60*open_equity-exposure)
            signal_hour=hour-lag
            eligible=[]
            for sym in pairs:
                if sym in open_positions or hour-last_closed.get(sym,-10000)<24:continue
                bars=tape[sym]
                if not base.has_signal(bars['events'][signal_hour],policy):continue
                max_liquid=calc_liquidity(bars,hour)
                if max_liquid<100:continue
                priority=bars['close'][signal_hour]/bars['low'][signal_hour]-1.
                eligible.append((-priority,sym,max_liquid))
            for _,sym,cap in sorted(eligible):
                if len(open_positions)>=3 or remaining<100:break
                budget=min(cash,.20*open_equity,remaining,cap)
                if budget<100:continue
                candle_open=tape[sym]['open'][hour]
                execution=candle_open*(1.+slip)
                qty=budget/(execution*(1.+fee))
                require(math.isfinite(qty) and qty>0,'BROKER_BAD_QUANTITY')
                cash-=budget;remaining-=budget
                open_positions[sym]={'entry_hour':hour,'signal_bar':signal_hour,
                                     'qty':qty,'spent':budget,'fill':execution,
                                     'hold':policy.hold,'peak':execution,'promoted':False}
                submit_order(orders,hour,'ENTRY',sym,candle_open,qty,fee,slip,-budget,cash,open_positions,'HISTORICAL_SIGNAL_NEXT_OPEN',signal_hour)
        nav=cash+sum(pos['qty']*tape[sym]['close'][hour]*(1.-fee)*(1.-slip) for sym,pos in open_positions.items())
        require(nav>0 and math.isfinite(nav),'BROKER_BAD_NAV')
        nav_peak=max(nav_peak,nav)
        drawdown=max(drawdown,1.-nav/nav_peak)
        if (hour+1)%24==0 or hour==limit-1 or hour==base.YEAREND-1:
            daily.append({'bar_index':hour,'closed_at_utc':(base.START+dt.timedelta(hours=hour+1)).isoformat(),
                         'equity':round(nav,6),'open_positions':len(open_positions)})
        if hour==base.YEAREND-1:yearend=nav
    if until is None:
        require(not open_positions,'BROKER_POSITIONS_REMAIN_AT_END')
        require(yearend is not None,'BROKER_YEAR_END_MISSING')
    return {'policy':policy.name,'scenario':scenario['name'],'excluded_pair':excluded_pair,
        'final_cash':cash,'final_equity':nav,'2022_pnl':yearend-100000. if yearend is not None else None,
        '2023_pnl':nav-yearend if yearend is not None else None,
        'max_drawdown_pct':100*drawdown,'trades':trades,'orders':orders,'daily':daily,
        'positions_at_end':len(open_positions)}


def check_frozen_parity(name,scenario,result,expected,archived):
    frozen=expected[(name,scenario)]
    for tag,original in [('final_equity','final_equity'),('2022_pnl','2022_pnl'),('2023_pnl','2023_pnl'),('max_drawdown_pct','max_drawdown_pct')]:
        current=result[tag]; prior=float(frozen[original]);
        require(abs(current-prior)<.015, 'INDEPENDENT_'+tag.upper()+'_DIFF:'+name+':'+scenario+':'+str((current,prior)))
    require(len(result['trades'])==int(frozen['trades']),'INDEPENDENT_TRADECOUNT_DIFF:'+name+':'+scenario)
    if scenario=='MODEL_2X':
        ref=archived[name]
        require(len(ref)==len(result['trades']),'R56_LEDGER_TRADECOUNT_MISMATCH')
        expected_sort=lambda r:(int(r['entry_i']),r['pair'],int(r['exit_i']))
        ref=sorted(ref,key=expected_sort);actual=sorted(result['trades'],key=expected_sort)
        for old,new in zip(ref,actual):
            for key in ('pair','entry_i','exit_i','entry_event_bar','exit_reason'):
                x=old[key];y=new[key]
                same=str(x)==str(y)
                require(same,'INDEPENDENT_TRADE_FIELD_DIFF:'+name+':'+key+':'+str((x,y)))
            require(abs(float(old['net_pnl'])-new['net_pnl'])<.001,'INDEPENDENT_TRADE_PNL_DIFF:'+name)
        require(len(result['orders'])==2*len(result['trades']),'BROKER_ORDER_JOURNAL_INCOMPLETE')
    return True


def tests():
    require(all(p in [x[0] for x in r55.SPECS] for p in FROZEN),'FROZEN_POLICY_MISSING')
    require(base.TOTAL==17519 and base.CLOSE_OUT_BAR==17518,'HISTORICAL_END_CHANGED')
    require(base.SCENARIOS[1]['name']=='MODEL_2X','R56_COST_BASIS_DRIFT')
    # synthetic 2-asset tape, event mask: independently replay vs original simulator
    n=base.TOTAL;syn={}
    for k in range(2):
        close=[100.+math.sin(i/160.0)*7.+math.sin(i/41.0)*3 for i in range(n)]
        op=[100.]+close[:-1]
        low=[min(op[i],close[i])*.99 for i in range(n)]
        high=[max(op[i],close[i])*1.01 for i in range(n)]
        qvol=[1e8]*n
        ev=[0]*n
        for j in range(300,17500,1100):ev[j]=2
        vpre=[0.];npos=[0];cpre=[0.]
        for v,c in zip(qvol,close):vpre.append(vpre[-1]+v);npos.append(npos[-1]+1);cpre.append(cpre[-1]+c)
        syn[('ETH-USDT','BTC-USDT')[k]]={'close':close,'open':op,'low':low,'high':high,
            'quote_volume':qvol,'vol_prefix':vpre,'positive_vol_prefix':npos,'close_prefix':cpre,'events':ev}
    pol=base.Policy('TEST_W168',168,168,.12);sc=base.SCENARIOS[1]
    a=run_broker(syn,pol,sc);b=base.sim(syn,pol,sc,diagnostics=True)
    require(abs(a['final_equity']-b['final_equity'])<.01 and len(a['trades'])==b['trades'],'SYNTHETIC_INDEPENDENT_PARITY')
    require(a['positions_at_end']==0,'SYNTHETIC_END_POSITIONS')
    require(all(x['source_signal_bar']<x['bar_i'] for x in a['orders'] if x['kind']=='ENTRY'),'SYNTHETIC_SAME_BAR_FILL')
    require(all(x['cash_balance']>=0 and x['open_positions']<=3 for x in a['orders']),'SYNTHETIC_BROKER_RISK_LIMIT')
    cut=base.TOTAL-100
    a1=run_broker(syn,pol,sc,until=cut)
    altered=copy.copy(syn)
    for p,bars in syn.items():
        bb=dict(bars);bb['events']=bars['events'][:cut]+[0]*(n-cut)
        altered[p]=bb
    a2=run_broker(altered,pol,sc,until=cut)
    require([(t['pair'],t['entry_i'],t['exit_i']) for t in a1['trades']]==[(t['pair'],t['entry_i'],t['exit_i']) for t in a2['trades']],'SYNTHETIC_PREFIX_INVARIANCE')
    return {'status':'PASS','synthetic_broker_parity':True,'risk_caps':True,'next_open_causality':True,'prefix_invariance':True}


def main(args):
    args.out.mkdir(parents=True,exist_ok=True)
    rep={'version':VERSION,'scope':'EXACT_SHA_PINNED_20PAIR_2022_2023_ONLY','real_orders_sent':0,'production_mutations':0,
        '2024_market_rows_read':0,'historical_PIT_certified':False,'execution_costs_certified':False,
        'policy_profitable_approved':False,'paper_forward_approved':False,'trade_api_used':False,'independent_signal_detector_certified':False,
        'status':'STARTED'}
    try:
        rep['tests']=tests()
        frozen,expected,archived=read_frozen_evidence(args.evidence)
        rep['R56_frozen_snapshot_sha256']=PINNED_R56_SHA
        pin=base.load_pin(args.pin)
        tape,source=base.read_tapes(args.repo,args.downloads,args.work,pin)
        rep['source_authority']={'pairs':source['pairs'],'read_market_rows':source['read_market_rows'],
                                 '2024_rows_read':source['2024_rows_read'],'PIT_membership_certified':source['PIT_membership_certified']}
        policies,metadata=r55.create_masks(tape)
        cases=[];total_orders=0;total_trades=0;checkpoints=[]
        for name in FROZEN:
            pol,masked=policies[name]
            for scenario in base.SCENARIOS:
                res=run_broker(masked,pol,scenario)
                check_frozen_parity(name,scenario['name'],res,expected,archived)
                cases.append({'policy':name,'scenario':scenario['name'],
                    'final_equity':round(res['final_equity'],3),'2022_pnl':round(res['2022_pnl'],3),
                    '2023_pnl':round(res['2023_pnl'],3),'max_drawdown_pct':round(res['max_drawdown_pct'],5),
                    'trades':len(res['trades']),'orders':len(res['orders']),'frozen_R56_parity':'PASS'})
                if scenario['name']=='MODEL_2X':
                    write_csv(args.out/(name+'_R57_INDEPENDENT_ORDERS_2X.csv'),res['orders'])
                    write_csv(args.out/(name+'_R57_INDEPENDENT_TRADES_2X.csv'),res['trades'])
                    write_csv(args.out/(name+'_R57_INDEPENDENT_DAILY_2X.csv'),res['daily'])
                    total_orders+=len(res['orders']);total_trades+=len(res['trades'])
                print('R57_PASS='+name+'/'+scenario['name']+' EQUITY='+str(round(res['final_equity'],3)),flush=True)
            source_top=frozen['stresses'][FROZEN.index(name)]['removed_pair']
            ref_row=next(x for x in frozen['stresses'] if x['policy']==name)
            ex=run_broker(masked,pol,base.SCENARIOS[1],excluded_pair=source_top)
            require(abs(ex['final_equity']-float(ref_row['final_equity']))<.015,'R57_LEAVE_TOP_PAIR_PARITY_FAILED:'+name)
            checkpoints.append({'policy':name,'removed_pair':source_top,'equity':round(ex['final_equity'],3),'parity':'PASS'})
            print('R57_STRESS_PASS='+name+'/'+source_top,flush=True)
        rep.update({'status':'PASS_INDEPENDENT_HISTORICAL_EVENT_BROKER_NOT_DEPLOYMENT',
            'n_policies':len(FROZEN),'n_scenarios':len(base.SCENARIOS),'n_main_replays':len(cases),
            'n_exclusion_replays':len(checkpoints),'n_total_replays':len(cases)+len(checkpoints),
            'model2x_total_orders':total_orders,'model2x_total_trades':total_trades,
            'scenario_parity':cases,'exclusion_parity':checkpoints,
            'known_blockers':['No historical PIT exchange membership authority for 20-pair cohort',
                'Execution costs and liquidity are model assumptions, not venue-certified',
                '2022-2023 data repeatedly explored: no independent return validation',
                'Some strategies fail positive-both-years and/or execution stress gates',
                'Independent broker reuses R55 frozen signal masks; independent signal proof not yet established',
                'No forward paper feed, clock, instrument rules, persistence or restart reconciliation'],
            'decision':'DO_NOT_DEPLOY_LIVE_OR_FORWARD_PAPER'})
    except Exception as e:
        rep['status']='BLOCKED_R57_INDEPENDENT_PARITY_OR_SOURCE'
        rep['error']=type(e).__name__+': '+str(e)
        rep['traceback_tail']=traceback.format_exc()[-5500:]
    write_json(args.out/'R57_INDEPENDENT_AUDIT_REPORT.json',rep)
    (args.out/'READ_FIRST_AR.md').write_text('# AKAH R57 — تدقيق محرك أوامر مستقل على بيانات تاريخية\n\n'
          'نجاح المطابقة يعني صحة التنفيذ وفق نموذج المحاكاة المجمد، ولا يعني أن الاستراتيجية مربحة خارج العينة أو جاهزة للإنتاج.\n\n'
          '2024 مغلقة، ولا أوامر حقيقية، ولا بيانات سوق حية، ولا تداول ورقي مستقبلي مفعل.\n\n'
          'راجع R57_INDEPENDENT_AUDIT_REPORT.json وملفات INDEPENDENT_ORDERS_2X.\n',encoding='utf8')
    print('R57_STATUS='+rep['status'],flush=True)
    return rep['status'].startswith('PASS')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for name in ('repo','downloads','work','out','pin','evidence'):ap.add_argument('--'+name,required=True,type=pathlib.Path)
    sys.exit(0 if main(ap.parse_args()) else 1)
