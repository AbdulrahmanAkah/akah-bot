#!/usr/bin/env python3
"""AKAH R55 exploratory one-pass: verify R54, predeclared gated reclaim, breakout and momentum.
Only frozen 2022/2023 local 20 tapes; no orders, no vendor API, no production edits.
"""
from __future__ import annotations
import argparse,csv,datetime as dt,hashlib,json,math,pathlib,sys,traceback
from collections import Counter,defaultdict,deque
import r54_p0r6_mega_portfolio as base

VERSION='AKAH_R55_MEGA_REGIME_CAUSAL_COMPARATIVE_V1'
EXPECTED_R54={
'D24_TACTICAL':{'MODEL_2X':70982.561},
'W168_SWING':{'MODEL_1X':103642.509,'MODEL_2X':99103.399,'MODEL_2X_DELAY3H':89627.313,'MODEL_2X_EXTRA_SLIP':91853.268},
}
N=base.TOTAL; YEAR_END=base.YEAREND
SC=base.SCENARIOS
# Hypotheses declared before running this V1 against market rows. Exploratory only.
SPECS=[
 ('BASE_W168',168,168,0.12,'base_w168'),
 ('BASE_D24',24,48,0.08,'base_d24'),
 ('W168_BTC30_RISE',168,168,0.12,'w_btc30'),
 ('W168_BTC90_RISE',168,168,0.12,'w_btc90'),
 ('W168_ASSET30_RISE',168,168,0.12,'w_asset30'),
 ('W168_BTC30_ASSET30',168,168,0.12,'w_both30'),
 ('W168_HOLD336',168,336,0.12,'base_w168'),
 ('D24_BTC30_ASSET30',24,48,0.08,'d_both30'),
 ('B20_CLOSED_BREAKOUT',168,336,0.15,'breakout20'),
 ('B20_BTC30_BREAKOUT',168,336,0.15,'breakout_btc30'),
 ('XS_28D_WEEKLY_TOP3',168,168,0.12,'weekly_top3'),
 ('XS_28D_BTC30_TOP3',168,168,0.12,'weekly_top3_btc30'),
]

def verify(cond,msg):
    if not cond:raise base.Gate(msg)

def closed_sma(b,j,n):
    if j+1<n:return None
    return (b['close_prefix'][j+1]-b['close_prefix'][j+1-n])/n

def btc_rule(btc,j,days):
    n=days*24
    if j<n-1 or j<168:return False
    ma=closed_sma(btc,j,n)
    return btc['close'][j]>ma and btc['close'][j]>btc['close'][j-168]

def asset_rule(b,j):
    if j<719 or j<168:return False
    return b['close'][j]>closed_sma(b,j,720) and b['close'][j]>b['close'][j-168]

def prior_highest(high,lookback=480):
    """out[j] max of high in [j-lookback,j); current j excluded. O(N)."""
    answer=[None]*len(high);q=deque()
    for j,h in enumerate(high):
        while q and q[0]<=j-lookback:q.popleft()
        if j>=lookback:answer[j]=high[q[0]]
        while q and high[q[-1]]<=h:q.pop()
        q.append(j)
    return answer

def create_masks(tape):
    btc=tape['BTC-USDT']
    btc30=[btc_rule(btc,j,30) for j in range(N)]
    btc90=[btc_rule(btc,j,90) for j in range(N)]
    assets={p:[asset_rule(b,j) for j in range(N)] for p,b in tape.items()}
    weekly={p:set() for p in tape}
    # Week decision at Sunday 23:00 UTC CLOSED 1H bar, next-open earliest fill.
    for j in range(47,N,168):
        if j<672:continue
        ranked=sorted(((b['close'][j]/b['close'][j-672]-1,p) for p,b in tape.items()),reverse=True)
        for momentum,p in ranked[:3]:
            if momentum>0:weekly[p].add(j)
    answer={}
    for name,h,hold,stop,mode in SPECS:
        modified={}
        for p,b in tape.items():
            mask=[0]*N
            if mode=='base_w168': mask=[int(bool(x&2))*2 for x in b['events']]
            elif mode=='base_d24': mask=[int(bool(x&1)) for x in b['events']]
            elif mode=='w_btc30': mask=[2 if (x&2) and btc30[j] else 0 for j,x in enumerate(b['events'])]
            elif mode=='w_btc90': mask=[2 if (x&2) and btc90[j] else 0 for j,x in enumerate(b['events'])]
            elif mode=='w_asset30': mask=[2 if (x&2) and assets[p][j] else 0 for j,x in enumerate(b['events'])]
            elif mode=='w_both30':mask=[2 if (x&2) and btc30[j] and assets[p][j] else 0 for j,x in enumerate(b['events'])]
            elif mode=='d_both30':mask=[1 if (x&1) and btc30[j] and assets[p][j] else 0 for j,x in enumerate(b['events'])]
            elif mode.startswith('breakout'):
                prior=prior_highest(b['high'])
                mask=[2 if (prior[j] is not None and b['close'][j]>prior[j] and
                             (mode=='breakout20' or btc30[j])) else 0 for j in range(N)]
            elif mode.startswith('weekly_top3'):
                mask=[0]*N
                for j in weekly[p]:
                    if mode=='weekly_top3' or btc30[j]:mask[j]=2
            else:raise base.Gate('UNKNOWN_MODE:'+mode)
            bb=dict(b);bb['events']=mask;modified[p]=bb
        answer[name]=(base.Policy(name,h,hold,stop),modified)
    return answer,{'btc30_hours':sum(btc30),'btc90_hours':sum(btc90),
                   'top3_weekly_positive_markers':sum(len(s) for s in weekly.values()),
                   'market_lookback_limitation':'2022 starts at 2022-01-01 (30d and 90d gates require in-range warmup; earlier 2021 hours unused)'}

def audit_result(result):
    trades=result['_trades'];daily=result['_daily'];weekly=result['_weekly']
    pnl=sum(t['net_pnl'] for t in trades)
    verify(abs(pnl-result['total_pnl'])<0.1,'PNL_LEDGER_RECONCILIATION:'+result['policy'])
    verify(abs(daily[-1]['value_usdt']-result['final_equity'])<.01,'DAILY_END_RECONCILIATION')
    verify(abs(sum(w['net_change_usdt'] for w in weekly)-result['total_pnl'])<.1,'WEEKLY_RECONCILIATION')
    verify(result['trades']==len(trades),'TRADE_COUNT_MISMATCH')
    verify(abs(result['2022_pnl']+result['2023_pnl']-result['total_pnl'])<0.01,'ANNUAL_RECONCILIATION')
    for t in trades:
        verify(2022<=dt.datetime.fromisoformat(t['entry_utc']).year<=2023 and
               2022<=dt.datetime.fromisoformat(t['exit_utc']).year<=2023,'OUT_OF_BOUNDS_TRADE')
        verify(t['entry_i']>t['entry_event_bar'],'SAME_BAR_FILL')
    return {'trades':len(trades),'net_pnl':round(pnl,3),'daily_rows':len(daily),'weekly_rows':len(weekly)}

def metrics_full(result):
    r=base.strip_private(result)
    r['annual_2022_positive']=r['2022_pnl']>0;r['annual_2023_positive']=r['2023_pnl']>0
    r['weekly_positive_share_pct']=round(100*r['positive_weeks']/max(1,r['positive_weeks']+r['negative_weeks']),3)
    r['stop_exit_pnl']=round(sum(t['net_pnl'] for t in result['_trades'] if t['exit_reason']=='CLOSE_CONFIRMED_STOP_NEXT_OPEN'),3)
    r['stop_exit_count']=sum(t['exit_reason']=='CLOSE_CONFIRMED_STOP_NEXT_OPEN' for t in result['_trades'])
    return r

def write_csv(out,rows,cols=None):
    if not rows:return
    base.putcsv(out,rows,cols or list(rows[0]))

def safe_do(tape,work,out):
    masks,gate_meta=create_masks(tape)
    all_rows=[];base_rows={};audits=[];stress=[];audit_detail=[]
    for name,_,_,_,mode in SPECS:
        pol,masked=masks[name]
        for scenario in SC:
            result=base.sim(masked,pol,scenario,diagnostics=scenario['name']=='MODEL_2X')
            row=metrics_full(result)
            all_rows.append(row)
            if name=='BASE_W168' and scenario['name'] in EXPECTED_R54['W168_SWING']:
                expected=EXPECTED_R54['W168_SWING'][scenario['name']]
                verify(abs(row['final_equity']-expected)<0.01,'R54_W168_BASELINE_PARITY_'+scenario['name'])
            if name=='BASE_D24' and scenario['name']=='MODEL_2X':
                verify(abs(row['final_equity']-EXPECTED_R54['D24_TACTICAL']['MODEL_2X'])<0.01,'R54_D24_BASELINE_PARITY')
            if scenario['name']=='MODEL_2X':
                audits.append({'policy':name,**audit_result(result)})
                base_rows[name]=result
                write_csv(out/(name+'_TRADES_2X.csv'),result['_trades'],['policy','scenario','pair','entry_i','exit_i','entry_utc','exit_utc','entry_fill','exit_open','entry_cash','exit_cash','net_pnl','net_return_pct','holding_hours','entry_event_bar','promoted','exit_reason'])
                write_csv(out/(name+'_DAILY_2X.csv'),result['_daily'],['bar_index','asof_closed_utc','value_usdt','open_positions'])
                write_csv(out/(name+'_WEEKLY_2X.csv'),result['_weekly'],['week_year','iso_week','ending_open_utc','net_change_usdt','ending_equity_usdt'])
            print(f'POLICY={name} SCENARIO={scenario["name"]} FINAL={row["final_equity"]} 2022={row["2022_pnl"]} 2023={row["2023_pnl"]} DD={row["max_drawdown_pct"]}',flush=True)
    for name,_,_,_,mode in SPECS:
        pol,masked=masks[name];ref=base_rows[name]
        target=ref['top_profitable_pair']
        if not target:continue
        rerun=base.sim(masked,pol,SC[1],exclude=target)
        stress.append({'policy':name,'removed_pair':target,'final_equity':rerun['final_equity'],'2022_pnl':rerun['2022_pnl'],
                       '2023_pnl':rerun['2023_pnl'],'max_drawdown_pct':rerun['max_drawdown_pct'],
                       'trades':rerun['trades']})
    write_csv(out/'R55_ALL_48_SCENARIOS.csv',all_rows)
    write_csv(out/'R55_LEAVE_TOP_PAIR_OUT.csv',stress)
    write_csv(out/'R55_ACCOUNTING_AUDIT.csv',audits)
    gates=[]
    for name,_,_,_,mode in SPECS:
        two=next(r for r in all_rows if r['policy']==name and r['scenario']=='MODEL_2X')
        delay=next(r for r in all_rows if r['policy']==name and r['scenario']=='MODEL_2X_DELAY3H')
        slip=next(r for r in all_rows if r['policy']==name and r['scenario']=='MODEL_2X_EXTRA_SLIP')
        ex=next((r for r in stress if r['policy']==name),None)
        g={'positive_both_years':two['2022_pnl']>0 and two['2023_pnl']>0,
           'positive_2x':two['total_pnl']>0,
           '2x_latency3h_positive':delay['total_pnl']>0,
           '2x_extra_slip_positive':slip['total_pnl']>0,
           'drawdown_le_25pct':two['max_drawdown_pct']<=25,
           'leave_top_pair_out_positive_both_years':bool(ex and ex['2022_pnl']>0 and ex['2023_pnl']>0),
           'at_least_52_trades_2yrs':two['trades']>=52}
        gates.append({'policy':name,'gates':g,'mechanical_exploratory_pass':all(g.values()),'PIT_certified':False,'cost_certified':False,'live_approved':False,'paper_approved':False})
    base.putjson(out/'R55_RESEARCH_GATES.json',gates)
    return {'n_policy':len(SPECS),'n_scenarios':len(SC),'n_economic_replays':len(all_rows)+len(stress),
            'gate_meta':gate_meta,'audit_rows':audits,'research_gates':gates,
            'results_2x':[r for r in all_rows if r['scenario']=='MODEL_2X'],
            'top_pair_exclusion':stress, 'controls':['BASE_W168','BASE_D24'],
            'R54_baseline_parity':'PASS_5_CELLS',
            'selection':'NONE_REPEATED_2022_2023_NOT_FRESH_HOLDOUT'}

def selftest():
    verify(base.selftest()==22,'R54_BASE_SELFTEST_FAILED')
    hi=[1,2,3,4,5,2,9];q=prior_highest(hi,3)
    verify(q==[None,None,None,3,4,5,5],f'HIGH_ROLLING_INCLUDES_CURRENT_OR_BAD:{q}')
    b={'close':[100.0]*720,'close_prefix':[0.0]}
    for v in b['close']:b['close_prefix'].append(b['close_prefix'][-1]+v)
    verify(closed_sma(b,719,720)==100 and closed_sma(b,718,720) is None,'SMA_CAUSAL_BAD')
    verify(base.CLOSE_OUT_BAR==17518 and N==17519,'HARD_2023_END')
    verify(len(set(z[0] for z in SPECS))==len(SPECS),'DUPLICATE_POLICY_NAME')
    return 27

def main(args):
    args.out.mkdir(parents=True,exist_ok=True)
    report={'version':VERSION,'status':'RUNNING','start_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'scope':'FROZEN_R42_20PAIR_2022_2023_ONLY','2024_market_rows_read':0,
            'production_modified':False,'live_orders':0,'PIT_historical_universe_certified':False,
            'execution_costs_certified':False,'not_independent_confirmation':True}
    try:
        report['selftests']=selftest()
        pin=base.load_pin(args.pin)
        tape,authority=base.read_tapes(args.repo,args.downloads,args.work,pin)
        report['authority']=authority
        report['economic']=safe_do(tape,args.work,args.out)
        report['status']='PASS_R55_RESEARCH_ONLY_NO_DEPLOYMENT'
    except Exception as e:
        report['status']='BLOCKED_R55';report['error']=type(e).__name__+': '+str(e)
        report['traceback_tail']=traceback.format_exc()[-4500:]
    report['end_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
    base.putjson(args.out/'R55_MEGA_REPORT.json',report)
    if report['status'].startswith('PASS'):
        rows=report['economic']['results_2x']
        lines=['# R55 Research Outcomes (2022–2023 only)','',
               'No new independent holdout. All strategies exploratory, 20-asset retrospective universe; no live or paper approval.','',
               '|Policy|Equity|2022|2023|Max DD|Trades|','|---|---:|---:|---:|---:|---:|']
        for r in rows:lines.append(f"|{r['policy']}|${r['final_equity']:,.0f}|${r['2022_pnl']:,.0f}|${r['2023_pnl']:,.0f}|{r['max_drawdown_pct']:.2f}%|{r['trades']}|")
        lines+=['','R54 original W168 and D24 parity checked. 2024 market rows=0.',
                'Do not pick a winning arm from repeatedly inspected 2022/2023 and call it validated.','',
                'Mechanics: R54 verified SHA tapes, close-bar signals, next-open fills, unchanged risk cap and costs.',
                'Market and asset trend gates: data known at event close only; 2022 warmup restriction applies.',
                'Replays are model dependent and the 20-asset universe was selected retrospectively.','']
        (args.out/'READ_FIRST.md').write_text('\n'.join(lines),encoding='utf-8')
    print('R55_STATUS='+report['status'],flush=True)
    if 'error' in report:print('R55_ERROR='+report['error'],flush=True)
    return report['status'].startswith('PASS')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for a in ('repo','downloads','work','out','pin'):ap.add_argument('--'+a,type=pathlib.Path,required=True)
    sys.exit(0 if main(ap.parse_args()) else 2)
