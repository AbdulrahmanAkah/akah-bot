#!/usr/bin/env python3
"""AKAH R56: fail-closed 2022–2023 historical paper-only functional trial.
Freeze 4 R55 research policies. Not an alpha discovery, not forward paper, not real trading.
No network access, API credentials, broker adapter, production changes, or 2024 reads.
"""
from __future__ import annotations
import argparse,csv,datetime as dt,hashlib,html,json,math,pathlib,sys,traceback,copy
from collections import Counter
import r55_mega_engine as r55
import r54_p0r6_mega_portfolio as base

NAME='AKAH_R56_OFFLINE_REPLAY_PRODUCT_LAB_V1'
FROZEN=('BASE_W168','W168_BTC30_RISE','W168_ASSET30_RISE','XS_28D_WEEKLY_TOP3')
EXPECTED={'BASE_W168':(99103.399,257,-8024.608,7128.006),
'W168_BTC30_RISE':(103087.291,55,-1140.944,4228.235),
'W168_ASSET30_RISE':(101004.601,14,526.412,478.189),
'XS_28D_WEEKLY_TOP3':(106997.762,96,-13294.127,20291.889)}
SCOPE='FROZEN_20PAIR_2022_2023_ONLY'; ALLOWED_SCENARIOS=base.SCENARIOS


def need(ok,message):
    if not ok:raise RuntimeError(message)


def jsave(path,d):path.write_text(json.dumps(d,ensure_ascii=False,indent=2,sort_keys=True,default=str)+'\n',encoding='utf8')


def csvsave(path,rr):
    if not rr:return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]),extrasaction='ignore');w.writeheader();w.writerows(rr)


def ledger_to_orders(result):
    """INDEPENDENT order book playback from the simulated fill journal (not new signals)."""
    e=[]
    for r in result['_trades']:
        for kind,t,value in [('EXIT',r['exit_i'],r['exit_cash']),('ENTRY',r['entry_i'],r['entry_cash'])]:
            # Same-hour exit must be accounted before entry to avoid artificial cash shortage.
            e.append({'bar_i':int(t),'utc':r['exit_utc'] if kind=='EXIT' else r['entry_utc'],
                      'kind':kind,'pair':r['pair'],'cash_change_usdt':round(value if kind=='EXIT' else -value,4),
                      'signal_bar_i':r['entry_event_bar'] if kind=='ENTRY' else None,
                      'fill':r['exit_open'] if kind=='EXIT' else r['entry_fill'],
                      'reason':r['exit_reason'] if kind=='EXIT' else 'HISTORICAL_SIGNAL_NEXT_OPEN'})
    e.sort(key=lambda x:(x['bar_i'],0 if x['kind']=='EXIT' else 1,x['pair']))
    money=100000.0;positions=set(); peak=0;negative=0
    for r in e:
        pair=r['pair'];money+=r['cash_change_usdt']
        if r['kind']=='EXIT':need(pair in positions,'EXIT_WITHOUT_POSITION:'+pair);positions.remove(pair)
        else:need(pair not in positions,'DUPLICATE_OPEN:'+pair);positions.add(pair)
        need(money>=-0.5,'NEGATIVE_SIM_CASH:'+str(money))
        peak=max(peak,len(positions));negative+=int(money<0)
        need(peak<=3,'OVER_THREE_POSITIONS')
        r['balance_after_usdt']=round(money,4);r['positions_after']=len(positions)
        r['research_only']=True
    need(not positions,'OPEN_AT_END')
    need(abs(money-result['final_equity'])<.3,'BROKER_CASH_MISMATCH')
    need(len(e)==2*result['trades'],'ORDER_COUNT_MISMATCH')
    return e,{'orders':len(e),'entries':result['trades'],'max_simultaneous_positions':peak,
              'final_cash':round(money,3),'final_equity':result['final_equity'],'cash_reconciled':True}


def validate_causal_trades(result):
    for r in result['_trades']:
        j=int(r['entry_event_bar']);entry=int(r['entry_i']);exit_i=int(r['exit_i'])
        need(0<=j<entry<=exit_i<base.TOTAL,'NON_CAUSAL_FILL_INDEX')
        need(2022<=dt.datetime.fromisoformat(r['entry_utc']).year<=2023,'ENTRY_AFTER_ALLOWED_END')
        need(2022<=dt.datetime.fromisoformat(r['exit_utc']).year<=2023,'EXIT_AFTER_ALLOWED_END')
        need(0<r['entry_fill'] and r['entry_cash']>0 and r['exit_cash']>=0,'BAD_FILL')
        need(abs((r['exit_cash']-r['entry_cash'])-r['net_pnl'])<.001,'TRADE_PNL_NOT_CASH_DIFFERENCE')
    return len(result['_trades'])


def partial_prefix_invariance(tape,masks,pol,scenario):
    """Historical replay should not let suffix data affect completed pre-suffix trades.
    Modify future events for 2 days and compare completed trades before that date.
    """
    cut=base.TOTAL-72
    v1=base.sim(masks,pol,scenario,diagnostics=True)
    perturbed={}
    for pair,b in masks.items():
        bb=dict(b)
        bb['events']=b['events'][:cut]+[0]*(len(b['events'])-cut)
        bb['close']=b['close'][:cut]+[v*1.5 for v in b['close'][cut:]]
        bb['high']=b['high'][:cut]+[v*1.5 for v in b['high'][cut:]]
        bb['low']=b['low'][:cut]+[v*1.5 for v in b['low'][cut:]]
        bb['open']=b['open'][:cut]+[v*1.5 for v in b['open'][cut:]]
        perturbed[pair]=bb
    v2=base.sim(perturbed,pol,scenario,diagnostics=True)
    before=lambda v: [(r['pair'],r['entry_i'],r['exit_i'],r['net_pnl']) for r in v['_trades'] if r['exit_i']<cut]
    need(before(v1)==before(v2),'LOOKAHEAD_PREFIX_DRIFT')
    return {'prefix_invariance':True,'mutation_start_bar':cut,'pre_mutation_completed_trades':len(before(v1))}


def render_dashboard(out,results,records):
    chosen=[]
    for name in FROZEN:
        res=results[name]
        chosen.append({'name':name,'equity':res['final_equity'],'pnl22':res['2022_pnl'],'pnl23':res['2023_pnl'],
                       'trades':res['trades'],'drawdown':res['max_drawdown_pct'],
                       'daily':[round(d['value_usdt'],2) for d in res['_daily']],
                       'positions':[d['open_positions'] for d in res['_daily']],
                       'orders':records[name][-180:]})
    data=json.dumps(chosen,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    body='''<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AKAH R56 — offline paper lab</title><style>
body{font:15px Tahoma,Arial,sans-serif;background:#0c1524;color:#ecf3fe;max-width:1200px;margin:auto;padding:25px}h1{font-size:24px}.warn{padding:15px;border:1px solid #a15b4f;background:#2b2025;border-radius:10px;line-height:1.8;color:#ffcdbe}section{background:#142137;border:1px solid #2d425a;border-radius:14px;margin:20px 0;padding:17px}.metrics{display:flex;gap:12px;flex-wrap:wrap}.metric{border:1px solid #354b61;border-radius:8px;padding:13px;min-width:140px;flex:1}.metric small{display:block;color:#b0c3da}.metric b{font-size:21px}select{background:#0b1726;color:#fff;padding:9px;border-radius:8px}svg{width:100%;height:290px;background:#0c1727;border-radius:8px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{text-align:right;padding:9px;border-bottom:1px solid #293e56}.scroll{overflow:auto;max-height:390px}.pos{color:#86d5ac}.neg{color:#ffa49c}.sub{color:#a9bed7;font-size:13px;line-height:1.7}</style></head><body>
<h1>AKAH — R56 Historical Paper Lab</h1><div class="warn"><b>NO REAL TRADING / NOT FORWARD PAPER APPROVED</b><div>هذا نموذج وظيفي لإعادة تشغيل قرارات تاريخية على بيانات 2022–2023 فقط. جميع السياسات غير معتمدة. لا يوجد اتصال بمنصة ولا إرسال أوامر ولا استخدام لبيانات 2024.</div></div>
<section><select id="sel"></select><div id="metrics" class="metrics"></div><h3>القيمة اليومية للمحفظة ($)</h3><svg id="nav" viewBox="0 0 1000 270" preserveAspectRatio="none"></svg><p class="sub">كل تعبئة في السجل أدناه تعبئة اصطناعية بتاريخ تاريخي، وليست أمرًا مرسلًا للبورصة.</p></section>
<section><h3>آخر 180 إجراء محاكاة</h3><div class="scroll"><table><thead><tr><th>التاريخ UTC</th><th>النوع</th><th>الأصل</th><th>التغير النقدي</th><th>المراكز المفتوحة</th></tr></thead><tbody id="orders"></tbody></table></div></section>
<section><h3>شروط الاعتماد</h3><p class="sub">لا توجد فترة تأكيد مستقلة، والأصول العشرون ليست عضوية تاريخية PIT موثقة، وتكاليف التنفيذ نموذجية. هذه تجربة لبنية البرمجيات لا لقابلية الربح. يتطلب أي اختبار ورقي مستقبلي موافقة مستقلة ومصدر سوق مباشر معتمد.</p></section>
<script>let D=__DATA__,sel=document.getElementById('sel');D.forEach((d,i)=>{let a=document.createElement('option');a.value=i;a.textContent=d.name;sel.appendChild(a)});function n(x){return Number(x).toLocaleString('en-US',{maximumFractionDigits:2,minimumFractionDigits:2})}function render(){let d=D[+sel.value||0];let m=[['النهاية',n(d.equity)+'$'],['2022',n(d.pnl22)+'$'],['2023',n(d.pnl23)+'$'],['الصفقات',d.trades],['أقصى تراجع',n(d.drawdown)+'%']];document.getElementById('metrics').innerHTML=m.map(x=>'<div class="metric"><small>'+x[0]+'</small><b>'+x[1]+'</b></div>').join('');let vv=d.daily,mi=Math.min(100000,...vv),ma=Math.max(100000,...vv),pad=(ma-mi)*.06||20,lo=mi-pad,hi=ma+pad;let pt=vv.map((v,i)=>(1000*i/(vv.length-1)).toFixed(2)+','+(265-260*(v-lo)/(hi-lo)).toFixed(2)).join(' ');let y=265-260*(100000-lo)/(hi-lo);document.getElementById('nav').innerHTML='<line x1="0" x2="1000" y1="'+y+'" y2="'+y+'" stroke="#778a9b" stroke-dasharray="6 6"/><polyline fill="none" stroke="#7fd1de" stroke-width="2" vector-effect="non-scaling-stroke" points="'+pt+'"/>';document.getElementById('orders').innerHTML=d.orders.slice().reverse().map(o=>'<tr><td>'+o.utc.slice(0,16)+'</td><td>'+o.kind+'</td><td>'+o.pair+'</td><td class="'+(o.cash_change_usdt<0?'neg':'pos')+'">'+n(o.cash_change_usdt)+'$</td><td>'+o.positions_after+'</td></tr>').join('')};sel.onchange=render;render();</script></body></html>'''
    (out/'R56_OFFLINE_PAPER_DASHBOARD.html').write_text(body.replace('__DATA__',data),encoding='utf-8')


def selftest():
    t={'_trades':[{'entry_i':4,'exit_i':6,'entry_utc':'2022-01-01T04:00:00+00:00','exit_utc':'2022-01-01T06:00:00+00:00','pair':'BTC-USDT','entry_cash':1000.,'exit_cash':1010.,'entry_event_bar':3,'entry_fill':100.5,'exit_open':102.,'net_pnl':10.,'exit_reason':'MAX_HOLD'}], 'final_equity':100010.,'trades':1}
    rows,check=ledger_to_orders(t);need(len(rows)==2 and check['max_simultaneous_positions']==1,'BROKER_SELFTEST')
    need(validate_causal_trades(t)==1,'CAUSAL_SELFTEST')
    try:
        o=copy.deepcopy(t);o['_trades'][0]['entry_event_bar']=4;validate_causal_trades(o);raise RuntimeError('LEAKAGE_SELFTEST_FAILED')
    except RuntimeError as ex:
        need(str(ex)=='NON_CAUSAL_FILL_INDEX','LEAKAGE_REJECTION_SELFTEST_BAD')
    need(all(x['name'] in [s['name'] for s in ALLOWED_SCENARIOS] for x in ALLOWED_SCENARIOS),'SCENARIO_SET_BAD')
    need(len(FROZEN)==4 and set(FROZEN)<=set(x[0] for x in r55.SPECS),'FROZEN_SET_DRIFT')
    return 5


def main(a):
    a.out.mkdir(parents=True,exist_ok=True)
    report={'name':NAME,'status':'RUNNING','scope':SCOPE,'2024_market_rows_read':0,
            'trade_api_used':False,'production_modified':False,'real_orders_sent':0,
            'paper_forward_approved':False,'live_approved':False,'PIT_certified':False,
            'costs_certified':False,'historical_dataset_reused_not_independent':True}
    try:
        report['selftests']=selftest()
        pin=base.load_pin(a.pin)
        tape,authority=base.read_tapes(a.repo,a.downloads,a.work,pin)
        report['authority']=authority
        masks,gate_meta=r55.create_masks(tape)
        report['mask_summary']=gate_meta
        rows=[];checks=[];stress=[];results={};books={}
        for name in FROZEN:
            pol,signal_tape=masks[name]
            for sc in ALLOWED_SCENARIOS:
                res=base.sim(signal_tape,pol,sc,diagnostics=True)
                verify=r55.audit_result(res)
                validate_causal_trades(res)
                od,broker=ledger_to_orders(res)
                row=base.strip_private(res)
                row['independent_broker_cash_reconciled']=broker['cash_reconciled']
                rows.append(row)
                if sc['name']=='MODEL_2X':
                    expected=EXPECTED[name]
                    need(abs(row['final_equity']-expected[0])<.01,'FROZEN_R55_EQUITY_DRIFT:'+name)
                    need(row['trades']==expected[1],'FROZEN_R55_TRADECOUNT_DRIFT:'+name)
                    need(abs(row['2022_pnl']-expected[2])<.01 and abs(row['2023_pnl']-expected[3])<.01,'FROZEN_R55_YEAR_DRIFT:'+name)
                    results[name]=res;books[name]=od
                    csvsave(a.out/(name+'_HISTORICAL_SIMULATED_ORDERS.csv'),od)
                    csvsave(a.out/(name+'_HISTORICAL_TRADES.csv'),res['_trades'])
                    csvsave(a.out/(name+'_DAILY_NAV.csv'),res['_daily'])
                    checks.append({'policy':name,'orders':len(od),'trade_count':row['trades'],'broker_cash':broker['final_cash'],
                                   'equity':row['final_equity'],'causal':True,'ledger_ok':True})
                print('R56_POLICY='+name+' SCENARIO='+sc['name']+' FINAL='+str(row['final_equity']),flush=True)
            best=results[name]['top_profitable_pair']
            ex=base.sim(signal_tape,pol,ALLOWED_SCENARIOS[1],exclude=best,diagnostics=True)
            validate_causal_trades(ex);ledger_to_orders(ex)
            stress.append({'policy':name,'removed_pair':best,'final_equity':ex['final_equity'],
                           '2022_pnl':ex['2022_pnl'],'2023_pnl':ex['2023_pnl'],'trades':ex['trades']})
        report['prefix_invariance']=partial_prefix_invariance(tape,masks['W168_BTC30_RISE'][1],masks['W168_BTC30_RISE'][0],ALLOWED_SCENARIOS[1])
        report['replays']=len(rows)+len(stress)+2
        report['accounting_checks']=checks;report['stresses']=stress
        report['all_research_gates_passed']=False
        csvsave(a.out/'R56_16_COST_SCENARIOS.csv',rows)
        csvsave(a.out/'R56_LEAVE_TOP_PAIR_OUT.csv',stress)
        render_dashboard(a.out,results,books)
        (a.out/'READ_FIRST_AR.md').write_text('# R56 — نموذج ورقي تاريخي فقط\n\nنجح التشغيل التقني لـ4 سياسات متجمدة مع 16 سيناريو تكلفة و4 إعادة تشغيل بعد الاستبعاد.\n\nلا أرباح متوقعة معتمدة، ولا تداول ورقي مستقبلي، ولا أوامر حقيقية، و2024 مغلقة.\n\nافتح R56_OFFLINE_PAPER_DASHBOARD.html لمراجعة قرارات المحاكي التاريخي.\n',encoding='utf8')
        report['status']='PASS_OFFLINE_FUNCTIONAL_LAB_ONLY_NOT_TRADING_APPROVAL'
    except Exception as ex:
        report['status']='BLOCKED_R56';report['error']=type(ex).__name__+': '+str(ex)
        report['traceback']=traceback.format_exc()[-5000:]
    jsave(a.out/'R56_REPORT.json',report)
    print('R56_STATUS='+report['status'],flush=True)
    if 'error'in report:print('R56_ERROR='+report['error'],flush=True)
    return report['status'].startswith('PASS')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for k in ('repo','downloads','work','out','pin'):ap.add_argument('--'+k,type=pathlib.Path,required=True)
    sys.exit(0 if main(ap.parse_args()) else 1)
