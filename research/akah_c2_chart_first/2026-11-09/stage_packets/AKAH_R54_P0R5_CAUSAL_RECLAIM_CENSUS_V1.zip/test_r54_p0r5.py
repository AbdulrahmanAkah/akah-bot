import datetime as dt, hashlib, json, pathlib, struct, tempfile, sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import r54_p0r5_reclaim_census as m
REC=struct.Struct('<5d')
class FakeMod:
    REC=REC
    START=dt.datetime(2022,1,1,tzinfo=dt.timezone.utc)
    H=dt.timedelta(hours=1)
    @staticmethod
    def validate_row(raw,i):
        assert 0<=i<m.TOTAL
        return REC.unpack(raw)

def integration():
    with tempfile.TemporaryDirectory() as td:
        base=pathlib.Path(td);repo=base/'repo';down=base/'Downloads';work=base/'work';out=base/'out'
        (repo/'.akah_bot/v2r2_common_causal_tape_v1/pairs').mkdir(parents=True)
        (down/'AKAH_R13R27_MEGA_WORK').mkdir(parents=True)
        work.mkdir()
        refs={};eligible={}
        for pair in ['BTC-USDT','ETH-USDT']:
            eligible[pair]=0
            path=repo/'.akah_bot/v2r2_common_causal_tape_v1/pairs'/(pair+'.1H.bars.bin')
            dig22=hashlib.sha256();dig23=hashlib.sha256()
            with path.open('wb') as f:
                for i in range(m.TOTAL):
                    # Inject causal sweeps every 100h, with 168h and 720h rarer as expected.
                    low=99.0 if i%100==0 else 100.0
                    blob=REC.pack(101,103,low,102,500)
                    f.write(blob)
                    (dig22 if i<m.HOURS_22 else dig23).update(blob)
            refs[pair]={'2022_sha256':dig22.hexdigest(), '2023_8759_sha256':dig23.hexdigest()}
        (down/'AKAH_R13R27_MEGA_WORK'/'R13R27_FROZEN_PLAN.json').write_text(json.dumps({'eligible':eligible}))
        old=m.REF_WITNESS;old_vendor=m.get_vendor
        try:
            m.REF_WITNESS=refs
            m.get_vendor=lambda d,w:(FakeMod, {'r43_source_sha256':'SYNTHETIC','record_size':REC.size})
            assert m.main(repo,down,out,work)
            report=json.loads((out/'R54_P0R5_EVENT_CENSUS_REPORT.json').read_text())
            assert report['rows_read_2022']==2*m.HOURS_22 and report['rows_read_2023']==2*m.HOURS_23
            assert report['event_rows']>0
            assert report['2024_market_rows_read']==0
            print('INTEGRATION_PASS_20PAIR_SCHEMA_PROOF_2_SYNTHETIC_PAIRS',report['counts'])
            # Assert future-only changes do not modify prior events.
            rows=[(100,101)]*720+[(99,101)]
            found=m.detect_events(rows); assert found[0][0]==720
            assert found[0] in m.detect_events(rows+[(98,98)])
        finally:
            m.REF_WITNESS=old;m.get_vendor=old_vendor
if __name__=='__main__':integration()
