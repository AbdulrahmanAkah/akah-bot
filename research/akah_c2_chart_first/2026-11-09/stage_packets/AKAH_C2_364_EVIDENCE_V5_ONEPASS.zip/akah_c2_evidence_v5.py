#!/usr/bin/env python3
# AKAH C2 364: read-only historical evidence enrichment & candle anatomy.
# Uses pre-2024-only data; no orders, no production mutations, no strategy fitting.
import argparse,collections,csv,datetime as dt,gzip,hashlib,io,json,math,os,pathlib,random,statistics,sys,time,urllib.error,urllib.parse,urllib.request,zipfile
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import deque,defaultdict
UTC=dt.timezone.utc
CUT=1704067200000
START=1483228800000
HOUR=3600000;DAY=24*HOUR
PIN='d994e7533174f5bc4b2b63ef8c119bc2235c2001818542379faa9451e29b04a2'
VERSION='AKAH_C2_364_EVIDENCE_V5'
RAW_FIELDS=['unix_ms','open','high','low','close','base_volume','quote_volume','trade_count','taker_buy_quote_volume']
METRICS=['CapMrktCurUSD','SplyCur','TxCnt','AdrActCnt']
CM_SYMBOLS=['BTC','ETH','SOL','XRP','ADA','DOGE','BNB','LTC','LINK','AVAX','ATOM','TRX','DOT','XMR','BCH','ETC','XLM','ALGO','NEAR','AAVE','FIL','MATIC','UNI','USDT','USDC','DAI','INJ','OP','ARB','MANA','SAND','SHIB','XTZ','EOS','NEO','VET','ZEC','YFI','COMP']

def sha256(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def js(path,value):
 p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 with open(tmp,'w',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False,default=str)
 os.replace(tmp,p)

def csvwrite(path,records,fields):
 p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 with open(tmp,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
 os.replace(tmp,p)

def readcsv(path):
 with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def rows_gz(path):
 path=pathlib.Path(path)
 if not path.is_file():return []
 with gzip.open(path,'rt',encoding='utf-8-sig',newline='') as f:
  return [r for r in csv.DictReader(f) if r.get('unix_ms','').lstrip('-').isdigit() and START<=int(r['unix_ms'])<CUT]

def tofloat(v):
 try:
  x=float(v)
  return x if math.isfinite(x) else None
 except (TypeError,ValueError):return None

def bar_valid(row,source=''): 
 try:
  t=int(row['unix_ms']);o=float(row['open']);h=float(row['high']);l=float(row['low']);c=float(row['close'])
  return START<=t<CUT and min(o,h,l,c)>0 and h>=max(o,c,l) and l<=min(o,c,h)
 except (KeyError,ValueError,TypeError):return False

def date_from_ms(t):return dt.datetime.fromtimestamp(t/1000,UTC).strftime('%Y-%m-%d')

def doc(base,report,category,status,source,rows=0,first='',last='',reason='',path=''):
 report.append({'category':category,'status':status,'source':source,'rows':rows,'first':first,'last':last,'reason':reason,'path':str(path)})

def authority(base,repo,out):
 f=pathlib.Path(base)/'C2_364_PLAN.csv'
 if not f.exists():raise RuntimeError('MISSING_V4_CANONICAL_C2_364_PLAN')
 rows=readcsv(f);pairs={r['pair']:r['symbol'] for r in rows if r.get('pair') and r.get('symbol')}
 if len(pairs)!=364:raise RuntimeError('C2_364_PAIR_COUNT_MISMATCH '+str(len(pairs)))
 a=pathlib.Path(base)/'ORIGINAL_364_AUTHORITY.json'
 if not a.exists():raise RuntimeError('V4_AUTHORITY_MISSING')
 auth=json.loads(a.read_text(encoding='utf-8'))
 if auth.get('sha256')!=PIN or auth.get('count')!=364:raise RuntimeError('C2_ORIGINAL_SOURCE_PIN_MISMATCH')
 rf=pathlib.Path(repo)/'data/research/rd18_p3x_a1_runtime/full-c2-hourly-acquisition-plan.csv'
 extra={}
 if rf.exists():
  if sha256(rf)!=PIN:raise RuntimeError('LOCAL_SOURCE_PLAN_SHA_MISMATCH')
  extra={r.get('pair','').upper().replace('/','-'):r for r in readcsv(rf)}
 js(out/'AUDIT/C2_AUTHORITY_V5.json',{'count':364,'pinned_original_sha256':PIN,'v4_ref':str(a),'repo_plan_found':rf.exists(),'historical_pit_certified':False,'note':'RD18 acquisition plan not historically eligible trading universe. No survivorship claims.'})
 return pairs,extra

_network_host_failures=defaultdict(int)
_network_broken_hosts=set()
def verify_v4_raw_files(base,out):
    manifest=base/'reports'/'C2_364_FILES_SHA256_MANIFEST.csv'
    if not manifest.is_file():raise RuntimeError('V4_RAW_SHA256_MANIFEST_REQUIRED')
    records=readcsv(manifest);result=[];bad=[]
    if len(records)<500:raise RuntimeError('RAW_MANIFEST_UNEXPECTEDLY_SMALL')
    for item in records:
        rel=item.get('path','');target=base/rel
        if not target.is_file():status='MISSING'
        elif sha256(target)==item.get('sha256'):status='PASS'
        else:status='SHA256_MISMATCH'
        result.append({'path':rel,'status':status,'expected_sha256':item.get('sha256','')})
        if status!='PASS':bad.append((rel,status))
    csvwrite(out/'AUDIT'/'V4_SOURCE_SHA256_VERIFICATION.csv',result,['path','status','expected_sha256'])
    if bad:raise RuntimeError('ORIGINAL_V4_SOURCE_HASH_CHECK_FAILED count='+str(len(bad))+' first='+repr(bad[:5]))
    print('C2_V5_ORIGINAL_SHA256=PASS_'+str(len(records)),flush=True)
    return len(records)

def network_json(url,attempts=2):
 host=urllib.parse.urlparse(url).hostname or ''
 if host in _network_broken_hosts:return None,'HOST_CIRCUIT_BREAKER_'+host
 err=None
 for i in range(attempts):
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'AKAH-C2-Historical-Evidence/5.0','Accept':'application/json'})
   with urllib.request.urlopen(req,timeout=19) as f:
    b=f.read(25000000)
   _network_host_failures[host]=0
   return json.loads(b),''
  except urllib.error.HTTPError as e:
   err='HTTP_'+str(e.code)
   if e.code in (400,401,403,404,451):break
   time.sleep(1.2*(i+1))
  except (OSError,TimeoutError,ValueError) as e:
   err=repr(e)[:180];time.sleep(1.2*(i+1))
 _network_host_failures[host]+=1
 if _network_host_failures[host]>=3 and not str(err).startswith('HTTP_4'):
  _network_broken_hosts.add(host)
 return None,err or 'EMPTY'

def filtered_historical(records,tfield,fields):
 out={}
 for r in records:
  try:
   t=int(r.get(tfield))
   if t<1e10:t*=1000
   if not START<=t<CUT:continue
   z={'unix_ms':t}
   for k,v in fields.items():
    val=r
    for key in v:
     val=val.get(key) if isinstance(val,dict) else None
    z[k]=val if isinstance(val,(int,float,str)) else ''
   out[t]=z
  except (ValueError,TypeError,AttributeError):continue
 return [out[t] for t in sorted(out)]

def write_gz(path,rows,fields):
 p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.part')
 with gzip.open(tmp,'wt',encoding='utf-8',newline='',compresslevel=5) as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
 os.replace(tmp,p)

def collect_macro(out,report,offline):
 specs=[('DEFI_TOTAL_TVL','https://api.llama.fi/v2/historicalChainTvl'),('DEFI_ETHEREUM_TVL','https://api.llama.fi/v2/historicalChainTvl/Ethereum'),('DEFI_SOLANA_TVL','https://api.llama.fi/v2/historicalChainTvl/Solana'),('STABLECOINS_TOTAL','https://api.llama.fi/stablecoincharts/all')]
 for kind,url in specs:
  path=out/'external'/('HISTORICAL_'+kind+'.csv.gz')
  if path.exists():
   rows=rows_gz(path);doc(out,report,'macro','CACHE_REUSED',url,len(rows),path=str(path));continue
  if offline:doc(out,report,'macro','NOT_DOWNLOADED_OFFLINE',url);continue
  vals,err=network_json(url)
  if not isinstance(vals,list):doc(out,report,'macro','SOURCE_UNAVAILABLE',url,reason=err or 'UNKNOWN_RESPONSE');continue
  if kind.startswith('STABLECOINS'):
   rows=filtered_historical(vals,'date',{'usd_circulating':('totalCirculating','peggedUSD')})
   # Also retain total USD equivalent from alternate stablecoin schema when present.
   for r in rows:
    if r['usd_circulating']=='':
     inp=next((v for v in vals if int(v.get('date',0))*1000==r['unix_ms']),{})
     d=inp.get('totalCirculatingUSD',{})
     r['usd_circulating']=d.get('peggedUSD','') if isinstance(d,dict) else ''
   fields=['unix_ms','usd_circulating']
  else:rows=filtered_historical(vals,'date',{'tvl_usd':('tvl',)});fields=['unix_ms','tvl_usd']
  if rows:
   write_gz(path,rows,fields);doc(out,report,'macro','COLLECTED',url,len(rows),date_from_ms(rows[0]['unix_ms']),date_from_ms(rows[-1]['unix_ms']),path=str(path))
  else:doc(out,report,'macro','NO_PRE2024_ROWS',url,reason='source has no parseable historical rows')
  time.sleep(.25)
 # stablecoin per-symbol IDs are fetched from an official live directory; ids applied to historical issuance, not current membership in C2.
 names=['USDT','USDC','DAI']
 if offline:
  for name in names:doc(out,report,'macro','NOT_DOWNLOADED_OFFLINE',f'DefiLlama stablecoin issuance {name}')
  return
 listing,err=network_json('https://api.llama.fi/stablecoins')
 coins=(listing or {}).get('peggedAssets',[]) if isinstance(listing,dict) else []
 for symbol in names:
  matched=next((v for v in coins if str(v.get('symbol','')).upper()==symbol and (str(v.get('pegType','')) in ('peggedUSD','') or not v.get('pegType'))),None)
  if not matched:doc(out,report,'macro','SYMBOL_ID_UNRESOLVED','DefiLlama '+symbol,reason=err or 'no exact symbol id');continue
  cid=matched.get('id');url='https://api.llama.fi/stablecoincharts/all?stablecoin='+urllib.parse.quote(str(cid))
  path=out/'external'/('HISTORICAL_STABLECOIN_'+symbol+'.csv.gz')
  if path.exists():doc(out,report,'macro','CACHE_REUSED',url,path=str(path));continue
  obj,er=network_json(url)
  if not isinstance(obj,list):doc(out,report,'macro','SOURCE_UNAVAILABLE',url,reason=er);continue
  rows=filtered_historical(obj,'date',{'usd_circulating':('totalCirculating','peggedUSD')})
  if rows:
   write_gz(path,rows,['unix_ms','usd_circulating']);doc(out,report,'macro','COLLECTED',url,len(rows),date_from_ms(rows[0]['unix_ms']),date_from_ms(rows[-1]['unix_ms']),path=str(path))
  else:doc(out,report,'macro','NO_PRE2024_ROWS',url)
  time.sleep(.3)

def collect_cm(out,report,offline,pairs,max_assets=40):
 covered=( [s for s in CM_SYMBOLS if s+'-USDT' in pairs] + [p[:-5] for p in sorted(pairs) if p[:-5] not in CM_SYMBOLS] )[:max_assets]
 for sym in covered:
  path=out/'external'/'coinmetrics'/('HISTORICAL_'+sym+'.csv.gz')
  if path.exists():
   doc(out,report,'network','CACHE_REUSED','Coin Metrics '+sym,len(rows_gz(path)),path=str(path));continue
  if offline:
   doc(out,report,'network','NOT_DOWNLOADED_OFFLINE','Coin Metrics '+sym);continue
  params={'assets':sym.lower(),'metrics':','.join(METRICS),'frequency':'1d','start_time':'2017-01-01','end_time':'2023-12-31','page_size':'10000'}
  base='https://community-api.coinmetrics.io/v4/timeseries/asset-metrics?'
  url=base+urllib.parse.urlencode(params)
  val,err=network_json(url)
  if not isinstance(val,dict) or not isinstance(val.get('data'),list):
   # Community catalog may lack a metric; never backfill missing fields by guessing.
   params['metrics']='CapMrktCurUSD';url=base+urllib.parse.urlencode(params);val,err=network_json(url)
  if not isinstance(val,dict) or not isinstance(val.get('data'),list):
   doc(out,report,'network','UNAVAILABLE','Coin Metrics '+sym,reason=err or 'metric/asset not in community API');time.sleep(.65);continue
  allrows=list(val['data']);nexturl=val.get('next_page_url');pages=1
  while nexturl and pages<12:
   sub,er=network_json(nexturl)
   if not isinstance(sub,dict):break
   allrows.extend(sub.get('data') or []);nexturl=sub.get('next_page_url');pages+=1
  rows=[]
  for r in allrows:
   try:
    stamp=dt.datetime.fromisoformat(str(r.get('time','')).replace('Z','+00:00'))
    t=int(stamp.timestamp()*1000)
    if not START<=t<CUT:continue
    rows.append({'unix_ms':t,**{k:r.get(k,'') for k in METRICS}})
   except (ValueError,TypeError):pass
  if rows:
   rows.sort(key=lambda r:r['unix_ms']);write_gz(path,rows,['unix_ms']+METRICS)
   doc(out,report,'network','COLLECTED','Coin Metrics '+sym,len(rows),date_from_ms(rows[0]['unix_ms']),date_from_ms(rows[-1]['unix_ms']),path=str(path))
  else:doc(out,report,'network','NO_PRE2024_ROWS','Coin Metrics '+sym)
  time.sleep(.7)

def collect_cmc(out,report,offline):
 key=os.environ.get('CMC_API_KEY','').strip()
 if not key:
  doc(out,report,'global_cap','REQUIRES_PAID_HISTORICAL_SOURCE','CoinMarketCap global-metrics/quotes/historical',reason='CMC_API_KEY not supplied; exact historical BTC.D/TOTAL cannot be generated from C2 candle prices')
  return
 if offline:doc(out,report,'global_cap','NOT_DOWNLOADED_OFFLINE','CoinMarketCap paid historical global metrics');return
 path=out/'external'/'HISTORICAL_CMC_GLOBAL_METRICS.csv.gz'
 if path.exists():doc(out,report,'global_cap','CACHE_REUSED','CoinMarketCap history',len(rows_gz(path)),path=str(path));return
 headers={'X-CMC_PRO_API_KEY':key,'Accept':'application/json','User-Agent':'AKAH-C2-Evidence/5.0'}
 vals=[];error=''
 for y in range(2017,2024):
  for mo in range(1,13):
   start=f'{y}-{mo:02d}-01T00:00:00Z'
   mend=(dt.datetime(y+1,1,1) if mo==12 else dt.datetime(y,mo+1,1))
   end=mend.strftime('%Y-%m-%dT00:00:00Z')
   url='https://pro-api.coinmarketcap.com/v1/global-metrics/quotes/historical?'+urllib.parse.urlencode({'time_start':start,'time_end':end,'interval':'1d','convert':'USD'})
   try:
    with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=18) as r:val=json.load(r)
    data=val.get('data',{});qs=data.get('quotes',[]) if isinstance(data,dict) else []
    vals.extend(qs)
   except Exception as e:error=str(e)[:130];break
  if error:break
 if not vals:
  doc(out,report,'global_cap','UNAVAILABLE','CoinMarketCap paid history',reason=error or 'no history returned');return
 res={}
 for z in vals:
  try:
   t=int(dt.datetime.fromisoformat(z['timestamp'].replace('Z','+00:00')).timestamp()*1000)
   if not START<=t<CUT:continue
   usd=z.get('quote',{}).get('USD',{})
   res[t]={'unix_ms':t,'btc_dominance':z.get('btc_dominance',''),'eth_dominance':z.get('eth_dominance',''),'total_market_cap_usd':usd.get('total_market_cap',''),'total_volume_24h_usd':usd.get('total_volume_24h','')}
  except Exception:continue
 if res:
  rows=[res[t] for t in sorted(res)];write_gz(path,rows,['unix_ms','btc_dominance','eth_dominance','total_market_cap_usd','total_volume_24h_usd'])
  doc(out,report,'global_cap','COLLECTED','CoinMarketCap paid global historical',len(rows),date_from_ms(rows[0]['unix_ms']),date_from_ms(rows[-1]['unix_ms']),path=str(path))

def lost_intervals(timestamps,period):
 ts=sorted(set(timestamps))
 for prev,nxt in zip(ts,ts[1:]):
  if nxt-prev>period:yield prev+period,nxt, (nxt-prev)//period-1

def kucoin_gap_recover(base,out,report,offline,pairs,max_windows=80):
 # Economic integrity: recovered candles stored as DELTAS, never silently replace V4 raw. Only small/medium internal gaps.
 status=[];budget=max_windows
 for pair in pairs:
  p=base/'hourly'/('KUCOIN_'+pair+'.csv.gz');bar=rows_gz(p)
  if not bar:continue
  ts=sorted(int(x['unix_ms']) for x in bar)
  for left,right,slots in lost_intervals(ts,HOUR):
   if slots>1200:continue
   if not START<=left<right<=CUT:continue
   if budget<=0:break
   entry={'pair':pair,'start':date_from_ms(left),'end':date_from_ms(right-HOUR),'missing_hours':slots}
   if offline:entry['status']='NOT_ATTEMPTED_OFFLINE';status.append(entry);continue
   budget-=1
   query=urllib.parse.urlencode({'symbol':pair,'type':'1hour','startAt':left//1000,'endAt':(right//1000)-1})
   src='https://api.kucoin.com/api/v1/market/candles?'+query
   obj,err=network_json(src)
   if not isinstance(obj,dict) or obj.get('code')!='200000':
    entry['status']='NETWORK_OR_SOURCE_FAILURE';entry['error']=err;status.append(entry);continue
   delta=[]
   for row in obj.get('data',[]):
    if len(row)<7:continue
    c={'unix_ms':str(int(row[0])*1000),'open':row[1],'high':row[3],'low':row[4],'close':row[2],'base_volume':row[5],'quote_volume':row[6],'trade_count':'','taker_buy_quote_volume':''}
    if bar_valid(c) and left<=int(c['unix_ms'])<right:delta.append(c)
   entry['status']='FETCHED' if delta else 'SOURCE_RETURNED_NO_BARS';entry['recovered_hours']=len(delta)
   if delta:
    f=out/'recovered_gaps'/pair/(str(left)+'_1h.csv.gz');write_gz(f,delta,RAW_FIELDS);entry['path']=str(f)
   status.append(entry)
  if budget<=0:break
 # Create a separately provenanced same-venue corrected series, leaving V4 originals untouched.
 bypair=defaultdict(list)
 for entry in status:
  if entry.get('path'):bypair[entry['pair']].append(pathlib.Path(entry['path']))
 for pair,paths in bypair.items():
  orig=rows_gz(base/'hourly'/('KUCOIN_'+pair+'.csv.gz'))
  combined={int(r['unix_ms']):r for r in orig if bar_valid(r)}
  for path in paths:
   for r in rows_gz(path):
    if bar_valid(r):combined.setdefault(int(r['unix_ms']),r)
  dest=out/'reconstructed_hourly'/('KUCOIN_'+pair+'.csv.gz')
  write_gz(dest,[combined[t] for t in sorted(combined)],RAW_FIELDS)
 csvwrite(out/'AUDIT'/'HOURLY_GAP_RECOVERY.csv',status,['pair','start','end','missing_hours','status','recovered_hours','path','error'])
 doc(out,report,'gap_recovery','COMPLETED_BOUNDED','KuCoin small internal 1h gaps',len(status),reason='delta data separate; original V4 untouched; limit='+str(max_windows))
 return status

def rescue_daily_for_missing(base,out,pairs,report,offline,max_pairs=41):
 # Use an archived venue independently; never equate unavailable source with a newly issued asset.
 statuses=[]
 for pair in pairs:
  k=base/'daily'/('KUCOIN_'+pair+'.csv.gz');b=base/'daily'/('BINANCE_'+pair+'.csv.gz')
  if k.exists() or b.exists():continue
  st={'pair':pair,'status':'NOT_ATTEMPTED_OFFLINE' if offline else 'NO_HISTORICAL_BARS_RETURNED'}
  if not offline and len(statuses)<max_pairs:
   symbol=pair.replace('-','');start=START;history={};pages=0;err=''
   while start<CUT and pages<5:
    url='https://data-api.binance.vision/api/v3/klines?'+urllib.parse.urlencode({'symbol':symbol,'interval':'1d','startTime':start,'endTime':CUT-1,'limit':1000})
    ob,err=network_json(url);pages+=1
    if not isinstance(ob,list) or not ob:break
    last=None
    for v in ob:
     if len(v)<11:continue
     z={'unix_ms':v[0],'open':v[1],'high':v[2],'low':v[3],'close':v[4],'base_volume':v[5],'quote_volume':v[7],'trade_count':v[8],'taker_buy_quote_volume':v[10]}
     if bar_valid(z):history[int(v[0])]=z
     last=int(v[0])
    if last is None or last<start:break
    start=last+DAY
    if len(ob)<1000:break
   if history:
    rows=[history[t] for t in sorted(history)];f=out/'rescued_daily'/('BINANCE_'+pair+'.csv.gz');write_gz(f,rows,RAW_FIELDS)
    st={'pair':pair,'status':'RECOVERED_EXCHANGE_HISTORY' if pages<5 or start>=CUT else 'PARTIAL_RETRY_PAGINATION','rows':len(rows),'source':'Binance spot klines API','path':str(f)}
   else:st['error']=err or 'empty history'
  statuses.append(st)
 csvwrite(out/'AUDIT'/'MISSING_SPOT_PAIRS.csv',statuses,['pair','status','rows','source','path','error'])
 doc(out,report,'missing_prices','RESCUE_ATTEMPTED' if not offline else 'OFFLINE_ONLY','Binance market-data API',len(statuses))
 return statuses

def contiguous_segments(seq,step):
 if not seq:return
 st=0;prior=int(seq[0]['unix_ms'])
 for i in range(1,len(seq)):
  t=int(seq[i]['unix_ms'])
  if t-prior!=step:
   yield seq[st:i];st=i
  prior=t
 yield seq[st:]

def forward_ranges(arr,h,high,low):
 """Future high/low i+1..i+h; only valid for complete contiguous forward horizon."""
 n=len(arr);ma=[None]*n;mi=[None]*n;dqmax=deque();dqmin=deque()
 # Reverse pass: append index i+1 each step, remove indices above i+h.
 dqmax.clear();dqmin.clear()
 for i in range(n-1,-1,-1):
  j=i+1
  if j<n:
   while dqmax and high[dqmax[-1]]<=high[j]:dqmax.pop()
   dqmax.append(j)
   while dqmin and low[dqmin[-1]]>=low[j]:dqmin.pop()
   dqmin.append(j)
  while dqmax and dqmax[0]>i+h:dqmax.popleft()
  while dqmin and dqmin[0]>i+h:dqmin.popleft()
  if i+h<n and dqmax and dqmin:
   ma[i]=high[dqmax[0]];mi[i]=low[dqmin[0]]
 return ma,mi

def fnum(v,nd=6):
 return round(v,nd) if v is not None and math.isfinite(v) else ''

def hour_anatomy(base,out,pairs,report):
 fields=['pair','venue','unix_ms','available_unix_ms','open','high','low','close','base_volume','quote_volume','trade_count','taker_buy_quote_volume','return_1h_pct','return_4h_pct','return_24h_pct','return_168h_pct','range_pct','body_pct','upper_wick_pct_of_range','lower_wick_pct_of_range','close_location','trailing_24h_volume_ratio','trailing_168h_volume_ratio','realized_vol_24h_pct','realized_vol_168h_pct','bar_category','volume_category','quality_segment_id']
 label_fields=['pair','venue','unix_ms','future_24h_close_return_pct','future_72h_close_return_pct','future_168h_close_return_pct','future_24h_max_favorable_pct','future_24h_max_adverse_pct','future_168h_max_favorable_pct','future_168h_max_adverse_pct','censor_reason']
 statuses=[];aggregates=defaultdict(lambda:{'n':0,'win':0,'sum':0.,'sum2':0.,'max':-1e100,'min':1e100})
 for k,pair in enumerate(sorted(pairs),1):
  # One exchange-identified series per asset; KuCoin priority, independent Binance alternative if KuCoin absent.
  src='KUCOIN';file=base/'hourly'/('KUCOIN_'+pair+'.csv.gz')
  repaired=out/'reconstructed_hourly'/('KUCOIN_'+pair+'.csv.gz')
  if repaired.is_file():src='KUCOIN_REST_GAP_REPAIRED';file=repaired
  elif not file.is_file():src='BINANCE';file=base/'hourly'/('BINANCE_'+pair+'.csv.gz')
  if not file.is_file():src='BINANCE';file=out/'recovered_hourly'/('BINANCE_'+pair+'.csv.gz')
  r=rows_gz(file)
  if not r:
   statuses.append({'pair':pair,'venue':'','rows':0,'status':'NO_HOURLY_SERIES','future_labeled':0,'segments':0});continue
  valid=[];seen=set();invalid=0
  for row in r:
   if not bar_valid(row):invalid+=1;continue
   t=int(row['unix_ms'])
   if t in seen:invalid+=1;continue
   seen.add(t);valid.append(row)
  valid.sort(key=lambda x:int(x['unix_ms']))
  feat=out/'features_hourly'/('C2_'+src+'_'+pair+'.csv.gz');lab=out/'labels_hourly'/('C2_'+src+'_'+pair+'.csv.gz')
  cache=out/'cache'/('CANDLE_'+pair+'.json')
  if cache.is_file() and feat.is_file() and lab.is_file() and feat.stat().st_size>80 and lab.stat().st_size>80:
   try:
    cached=json.loads(cache.read_text(encoding='utf-8'))
    if cached.get('version')==VERSION and cached.get('source_sha256')==sha256(file):
     statuses.append(cached['status'])
     for item in cached['stats']:
      key=(pair,item['year'],item['bucket'])
      z=aggregates[key]
      for fn in ('n','win','sum','sum2'):z[fn]+=item[fn]
      z['max']=max(z['max'],item['max']);z['min']=min(z['min'],item['min'])
      key=('ALL',item['year'],item['bucket']);zz=aggregates[key]
      for fn in ('n','win','sum','sum2'):zz[fn]+=item[fn]
      zz['max']=max(zz['max'],item['max']);zz['min']=min(zz['min'],item['min'])
     continue
   except (OSError,ValueError,KeyError,TypeError):pass
  feat.parent.mkdir(parents=True,exist_ok=True);lab.parent.mkdir(parents=True,exist_ok=True)
  tmpfeat=feat.with_name(feat.name+'.part');tmplab=lab.with_name(lab.name+'.part')
  labels=0;segments=0
  with gzip.open(tmpfeat,'wt',encoding='utf-8',compresslevel=4,newline='') as f,gzip.open(tmplab,'wt',encoding='utf-8',compresslevel=4,newline='') as lf:
   wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader();lw=csv.DictWriter(lf,fieldnames=label_fields);lw.writeheader()
   for seg in contiguous_segments(valid,HOUR):
    segments+=1;n=len(seg)
    if not n:continue
    t=[int(x['unix_ms']) for x in seg];o=[float(x['open']) for x in seg];c=[float(x['close']) for x in seg];hi=[float(x['high']) for x in seg];lo=[float(x['low']) for x in seg]
    vol=[tofloat(x.get('quote_volume')) for x in seg]
    mx24,mn24=forward_ranges(seg,24,hi,lo);mx168,mn168=forward_ranges(seg,168,hi,lo)
    logret=[0.0]+[math.log(c[i]/c[i-1]) for i in range(1,n)]
    cum=[0.0];cum2=[0.0];vsum=[0.0];vcount=[0]
    for i in range(n):
     lr=logret[i]
     cum.append(cum[-1]+lr);cum2.append(cum2[-1]+lr*lr)
     vsum.append(vsum[-1]+(vol[i] or 0.0));vcount.append(vcount[-1]+int(vol[i] is not None))
    def rv(i,h):
     if i<h:return None
     # h consecutive hourly log returns ending at i; exclude the first row's synthetic 0.
     summ=cum[i+1]-cum[i+1-h];sq=cum2[i+1]-cum2[i+1-h]
     var=max(0.0,sq/h-(summ/h)**2)
     return 100*math.sqrt(var)
    for i in range(n):
     rng=hi[i]-lo[i];ret=lambda h:100*(c[i]/c[i-h]-1) if i>=h else None
     lower=(min(c[i],o[i])-lo[i])/rng if rng>0 else None;upper=(hi[i]-max(c[i],o[i]))/rng if rng>0 else None;cloc=(c[i]-lo[i])/rng if rng>0 else None
     def vr(h):
      if i<h or vol[i] is None:return None
      cnt=vcount[i]-vcount[i-h];tot=vsum[i]-vsum[i-h]
      return vol[i]/(tot/cnt) if cnt==h and tot>0 else None
     vv=vr(24)
     if cloc is None:shape='ZERO_RANGE'
     elif cloc>=.8 and lower is not None and lower>=.5:shape='LOWER_WICK_HIGH_CLOSE'
     elif cloc<=.2 and upper is not None and upper>=.5:shape='UPPER_WICK_LOW_CLOSE'
     elif cloc>=.8:shape='HIGH_CLOSE'
     elif cloc<=.2:shape='LOW_CLOSE'
     else:shape='MID_CLOSE'
     vclass='NOT_MEASURABLE' if vv is None else ('VOLUME_SPIKE_2X' if vv>=2 else ('VOLUME_LOW_HALF' if vv<=.5 else 'VOLUME_NORMAL'))
     z={'pair':pair,'venue':src,'unix_ms':t[i],'available_unix_ms':t[i]+HOUR,'open':o[i],'high':hi[i],'low':lo[i],'close':c[i],
        'base_volume':seg[i].get('base_volume',''),'quote_volume':seg[i].get('quote_volume',''),'trade_count':seg[i].get('trade_count',''),'taker_buy_quote_volume':seg[i].get('taker_buy_quote_volume',''),
        'return_1h_pct':fnum(ret(1)),'return_4h_pct':fnum(ret(4)),'return_24h_pct':fnum(ret(24)),'return_168h_pct':fnum(ret(168)),
        'range_pct':fnum(100*rng/c[i]),'body_pct':fnum(100*(c[i]-o[i])/o[i]),'upper_wick_pct_of_range':fnum(100*upper if upper is not None else None),
        'lower_wick_pct_of_range':fnum(100*lower if lower is not None else None),'close_location':fnum(cloc),'trailing_24h_volume_ratio':fnum(vv),
        'trailing_168h_volume_ratio':fnum(vr(168)),'realized_vol_24h_pct':fnum(rv(i,24)),'realized_vol_168h_pct':fnum(rv(i,168)),
        'bar_category':shape,'volume_category':vclass,'quality_segment_id':segments}
     wr.writerow(z)
     fl={}
     for h in (24,72,168):fl['future_'+str(h)+'h_close_return_pct']=fnum(100*(c[i+h]/c[i]-1)) if i+h<n else ''
     for h,ma,mi in ((24,mx24,mn24),(168,mx168,mn168)):
      fl['future_'+str(h)+'h_max_favorable_pct']=fnum(100*(ma[i]/c[i]-1)) if ma[i] is not None else ''
      fl['future_'+str(h)+'h_max_adverse_pct']=fnum(100*(mi[i]/c[i]-1)) if mi[i] is not None else ''
     fl.update({'pair':pair,'venue':src,'unix_ms':t[i],'censor_reason':'HORIZON_END_OR_GAP' if i+168>=n else ''});lw.writerow(fl)
     if i+24<n:
      labels+=1
      future=100*(c[i+24]/c[i]-1)
      for key in ((pair,date_from_ms(t[i])[:4],shape),(pair,date_from_ms(t[i])[:4],vclass),('ALL',date_from_ms(t[i])[:4],shape),('ALL',date_from_ms(t[i])[:4],vclass)):
       a=aggregates[key];a['n']+=1;a['win']+=int(future>0);a['sum']+=future;a['sum2']+=future*future;a['max']=max(a['max'],future);a['min']=min(a['min'],future)
  os.replace(tmpfeat,feat);os.replace(tmplab,lab)
  status={'pair':pair,'venue':src,'rows':len(valid),'status':'ANALYZED','future_labeled':labels,'segments':segments,'invalid_or_duplicate_rows':invalid}
  statuses.append(status)
  cache_stats=[{'year':key[1],'bucket':key[2],**dict(v)} for key,v in aggregates.items() if key[0]==pair]
  js(cache,{'version':VERSION,'source_sha256':sha256(file),'status':status,'stats':cache_stats})
  if k%40==0:print('C2_V5_HOURLY_CANDLES_ANALYZED',k,'/',len(pairs),flush=True)
 summary=[]
 for (pair,yr,category),v in sorted(aggregates.items()):
  summary.append({'pair':pair,'year':yr,'candle_bucket':category,'n':v['n'],'next_24h_positive_pct':fnum(100*v['win']/v['n'],3),
                  'mean_next_24h_return_pct':fnum(v['sum']/v['n'],5),'std_next_24h_return_pct':fnum(math.sqrt(max(0,v['sum2']/v['n']-(v['sum']/v['n'])**2)),5),'max_next_24h_return_pct':fnum(v['max']),'min_next_24h_return_pct':fnum(v['min']),
                  'warning':'OVERLAPPING_24H_OUTCOMES;NOT_INDEPENDENT_TRADES;NO_COSTS;DESCRIPTIVE_ONLY'})
 csvwrite(out/'ANALYSIS'/'CANDLE_CONDITIONAL_24H_BY_PAIR_YEAR.csv',summary,['pair','year','candle_bucket','n','next_24h_positive_pct','mean_next_24h_return_pct','std_next_24h_return_pct','max_next_24h_return_pct','min_next_24h_return_pct','warning'])
 csvwrite(out/'AUDIT'/'CANDLE_ANALYSIS_COVERAGE.csv',statuses,['pair','venue','rows','status','future_labeled','segments','invalid_or_duplicate_rows'])
 doc(out,report,'candles','ANALYZED_ALL_AVAILABLE_HOURLY',str(base),sum(x['rows'] for x in statuses),reason='separate strictly causal feature tables and future outcome label tables')
 return statuses

def rescue_missing_hourly_from_binance(base,out,pairs,report,offline,max_pairs=33):
    # Separate exchange-identified recovery, only missing hourly series; do not replace KuCoin prices.
    statuses=[];count=0
    for pair in sorted(pairs):
        if (base/'hourly'/('KUCOIN_'+pair+'.csv.gz')).is_file() or (base/'hourly'/('BINANCE_'+pair+'.csv.gz')).is_file():continue
        existing=out/'recovered_hourly'/('BINANCE_'+pair+'.csv.gz')
        if existing.is_file():
            statuses.append({'pair':pair,'status':'REUSE_PREVIOUS_RECOVERY','rows':len(rows_gz(existing))});continue
        daily=base/'daily'/('BINANCE_'+pair+'.csv.gz')
        if not daily.is_file():daily=out/'rescued_daily'/('BINANCE_'+pair+'.csv.gz')
        if not daily.is_file():continue
        if offline:
            statuses.append({'pair':pair,'status':'OFFLINE_BINANCE_HOURLY_NEEDED'});continue
        if count>=max_pairs:break
        count+=1
        days=rows_gz(daily)
        if not days:continue
        lo=min(int(r['unix_ms']) for r in days);hi=min(CUT,max(int(r['unix_ms']) for r in days)+DAY)
        symbol=pair.replace('-','');rows={};pages=0;error=''
        while lo<hi and pages<65:
            url='https://data-api.binance.vision/api/v3/klines?'+urllib.parse.urlencode({'symbol':symbol,'interval':'1h','startTime':lo,'endTime':hi-1,'limit':1000})
            obj,error=network_json(url);pages+=1
            if not isinstance(obj,list) or not obj:break
            last=None
            for v in obj:
                if len(v)<11:continue
                z={'unix_ms':v[0],'open':v[1],'high':v[2],'low':v[3],'close':v[4],'base_volume':v[5],'quote_volume':v[7],'trade_count':v[8],'taker_buy_quote_volume':v[10]}
                if bar_valid(z):rows[int(v[0])]=z
                last=int(v[0])
            if last is None or last<lo:break
            lo=last+HOUR
            if len(obj)<1000:break
        if rows:
            write_gz(existing,[rows[k] for k in sorted(rows)],RAW_FIELDS)
            statuses.append({'pair':pair,'status':'RECOVERED_BINANCE_HOURLY' if lo>=hi else 'PARTIAL_RETRY_SAME_COMMAND','rows':len(rows),'pages':pages,'output_path':str(existing)})
        else:statuses.append({'pair':pair,'status':'SOURCE_HOURLY_UNAVAILABLE','pages':pages,'error':error})
    csvwrite(out/'AUDIT'/'MISSING_HOURLY_RESCUE.csv',statuses,['pair','status','rows','pages','output_path','error'])
    doc(out,report,'missing_prices','BINANCE_HOURLY_RECOVERY_ATTEMPTED','Binance spot hourly REST (source-identified)',sum(int(x.get('rows',0)) for x in statuses))
    return statuses

def derive_complete_daily_from_hourly(base,out,pairs,report):
    # Only full 24-hour UTC days are converted, independently labeled; never synthesize an absent candle.
    results=[]
    for pair in sorted(pairs):
        if (base/'daily'/('KUCOIN_'+pair+'.csv.gz')).exists() or (base/'daily'/('BINANCE_'+pair+'.csv.gz')).exists():continue
        venue='KUCOIN';f=base/'hourly'/('KUCOIN_'+pair+'.csv.gz')
        if not f.exists():venue='BINANCE';f=base/'hourly'/('BINANCE_'+pair+'.csv.gz')
        if not f.exists():venue='BINANCE';f=out/'recovered_hourly'/('BINANCE_'+pair+'.csv.gz')
        if not f.exists():continue
        rows=rows_gz(f);days=defaultdict(list)
        for r in rows:
            if bar_valid(r):days[(int(r['unix_ms'])//DAY)*DAY].append(r)
        converted=[];incomplete=0
        for day,bars in sorted(days.items()):
            bars.sort(key=lambda x:int(x['unix_ms']))
            if len(bars)!=24 or [int(x['unix_ms']) for x in bars]!=[day+h*HOUR for h in range(24)]:
                incomplete+=1;continue
            qb=[tofloat(x.get('quote_volume')) for x in bars];bv=[tofloat(x.get('base_volume')) for x in bars]
            converted.append({'unix_ms':day,'open':bars[0]['open'],'high':max(float(x['high']) for x in bars),
              'low':min(float(x['low']) for x in bars),'close':bars[-1]['close'],
              'base_volume':sum(bv) if all(v is not None for v in bv) else '',
              'quote_volume':sum(qb) if all(v is not None for v in qb) else '',
              'trade_count':sum(float(x['trade_count']) for x in bars) if all(x.get('trade_count') for x in bars) else '',
              'taker_buy_quote_volume':sum(float(x['taker_buy_quote_volume']) for x in bars) if all(x.get('taker_buy_quote_volume') for x in bars) else ''})
        if converted:
            f=out/'derived_daily'/('DERIVED_'+venue+'_'+pair+'.csv.gz');write_gz(f,converted,RAW_FIELDS)
            results.append({'pair':pair,'derived_days':len(converted),'incomplete_days_discarded':incomplete,'venue':venue,'path':str(f)})
    csvwrite(out/'AUDIT'/'DERIVED_COMPLETE_DAILY.csv',results,['pair','derived_days','incomplete_days_discarded','venue','path'])
    doc(out,report,'daily_recovery','COMPLETE_24H_ONLY','direct hourly OHLC aggregation; provenance DERIVED not exchange-reported',sum(r['derived_days'] for r in results))
    return results

def daily_indicators(base,out,pairs,report):
 fields=['pair','venue','unix_ms','date','close','quote_volume','return_1d_pct','return_7d_pct','return_30d_pct','return_90d_pct','sma20','sma50','sma200','ema12','ema26','ema50','ema200','macd','macd_signal','rsi14_wilder','atr14_wilder','bollinger20_width_pct','donchian20_breakout_high','donchian20_breakdown_low','stochastic14_pct','williams_r14','obv','money_flow_multiplier','chaikin_money_flow20','realized_volatility30_pct','volume_ratio30','trade_count','taker_buy_ratio','source_quality','missing_days_in_segment']
 status=[]
 for k,pair in enumerate(sorted(pairs),1):
  venue='KUCOIN';p=base/'daily'/('KUCOIN_'+pair+'.csv.gz')
  if not p.exists():venue='BINANCE';p=base/'daily'/('BINANCE_'+pair+'.csv.gz')
  if not p.exists():
   options=list((out/'derived_daily').glob('DERIVED_*_'+pair+'.csv.gz'))
   if options:p=options[0];venue='DERIVED_FROM_HOURLY_'+('KUCOIN' if 'KUCOIN' in p.name else 'BINANCE')
  raw=rows_gz(p)
  if not raw:status.append({'pair':pair,'status':'NO_EXCHANGE_DAILY','rows':0});continue
  clean=sorted((v for v in raw if bar_valid(v)),key=lambda z:int(z['unix_ms']))
  path=out/'features_daily'/('C2_'+venue+'_'+pair+'.csv.gz');path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp')
  count=0
  with gzip.open(tmp,'wt',encoding='utf-8',compresslevel=5,newline='') as f:
   w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
   for seg in contiguous_segments(clean,DAY):
    if not seg:continue
    t=[int(z['unix_ms']) for z in seg];c=[float(z['close']) for z in seg];h=[float(z['high']) for z in seg];l=[float(z['low']) for z in seg];o=[float(z['open']) for z in seg];v=[tofloat(z.get('quote_volume')) for z in seg];n=len(seg)
    em={z:None for z in (12,26,50,200)};signal=None;ar=ag=al=None;prior=None;obv=0.0
    tr=[];mfv=[];vols=[]
    for i in range(n):
     prior=c[i-1] if i else c[i]
     for z in em:em[z]=c[i] if em[z] is None else (2/(z+1))*c[i]+(1-2/(z+1))*em[z]
     m=em[12]-em[26];signal=m if signal is None else .2*m+.8*signal
     tr0=max(h[i]-l[i],abs(h[i]-prior),abs(l[i]-prior));tr.append(tr0)
     gain=max(0,c[i]-prior);loss=max(0,prior-c[i]);
     if i==14:ag=sum(max(0,c[k]-c[k-1]) for k in range(1,15))/14;al=sum(max(0,c[k-1]-c[k]) for k in range(1,15))/14;ar=sum(tr[1:15])/14
     elif i>14:
      ag=(ag*13+gain)/14;al=(al*13+loss)/14;ar=(ar*13+tr0)/14
     rsi=100 if i>=14 and al==0 else (100-100/(1+(ag/al))) if i>=14 and al else None
     if i>0 and tofloat(seg[i].get('base_volume')) is not None:obv+=float(seg[i]['base_volume'])*(1 if c[i]>prior else (-1 if c[i]<prior else 0))
     mfm=((c[i]-l[i])-(h[i]-c[i]))/(h[i]-l[i]) if h[i]>l[i] else 0.0
     mfv.append(mfm*(v[i] or 0.0));vols.append(v[i])
     def ret(z):return 100*(c[i]/c[i-z]-1) if i>=z else None
     def sma(z):return sum(c[i-z+1:i+1])/z if i>=z-1 else None
     top=max(h[i-13:i+1]) if i>=13 else None;bot=min(l[i-13:i+1]) if i>=13 else None
     std=None
     if i>=19:
      arr=c[i-19:i+1];avg=sum(arr)/20;std=math.sqrt(sum((x-avg)**2 for x in arr)/20)
     width=400*std/avg if i>=19 and avg else None
     donhi=max(h[i-20:i]) if i>=20 else None;donlo=min(l[i-20:i]) if i>=20 else None
     cash=sum((x or 0) for x in v[i-19:i+1]) if i>=19 else None
     cmf=sum(mfv[i-19:i+1])/cash if i>=19 and cash and all(x is not None for x in v[i-19:i+1]) else None
     vratio=v[i]/(sum(v[i-30:i])/30) if i>=30 and v[i] is not None and all(x is not None for x in v[i-30:i]) and sum(v[i-30:i])>0 else None
     rv=None
     if i>=30:
      lrs=[math.log(c[j]/c[j-1]) for j in range(i-29,i+1)];mu=sum(lrs)/30;rv=100*math.sqrt(sum((x-mu)**2 for x in lrs)/30)
     buy=tofloat(seg[i].get('taker_buy_quote_volume'));q=v[i]
     z={'pair':pair,'venue':venue,'unix_ms':t[i],'date':date_from_ms(t[i]),'close':c[i],'quote_volume':seg[i].get('quote_volume',''),
        'return_1d_pct':fnum(ret(1)),'return_7d_pct':fnum(ret(7)),'return_30d_pct':fnum(ret(30)),'return_90d_pct':fnum(ret(90)),
        'sma20':fnum(sma(20)),'sma50':fnum(sma(50)),'sma200':fnum(sma(200)),'ema12':fnum(em[12]),'ema26':fnum(em[26]),'ema50':fnum(em[50]),'ema200':fnum(em[200]),
        'macd':fnum(m),'macd_signal':fnum(signal),'rsi14_wilder':fnum(rsi),'atr14_wilder':fnum(ar),'bollinger20_width_pct':fnum(width),
        'donchian20_breakout_high':int(h[i]>donhi) if donhi is not None else '', 'donchian20_breakdown_low':int(l[i]<donlo) if donlo is not None else '',
        'stochastic14_pct':fnum(100*(c[i]-bot)/(top-bot)) if top is not None and top>bot else '',
        'williams_r14':fnum(-100*(top-c[i])/(top-bot)) if top is not None and top>bot else '',
        'obv':fnum(obv),'money_flow_multiplier':fnum(mfm),'chaikin_money_flow20':fnum(cmf),'realized_volatility30_pct':fnum(rv),
        'volume_ratio30':fnum(vratio),'trade_count':seg[i].get('trade_count',''),'taker_buy_ratio':fnum(buy/q) if buy is not None and q and q>0 else '',
        'source_quality':('DERIVED_COMPLETE_24H' if venue.startswith('DERIVED_') else 'EXCHANGE_REPORTED_'+venue),'missing_days_in_segment':0}
     w.writerow(z);count+=1
  os.replace(tmp,path)
  status.append({'pair':pair,'status':'ANALYZED','rows':count,'venue':venue})
  if k%70==0:print('C2_V5_DAILY_FEATURES_ANALYZED',k,'/',len(pairs),flush=True)
 csvwrite(out/'AUDIT'/'DAILY_FEATURES_COVERAGE.csv',status,['pair','status','rows','venue'])
 doc(out,report,'daily_features','DERIVED_CAUSAL','Observed exchange daily candles',sum(x.get('rows',0) for x in status))
 return status

def build_joined_market_context(out,pairs,report):
    """Observed-panel breadth, external macro rows kept separate from future outcomes.
    Every source observation has an explicit not-before-next-day timestamp, not event time alone.
    """
    flow=defaultdict(lambda:{'assets':set(),'ret30_n':0,'ret30_pos':0,'ma50_n':0,'ma50_pos':0,'rsi_n':0,'rsi_sum':0.0,'total_quote_volume':0.0,'btc_quote_volume':None})
    for f in sorted((out/'features_daily').glob('*.csv.gz')):
        pair=f.stem.replace('.csv','').replace('C2_','')
        with gzip.open(f,'rt',encoding='utf-8',newline='') as g:
            for row in csv.DictReader(g):
                day=row['date'];z=flow[day];z['assets'].add(row['pair'])
                v=tofloat(row.get('return_30d_pct'))
                if v is not None:z['ret30_n']+=1;z['ret30_pos']+=int(v>0)
                close=tofloat(row.get('close'));sma=tofloat(row.get('sma50'))
                if close is not None and sma is not None:z['ma50_n']+=1;z['ma50_pos']+=int(close>sma)
                rsi=tofloat(row.get('rsi14_wilder'))
                if rsi is not None:z['rsi_n']+=1;z['rsi_sum']+=rsi
                q=tofloat(row.get('quote_volume'))
                if q is not None:
                    z['total_quote_volume']+=q
                    if row['pair']=='BTC-USDT':z['btc_quote_volume']=q
    ext={}
    for field,name in [('stablecoin_supply_usd','HISTORICAL_STABLECOINS_TOTAL'),('defi_tvl_usd','HISTORICAL_DEFI_TOTAL_TVL')]:
        path=out/'external'/(name+'.csv.gz')
        if not path.is_file():continue
        for x in rows_gz(path):
            val=tofloat(x.get('usd_circulating') if field=='stablecoin_supply_usd' else x.get('tvl_usd'))
            if val is not None:ext.setdefault(date_from_ms(int(x['unix_ms'])),{})[field]=val
    cm=out/'external'/'coinmetrics'/'HISTORICAL_BTC.csv.gz'
    if cm.is_file():
        for x in rows_gz(cm):
            val=tofloat(x.get('CapMrktCurUSD'))
            if val is not None:ext.setdefault(date_from_ms(int(x['unix_ms'])),{})['btc_market_cap_usd']=val
    cmc=out/'external'/'HISTORICAL_CMC_GLOBAL_METRICS.csv.gz'
    if cmc.is_file():
        for x in rows_gz(cmc):
            d=ext.setdefault(date_from_ms(int(x['unix_ms'])),{})
            for field in ('btc_dominance','eth_dominance','total_market_cap_usd','total_volume_24h_usd'):
                v=tofloat(x.get(field))
                if v is not None:d[field]=v
    rows=[]
    for day,b in sorted(flow.items()):
        x={'date':day,'known_after_utc_day_end':day+' UTC DAY CLOSE + PROVIDER REPORTING DELAY','observed_assets':len(b['assets']),'assets_with_30d_return':b['ret30_n'],
           'observed_breadth_30d_positive_pct':fnum(100*b['ret30_pos']/b['ret30_n']) if b['ret30_n'] else '',
           'assets_with_ma50':b['ma50_n'],'observed_breadth_above_sma50_pct':fnum(100*b['ma50_pos']/b['ma50_n']) if b['ma50_n'] else '',
           'median_rsi14':'','mean_rsi14':fnum(b['rsi_sum']/b['rsi_n']) if b['rsi_n'] else '',
           'panel_quote_turnover_usd':fnum(b['total_quote_volume'],2),
           'btc_share_of_observed_panel_turnover_pct':fnum(100*b['btc_quote_volume']/b['total_quote_volume']) if b['btc_quote_volume'] is not None and b['total_quote_volume'] else '',
           'NOT_ACTUAL_BTC_DOMINANCE':'YES',
           'external_stablecoin_supply_usd':fnum(ext.get(day,{}).get('stablecoin_supply_usd')),
           'external_defi_tvl_usd':fnum(ext.get(day,{}).get('defi_tvl_usd')),
           'external_btc_market_cap_usd':fnum(ext.get(day,{}).get('btc_market_cap_usd')),
           'external_global_btc_dominance_pct':fnum(ext.get(day,{}).get('btc_dominance')),
           'external_global_total_market_cap_usd':fnum(ext.get(day,{}).get('total_market_cap_usd')),
           'panel_status':'OBSERVED_HISTORICAL_DATA_NOT_PIT_UNIVERSE_CERTIFIED'}
        rows.append(x)
    fields=['date','known_after_utc_day_end','observed_assets','assets_with_30d_return','observed_breadth_30d_positive_pct','assets_with_ma50','observed_breadth_above_sma50_pct','mean_rsi14','panel_quote_turnover_usd','btc_share_of_observed_panel_turnover_pct','NOT_ACTUAL_BTC_DOMINANCE','external_stablecoin_supply_usd','external_defi_tvl_usd','external_btc_market_cap_usd','external_global_btc_dominance_pct','external_global_total_market_cap_usd','panel_status']
    csvwrite(out/'ANALYSIS'/'C2_364_JOINT_DAILY_MARKET_CONTEXT.csv',rows,fields)
    doc(out,report,'joint_market_context','CAUSAL_DAILY_CONTEXT_SNAPSHOT','C2 observed panel + externally sourced historical macro, no synthetic global dominance',len(rows))
    return rows

def vault_inventory(root,out,report):
 root=pathlib.Path(root)
 if not root.exists():doc(out,report,'legacy_microstructure','V2_CACHE_NOT_FOUND',str(root));return
 files=[];cnt=defaultdict(lambda:{'n':0,'bytes':0})
 paths=[root/'raw/binance/spot/klines',root/'raw/binance/spot/aggTrades',root/'raw/binance/futures_um/klines',root/'raw/binance/futures_um/fundingRate',root/'local_canonical_tape']
 for src in paths:
  if not src.exists():continue
  for f in src.rglob('*'):
   if not f.is_file():continue
   try:
    relative=f.relative_to(root).as_posix();sz=f.stat().st_size
    # Do not read pre-2024 sealed rows: filename filter for month-specific sources.
    import re
    dates=re.findall(r'\b(20\d\d)[-_](0[1-9]|1[0-2])\b',f.name)
    if dates and any(int(y)>=2024 for y,m in dates):continue
    files.append({'path':relative,'bytes':sz,'file_suffix':f.suffix});key='/'.join(relative.split('/')[:4]);cnt[key]['n']+=1;cnt[key]['bytes']+=sz
   except OSError:continue
 csvwrite(out/'AUDIT'/'V2_CACHED_RAW_INVENTORY.csv',files,['path','bytes','file_suffix'])
 doc(out,report,'legacy_microstructure','INVENTORIED_NOT_DOWNLOADED',str(root),len(files),reason='preserved cached minute/aggTrades archive; not falsely marked as parsed.')

def microstructure_cached_months(vault,out,pairs,report,max_minutes=40,max_uncompressed_mb=1000):
    """Process already downloaded Binance 1-minute and aggTrades monthly ZIPs.
    Saves per-month hourly aggregates, checkpointed and resumable. No downloads, no source modification.
    No order-book or true individual-trade depth is inferred.
    """
    import re
    root=pathlib.Path(vault)/'raw/binance/spot';t0=time.monotonic()
    if not root.is_dir():
        doc(out,report,'microstructure','V2_ARCHIVES_NOT_FOUND',str(root));return []
    statuses=[];processed=0
    columns=['pair','month','kind','status','events','hour_bins','bytes_uncompressed','raw_path','output_path','reason']
    for kind in ('klines','aggTrades'):
        folder=root/kind
        if not folder.is_dir():continue
        candidates=sorted(folder.rglob('*.zip'))
        for f in candidates:
            if time.monotonic()-t0>max_minutes*60:
                statuses.append({'pair':'ALL','kind':kind,'status':'TIME_BUDGET_REACHED_RESUME_SAME_COMMAND'});break
            matches=re.findall(r'(20\d{2})-(0[1-9]|1[0-2])',f.name)
            if not matches:continue
            year,mo=map(int,matches[-1])
            if year>=2024 or year<2017:continue
            # Parent can be spot/klines/BTCUSDT/1m/ or spot/aggTrades/BTCUSDT/
            sym=f.parent.parent.name if kind=='klines' else f.parent.name
            if kind=='klines' and f.parent.name!='1m':continue
            pair=sym[:-4]+'-USDT' if sym.endswith('USDT') else sym
            if pair not in pairs:continue
            month=f'{year:04d}-{mo:02d}'
            output=out/'microstructure_hourly'/kind/(pair+'_'+month+'.csv.gz')
            if output.is_file() and output.stat().st_size>80:
                statuses.append({'pair':pair,'month':month,'kind':kind,'status':'REUSED_CACHED','events':0,'hour_bins':0,'raw_path':str(f),'output_path':str(output)})
                continue
            try:
                with zipfile.ZipFile(f) as z:
                    csvfiles=[v for v in z.infolist() if v.filename.lower().endswith('.csv')]
                    if not csvfiles:raise ValueError('NO_CSV_MEMBER')
                    entry=csvfiles[0]
                    if entry.file_size>max_uncompressed_mb*1048576:
                        statuses.append({'pair':pair,'month':month,'kind':kind,'status':'OVERSIZE_SKIPPED','bytes_uncompressed':entry.file_size,'raw_path':str(f),'reason':'Raise max uncompressed MB when resources allow'});continue
                    bins=defaultdict(lambda:{'count':0,'quote_volume':0.,'base_volume':0.,'taker_buy_quote':0.,'taker_sell_quote':0.,'agg_events':0,'minute_max_range_pct':0.,'minute_count':0,'reported_trade_count':0,'last_minute_close':None,'rv1m_sq':0.0})
                    counter=0
                    with z.open(entry) as infile:
                        reader=csv.reader(io.TextIOWrapper(infile,encoding='utf-8-sig',errors='replace',newline=''))
                        for x in reader:
                            try:
                                if kind=='klines':
                                    if len(x)<11:continue
                                    tt=int(x[0]);tt=tt//1000 if tt>=10**15 else tt
                                    if not START<=tt<CUT:continue
                                    op=float(x[1]);high=float(x[2]);low=float(x[3]);cl=float(x[4]);bas=float(x[5]);quote=float(x[7]);tc=int(float(x[8]));buy=float(x[10])
                                    if not min(op,high,low,cl)>0:continue
                                    b=bins[(tt//HOUR)*HOUR];b['count']+=1;b['minute_count']+=1;b['quote_volume']+=quote;b['base_volume']+=bas;b['taker_buy_quote']+=buy;b['reported_trade_count']+=tc
                                    b['minute_max_range_pct']=max(b['minute_max_range_pct'],100*(high-low)/cl)
                                    if b['last_minute_close'] is not None:
                                        r=math.log(cl/b['last_minute_close']);b['rv1m_sq']+=r*r
                                    b['last_minute_close']=cl
                                else:
                                    if len(x)<7:continue
                                    tt=int(x[5]);tt=tt//1000 if tt>=10**15 else tt
                                    if not START<=tt<CUT:continue
                                    price=float(x[1]);qty=float(x[2]);
                                    if price<=0 or qty<0:continue
                                    maker=str(x[6]).lower() in ('true','1')
                                    quote=price*qty;b=bins[(tt//HOUR)*HOUR];b['agg_events']+=1;b['base_volume']+=qty;b['quote_volume']+=quote
                                    if maker:b['taker_sell_quote']+=quote
                                    else:b['taker_buy_quote']+=quote
                                    b['count']+=1
                                counter+=1
                            except (ValueError,TypeError,IndexError,ZeroDivisionError,OverflowError):continue
                if not bins:
                    statuses.append({'pair':pair,'month':month,'kind':kind,'status':'NO_VALID_PRE2024_EVENTS','raw_path':str(f)});continue
                output.parent.mkdir(parents=True,exist_ok=True)
                data=[]
                for t,b in sorted(bins.items()):
                    data.append({'unix_ms':t,'source':'BINANCE_SPOT_1M' if kind=='klines' else 'BINANCE_SPOT_AGGTRADES','minute_count':b['minute_count'],
                     'minute_reported_trade_count':b['reported_trade_count'],'aggregate_trade_events':b['agg_events'],'quote_volume':fnum(b['quote_volume']),
                     'base_volume':fnum(b['base_volume']),'taker_buy_quote':fnum(b['taker_buy_quote']),
                     'taker_sell_quote':fnum(b['taker_sell_quote']),'minute_max_range_pct':fnum(b['minute_max_range_pct']) if kind=='klines' else '',
                     'minute_rv_sqrt_sum_sq_pct':fnum(100*math.sqrt(b['rv1m_sq'])) if kind=='klines' else '',
                     'buy_quote_fraction':fnum(b['taker_buy_quote']/b['quote_volume']) if b['quote_volume'] else ''})
                write_gz(output,data,list(data[0]))
                processed+=1
                statuses.append({'pair':pair,'month':month,'kind':kind,'status':'ANALYZED','events':counter,'hour_bins':len(data),'bytes_uncompressed':entry.file_size,'raw_path':str(f),'output_path':str(output)})
                if processed%50==0:print('C2_V5_LOCAL_MICRO_ARCHIVES',processed,flush=True)
            except (OSError,zipfile.BadZipFile,RuntimeError,ValueError) as e:
                statuses.append({'pair':pair,'month':month,'kind':kind,'status':'ARCHIVE_INVALID_OR_UNREADABLE','raw_path':str(f),'reason':repr(e)[:180]})
    csvwrite(out/'AUDIT'/'V2_MICROSTRUCTURE_ARCHIVE_ANALYSIS.csv',statuses,columns)
    doc(out,report,'microstructure','CACHED_ARCHIVES_ANALYZED_WITH_BOUNDED_RUNTIME',str(root),processed,reason='1m flow and aggTrades aggressor flow are separate venues; no market depth inferred')
    return statuses

def import_cached_futures_daily(vault,base,out,pairs,report):
    """Binance USD-M perpetual traded OHLC from previously downloaded V2 monthly ZIPs.
    Identified as futures traded price, NOT mark price and NOT spot.
    """
    import re
    root=pathlib.Path(vault)/'raw/binance/futures_um/klines'
    if not root.is_dir():doc(out,report,'futures','V2_USDM_DAILY_CACHE_NOT_FOUND',str(root));return []
    status=[];total=0
    for pair in sorted(pairs):
        symbol=pair.replace('-','');folder=root/symbol/'1d'
        if not folder.is_dir():continue
        target=out/'external'/'futures_daily_traded_price'/('BINANCE_USDM_'+pair+'.csv.gz')
        if target.exists():
            status.append({'pair':pair,'status':'CACHED_V5','rows':len(rows_gz(target))});continue
        records={};files=0;skipped=0
        for file in sorted(folder.glob('*.zip')):
            months=re.findall(r'(20\d{2})-(0[1-9]|1[0-2])',file.name)
            if not months or int(months[-1][0])>=2024:continue
            try:
                with zipfile.ZipFile(file) as z:
                    names=[i for i in z.infolist() if i.filename.endswith('.csv') and i.file_size<25000000]
                    if not names:skipped+=1;continue
                    with z.open(names[0]) as f:
                        reader=csv.reader(io.TextIOWrapper(f,encoding='utf-8-sig',newline='',errors='replace'))
                        for v in reader:
                            try:
                                if len(v)<11:continue
                                ms=int(v[0]);ms=ms//1000 if ms>=10**15 else ms
                                row={'unix_ms':ms,'open':v[1],'high':v[2],'low':v[3],'close':v[4],'base_volume':v[5],
                                     'quote_volume':v[7],'trade_count':v[8],'taker_buy_quote_volume':v[10]}
                                if bar_valid(row):records[ms]=row
                            except (ValueError,TypeError,IndexError):continue
                files+=1
            except (OSError,zipfile.BadZipFile,RuntimeError):skipped+=1
        if records:
            rows=[records[t] for t in sorted(records)];write_gz(target,rows,RAW_FIELDS)
            status.append({'pair':pair,'status':'COLLECTED_FROM_LOCAL_V2','rows':len(rows),'months':files,'invalid_files':skipped,'path':str(target)})
            total+=len(rows)
    csvwrite(out/'AUDIT'/'FUTURES_UM_DAILY_ARCHIVE_COVERAGE.csv',status,['pair','status','rows','months','invalid_files','path'])
    doc(out,report,'futures','ARCHIVED_USDM_PERPETUAL_TRADED_PRICE_PARSED','V2 Binance USD-M traded kline 1d; not mark price',total)
    return status

def futures_spot_funding_joint(base,out,pairs,report):
    rows=[]
    futures=out/'external'/'futures_daily_traded_price'
    for f in sorted(futures.glob('*.csv.gz')) if futures.is_dir() else []:
        pair=f.name.replace('BINANCE_USDM_','').replace('.csv.gz','')
        spot=base/'daily'/('BINANCE_'+pair+'.csv.gz')
        if not spot.is_file():continue
        spotmap={int(x['unix_ms']):tofloat(x.get('close')) for x in rows_gz(spot)}
        for r in rows_gz(f):
            t=int(r['unix_ms']);c=tofloat(r.get('close'));s=spotmap.get(t)
            if c and s:
                rows.append({'pair':pair,'unix_ms':t,'date':date_from_ms(t),'futures_usdm_traded_close':c,'binance_spot_close':s,
                     'futures_vs_spot_close_basis_pct':fnum(100*(c/s-1)),
                     'note':'DAILY_TRADED_CLOSE_BASIS_PROXY_NOT_MARK_PRICE_OR_EXECUTABLE_BASIS;NO_ORDERBOOK'})
    if rows:
        write_gz(out/'ANALYSIS'/'BINANCE_USDM_PERP_SPOT_DAILY_BASIS_PROXY.csv.gz',rows,
            ['pair','unix_ms','date','futures_usdm_traded_close','binance_spot_close','futures_vs_spot_close_basis_pct','note'])
    doc(out,report,'futures','EXCHANGE_MATCHED_SPOT_FUTURES_DAILY_CLOSE_PROXY','Binance Spot vs Binance USD-M perpetual traded close, distinct from true mark-price basis',len(rows))
    return len(rows)

def analyze_funding_history(base,out,pairs,report):
    """Historical Binance USD-M perps funding events, summarized by UTC day.
    Cannot infer open interest, liquidations, funding cash flows or mark basis.
    """
    summary=[];coverage=[]
    for pair in sorted(pairs):
        p=base/'derivatives_funding'/('BINANCE_USDM_'+pair+'.csv.gz')
        if not p.is_file():continue
        v=defaultdict(list);mark=defaultdict(list)
        for r in rows_gz(p):
            t=int(r['unix_ms']);rate=tofloat(r.get('funding_rate'))
            if rate is None:continue
            day=(t//DAY)*DAY;v[day].append(rate)
            mp=tofloat(r.get('mark_price'))
            if mp is not None:mark[day].append(mp)
        for day,a in sorted(v.items()):
            summary.append({'pair':pair,'date':date_from_ms(day),'unix_ms':day,'funding_observations':len(a),
               'funding_rate_sum':fnum(sum(a),10),'funding_rate_mean':fnum(sum(a)/len(a),10),
               'funding_rate_min':fnum(min(a),10),'funding_rate_max':fnum(max(a),10),
               'positive_rate_share_pct':fnum(100*sum(x>0 for x in a)/len(a),4),
               'mark_price_observations':len(mark[day]),'note':'rates are event-level fractions; daily sum is NOT spot strategy PnL'})
        coverage.append({'pair':pair,'daily_rows':len(v),'total_events':sum(len(x) for x in v.values()),'mark_price_events':sum(len(x) for x in mark.values())})
    if summary:
        write_gz(out/'ANALYSIS'/'BINANCE_USDM_HISTORICAL_DAILY_FUNDING.csv.gz',summary,
                 ['pair','date','unix_ms','funding_observations','funding_rate_sum','funding_rate_mean','funding_rate_min','funding_rate_max','positive_rate_share_pct','mark_price_observations','note'])
    csvwrite(out/'AUDIT'/'FUNDING_EVENT_COVERAGE.csv',coverage,['pair','daily_rows','total_events','mark_price_events'])
    doc(out,report,'funding','EVENT_LEVEL_HISTORY_AGGREGATED','Binance historical USD-M funding from V4 only, no new historical OI inference',sum(z['total_events'] for z in coverage))
    return coverage

def compile_coverage(base,out,pairs,authorities,report):
    # Reuse V4 exact audited coverage counts; avoid reading 6.34m hours twice.
    source=base/'reports'/'C2_364_COVERAGE_FINAL.csv'
    audit_by_pair={r['pair']:r for r in readcsv(source)} if source.is_file() else {}
    outrows=[]
    for pair in sorted(pairs):
        orig=audit_by_pair.get(pair,{})
        row={'pair':pair,'source_plan_required_since_open':authorities.get(pair,{}).get('required_since_open',''),
          'source_plan_required_until_exclusive':authorities.get(pair,{}).get('required_until_exclusive',''),
          'historical_pit_status':'NOT_CERTIFIED'}
        for venue in ('KUCOIN','BINANCE'):
            for freq in ('daily','hourly'):
                prefix=venue.lower()+'_'+freq
                key=venue+'_'+freq
                row[key+'_rows']=int(orig.get(prefix+'_rows') or 0)
                row[key+'_first']=orig.get(prefix+'_first','')
                row[key+'_last']=orig.get(prefix+'_last','')
                row[key+'_internal_gaps']=int(orig.get(prefix+'_internal_missing_slots') or 0)
        row['hourly_series_status']='AVAILABLE' if row.get('KUCOIN_hourly_rows',0) or row.get('BINANCE_hourly_rows',0) else 'NO_PRE2024_HOURLY_SERIES_IN_V4'
        start=str(row['source_plan_required_since_open'])
        row['possible_post_cutoff_listing']='YES_FROM_PLAN_METADATA_ONLY' if start[:4].isdigit() and int(start[:4])>=2024 else 'UNKNOWN_OR_PRE2024'
        outrows.append(row)
    fields=['pair','source_plan_required_since_open','source_plan_required_until_exclusive','KUCOIN_daily_rows','KUCOIN_daily_first','KUCOIN_daily_last','KUCOIN_daily_internal_gaps','KUCOIN_hourly_rows','KUCOIN_hourly_first','KUCOIN_hourly_last','KUCOIN_hourly_internal_gaps','BINANCE_daily_rows','BINANCE_daily_first','BINANCE_daily_last','BINANCE_daily_internal_gaps','BINANCE_hourly_rows','BINANCE_hourly_first','BINANCE_hourly_last','BINANCE_hourly_internal_gaps','hourly_series_status','historical_pit_status','possible_post_cutoff_listing']
    csvwrite(out/'AUDIT'/'V5_HISTORICAL_COVERAGE_BY_PAIR.csv',outrows,fields)
    doc(out,report,'universe','COVERAGE_AUDITED_FROM_V4','original RD18 364 C2',len(outrows),reason='V4 coverage counts, not recomputed here; V5 rechecks actual bars during individual analysis')
    return outrows

def pack(out,upload,maxmb=60):
 upload.mkdir(parents=True,exist_ok=True)
 files=[];meta=[]
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  if p.suffix in ('.tmp','.part'):continue
  rel=p.relative_to(out).as_posix()
  if rel.startswith(('AUDIT/','ANALYSIS/','external/')):meta.append(p)
  elif rel.startswith(('features_hourly/','labels_hourly/','features_daily/','derived_daily/','recovered_gaps/','rescued_daily/','microstructure_hourly/','recovered_hourly/','reconstructed_hourly/')):files.append(p)
  else:meta.append(p)
 first=upload/'UPLOAD_THIS_AKAH_C2_V5_ANALYSIS_AND_AUDIT.zip'
 with zipfile.ZipFile(first,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
  for p in meta:z.write(p,p.relative_to(out).as_posix())
  index={'parts':[],'features_files':len(files)}
 parts=[];z=None;written=0;i=0;name=None;members=[]
 def stop():
  nonlocal z,written,members
  if z:
   z.close();parts.append({'filename':name.name,'files':len(members),'bytes':name.stat().st_size});z=None;written=0;members=[]
 for p in files:
  if z is None or (written and written+p.stat().st_size>maxmb*1048576):
   stop();i+=1;name=upload/f'UPLOAD_THIS_AKAH_C2_V5_ENRICHED_PART_{i:04d}.zip';z=zipfile.ZipFile(name,'w',compression=zipfile.ZIP_STORED,allowZip64=True)
  z.write(p,p.relative_to(out).as_posix());members.append(p.name);written+=p.stat().st_size
 stop();index['parts']=parts
 js(upload/'UPLOAD_INDEX.json',index)
 return {'analysis':str(first),'parts':parts}

def safety_selftest():
 assert CUT==int(dt.datetime(2024,1,1,tzinfo=UTC).timestamp()*1000)
 assert bar_valid({'unix_ms':CUT-3600000,'open':2,'high':4,'low':1,'close':3})
 assert not bar_valid({'unix_ms':CUT,'open':2,'high':4,'low':1,'close':3})
 assert not bar_valid({'unix_ms':CUT-3600000,'open':2,'high':1,'low':4,'close':3})
 a=[{'unix_ms':START+i*HOUR} for i in (0,1,3,4)]
 assert [len(x) for x in contiguous_segments(a,HOUR)]==[2,2]
 prices=[3,5,4,8,9,6,7];b=[{'unix_ms':START+i*HOUR} for i in range(len(prices))]
 ma,mi=forward_ranges(b,2,prices,prices)
 assert ma[:5]==[5,8,9,9,7],ma
 assert mi[:5]==[4,4,8,6,6],mi
 assert ma[5] is None and mi[5] is None
 # No forward-candle effect on a prefix: historical bars already indexed remain unchanged.
 assert ma[0]==5
 print('AKAH_C2_V5_SELFTEST=PASS_9')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--base');ap.add_argument('--repo');ap.add_argument('--old-vault');ap.add_argument('--out');ap.add_argument('--upload');ap.add_argument('--offline',action='store_true');ap.add_argument('--selftest',action='store_true');ap.add_argument('--max-cm-assets',type=int,default=364);ap.add_argument('--max-gap-windows',type=int,default=80);ap.add_argument('--max-rescue-pairs',type=int,default=41);ap.add_argument('--max-hourly-rescue-pairs',type=int,default=33);ap.add_argument('--packet-mb',type=int,default=60);ap.add_argument('--max-micro-minutes',type=int,default=40);ap.add_argument('--max-micro-uncompressed-mb',type=int,default=1000)
 a=ap.parse_args()
 if a.selftest:return safety_selftest()
 base=pathlib.Path(a.base);repo=pathlib.Path(a.repo);out=pathlib.Path(a.out);upload=pathlib.Path(a.upload)
 if not base.exists():raise RuntimeError('V4_BASE_MISSING '+str(base))
 if out.resolve()==base.resolve():raise RuntimeError('OUT_MUST_BE_DIFFERENT_FROM_V4_BASE')
 out.mkdir(parents=True,exist_ok=True)
 pairs,authorities=authority(base,repo,out);report=[]
 verify_v4_raw_files(base,out)
 print('C2_V5_START PAIRS=364 MODE='+('OFFLINE' if a.offline else 'ONLINE')+' 2024=SEALED',flush=True)
 compile_coverage(base,out,pairs,authorities,report)
 vault_inventory(pathlib.Path(a.old_vault),out,report)
 microstructure_cached_months(pathlib.Path(a.old_vault),out,pairs,report,a.max_micro_minutes,a.max_micro_uncompressed_mb)
 import_cached_futures_daily(pathlib.Path(a.old_vault),base,out,pairs,report)
 futures_spot_funding_joint(base,out,pairs,report)
 analyze_funding_history(base,out,pairs,report)
 collect_macro(out,report,a.offline)
 collect_cm(out,report,a.offline,pairs,a.max_cm_assets)
 collect_cmc(out,report,a.offline)
 rescue_daily_for_missing(base,out,pairs,report,a.offline,a.max_rescue_pairs)
 rescue_missing_hourly_from_binance(base,out,pairs,report,a.offline,a.max_hourly_rescue_pairs)
 kucoin_gap_recover(base,out,report,a.offline,pairs,a.max_gap_windows)
 print('C2_V5_START_CANDLE_COMPUTATION',flush=True)
 derive_complete_daily_from_hourly(base,out,pairs,report)
 daily=daily_indicators(base,out,pairs,report)
 build_joined_market_context(out,pairs,report)
 hourly=hour_anatomy(base,out,pairs,report)
 report.append({'category':'derivatives','status':'HISTORICAL_OI_LIQUIDATIONS_LONG_SHORT_NOT_AVAILABLE_FROM_SELECTED_PUBLIC_SOURCES','source':'Binance recent OI endpoints are restricted to recent rolling history','rows':0,'reason':'Do not backfill 2022/2023 from current OI/long-short data.'})
 report.append({'category':'market_global','status':'BTC_DOMINANCE_GLOBAL_NOT_COMPUTED_FROM_C2','source':'CoinMarketCap paid CMC_API_KEY optional','rows':0,'reason':'Panel share is not BTC.D; historical total market cap needs authoritative global market source.'})
 csvwrite(out/'AUDIT'/'EXTERNAL_FIELD_STATUS.csv',report,['category','status','source','rows','first','last','reason','path'])
 status={'version':VERSION,'c2_original_364_sha256':PIN,'pre2024_cutoff_ms_exclusive':CUT,'2024_market_rows_read':False,'any_orders_sent':False,'production_repo_mutated':False,'offline':a.offline,
   'daily_pairs_analysed':sum(x['status']=='ANALYZED' for x in daily),'hourly_pairs_analysed':sum(x['status']=='ANALYZED' for x in hourly),
   'hourly_candles_analysed':sum(x['rows'] for x in hourly),'status':'PARTIAL_REAL_MARKET_DATA;DESCRIPTIVE_NO_TRADE_CERTIFICATION',
   'limits':['No historical PIT eligibility certification','C2 list is research acquisition plan, not deployable market membership','Provider absent fields remain missing','Future outcomes isolated from decision-time features','No profitability evidence from overlapping horizons','No 2024, no live, no trading']}
 js(out/'AUDIT'/'V5_STATUS.json',status)
 p=pack(out,upload,a.packet_mb)
 print('C2_V5_DONE='+json.dumps(status),flush=True)
 print('UPLOAD_FIRST='+p['analysis'],flush=True)
 print('UPLOAD_PARTS='+str(len(p['parts'])),flush=True)

if __name__=='__main__':
 try:main()
 except Exception as e:
  import traceback;traceback.print_exc();sys.exit(2)
